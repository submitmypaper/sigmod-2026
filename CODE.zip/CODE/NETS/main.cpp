#include<fstream>
#include <windows.h>
#include <psapi.h>
#include"NET.h"
#include"Tuple.h"
#include"Grid.h"

#include"Test.h"
#include"Tstream.h"

#pragma comment(lib, "psapi.lib")
#pragma warning(disable:4996)
using namespace std;

double getProcessMemoryMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	GetProcessMemoryInfo(GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc));

	return pmc.WorkingSetSize / (1024.0 * 1024.0);
}

double getPeakProcessMemoryMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	if (!GetProcessMemoryInfo(
		GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc)))
	{
		return 0.0;
	}

	return pmc.PeakWorkingSetSize / (1024.0 * 1024.0);
}

void printlogmain(TStream& tstream, Test& test, double time1, double time2) {
	
	ofstream data;
	data.clear();
	data.open("NETSLogFile.txt", ofstream::app);
	if (data.is_open()) {
		data << "Dimension= " << test.GetDimension() << " N= " << test.GetWindowSize() << " K= " << test.GetK() << endl;
		data << "InitTime= " << time1 << "s" << endl;
		data << "RunningTime= " << time2 << "s" << endl;
		data << "=====================================" << endl;
		data.close();
	}
}

int main() {
	int changes = 0;
	TStream ts;
	Test t;
	vector<Test>vecTestFile;
	double dataMemory = 0;
	vector<double>memory;
	double memoryMax = 0;



	for (int j = 0; j < 5; j++) {
		t.Init(vecTestFile, j);
		ts.readFile(vecTestFile[0], j, changes);
		dataMemory = getProcessMemoryMB();

		for (int i = 0; i < vecTestFile.size(); i++) {
			clock_t starttime, endtime;
			starttime = clock();
			NETS net = NETS(vecTestFile[i], ts);
			
			net.Init();
			memory.push_back(getProcessMemoryMB() - dataMemory);

			endtime = clock();
			int ans = net.getOuliersNum();
			double time1 = (double)(endtime - starttime) / CLOCKS_PER_SEC;
			cout << "Init Time: " << (double)(endtime - starttime) / CLOCKS_PER_SEC << "s\n";

			starttime = clock();
			clock_t temp = starttime;
			while (net.streamFront < ts.dataStream.size()) {
				net.update();
				ans = net.getOuliersNum();
				memory.push_back(getProcessMemoryMB() - dataMemory);
				if (net.oldestSlideID % 20 == 0 && net.oldestSlideID != 0) {
					cout << "Current Cursor Time: " << double(clock() - temp) / 1000 << "s\n";
					temp = clock();
				}
				if (net.SlideBegin[net.newestSlideID + 1] > ts.dataStream.size()) {
					break;
				}
			}

			endtime = clock();
			double time2 = (double)(endtime - starttime) / CLOCKS_PER_SEC;
			double avg = 0;
			for (auto it : memory) {
				avg += it;
			}
			avg /= memory.size();
			memoryMax = getPeakProcessMemoryMB() - dataMemory;
			printlogmain(ts, vecTestFile[i], time1, time2);
			memory.clear();
		}
		vecTestFile.clear();
	}
	return 0;
}