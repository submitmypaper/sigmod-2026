#ifndef Test_h
#define Test_h
#include"head.h"
#include"Count.h"
class Test
{
private:
	int dim;
	double R;
	int K;
	int inFlow;
	int N;
	int splitThreshold;
	int kdTree_SplitThreshold;
	int kdTreeChildNum;
	double Rho;
	short mapCount;
	double rhoMin;
	int virtualDim;
	double l_kThreshold;
	double virtualDimThreshold=1;
public:
	Test();
	~Test();
	int GetDim();
	int GetK();
	double GetR();
	int GetInFlow();
	int GetN();
	int GetSplitThreshold();
	double GetRho();
	short GetMapCount();
	double GetRhoMin();
	int GetVirtualDim();
	double GetL_kThreshold();
	int GetkdTree_SplitThreshold();
	int GetkdTreeChildNum();
	double GetVirtualDimThreshold();
	void SetVirtualDim(int vDim);
	void SetDim(int dim);
	void SetK(int k);
	void SetR(double r);
	void SetInFlow(int iF);
	void SetN(int n);
	void SetSplitThreshold(int threshold);
	void SetRho(double inrho);
	void SetMapCount(short count);
	void SetL_kThreshold();
	void SetkdTree_SplitThreshold(int threshold);
	void SetkdTreeChildNum(int childNum);
	void SetVirtualDimThreshold(double threshold);
	void Init(int j);						
	void Init(vector<Test>& vec, int j);	

	void PrintLog(double init, double upd);	
	void SetThresholdWithTAO(Test& t);
	void SetThresholdWithSTK(Test& t);
	void SetThresholdWithHPC(Test& t);
	void SetThresholdWithGAS(Test& t);
	void SetThresholdWithEM(Test& t);
};
#endif
