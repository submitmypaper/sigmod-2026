#ifndef CObjGroup_h
#define CObjGroup_h
#include"head.h"
class CObjGroup
{
private:
	list<int> objectList; 

public:
	CObjGroup();
	~CObjGroup();
	void AddObjToObjectListFront(int id);
	void AddObjToObjectListBack(int id);
	list<int>& GetObjectList();
	int GetObjectListSize();
	void DeleteExpireObject(int minObjectId);
	void ClearObjectList();

};

#endif