#pragma once
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdlib>
#include<fstream>
#include<vector>
#include<queue>
#include<unordered_map>
#include<string>
#include<list>
#include<cassert>
#include<math.h>
#include<stack>
#include<map>
#include<set>
#include<unordered_set>
#include <memory>
#include<stdio.h>
#include <iomanip>
#include <ctime>
#include <numeric>
#include <functional>
#include <cstddef>
#include <float.h>
#include <limits>



#define NNl_ukSmallSize 0.5
#define lambda 2
#define deleteSize 0.25

#define ChangeRLowerBound 0.005
#define ChangeRUpperBound 0.02
#define ChangeRTag 0.5
using namespace std;
#pragma warning(disable:4996)







