#include "CObjectPool.h"

CObjectPool::CObjectPool()
{

}

CObjectPool::~CObjectPool()
{
}

CObject* CObjectPool::AcquireObject()
{
    if (objectPool.empty()) {
        const int m = 1;
        for (int i = 0; i < m; ++i) {
            CObject* obj = new CObject();
            objectPool.push(obj);
        }
    }
    CObject* object = objectPool.front();
    objectPool.pop();
    return object;
}

void CObjectPool::ReleaseObject(CObject* needReleaseObject)
{
    needReleaseObject->Reset();
    objectPool.push(needReleaseObject);
}

void CObjectPool::InitializeObjectPool(int initializeSize)
{
    for (int i = 0; i < initializeSize; ++i) {
        CObject* object = new CObject();
        objectPool.push(object);
    }
}

void CObjectPool::DestroyObjectPool()
{
    while (!objectPool.empty())
    {
        CObject* obj = objectPool.front();
        objectPool.pop();
        if (obj != nullptr)
        {
            delete obj;
        }
    }
}
