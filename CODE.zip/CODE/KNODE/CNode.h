#ifndef CNode_h
#define CNode_h
#include"head.h"
#include"TStream.h"
#include"Test.h"
#include"CObjGroup.h"
#include "IdContainer.h"  
#include "NnlOps.h"       
class CNode
{
private:
    short addr = -1;
    short alarmTime = 0;
    short tighteningl_kTime = 0;
    bool kNodeFlag = false;
    int nodeId;
    int maintainDataNum = 0;
    double sideLength = 0;
    double l_k = DBL_MAX;
    unordered_map<short, CNode*> childList;
    vector<CObjGroup*> dataMap;
    CNode* parentNode = nullptr;
    vector<float> vecLeftDown;
    NNLContainer nnl_uk;
    NNLContainer nnl_ukSmall;
public:
    CNode(int id);
    ~CNode();
    void Reset(int newId);
    void SetNodeInformation(TStream& tstream, Test& test, short calAddr, vector<float> calVecLeftDown, double calSideLength);
    void SetMaintainDataNum(int num);
    void SetKNodeFlag(bool state);
    void Setnnl_uk(NNLContainer& nnl);
    void Setnnl_ukSmall(NNLContainer& nnl);



    void AddObjToNodeFront(int index, int objId);
    void AddObjToNodeBack(int index, int objId);
    void CheckSplit(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool);
    double CalDiagonalLength(int dimension);
    short FindAddrForDataObj(TStream& tstream, Test& test, int objId, vector<int>& vecAddr);
    short CalAddr(TStream& tstream, Test& test, vector<int>& vecAddr);
    void FindChildNode(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool, short calAddr, int objId, vector<int>& vecAddr);
    void AddMaintainDataNum();
    void ClearDataMap();
    void CreateNN_l(TStream& tstream, Test& test);
    void AddOwnLeafToNN_l(TStream& tstream, Test& test);
    double CalMinDisToNode(TStream& tstream, Test& test, CNode* node);
    void SetUpl_k(TStream& tstream, Test& test, std::function<CNode* (int)>& nodePool);
    void SetUpl_k(TStream& tstream, Test& test, std::function<CNode* (int)>& nodePool, NNLContainer& nnl_uk, NNLContainer& nnl_ukSmall);
    void Call_k(TStream& tstream, Test& test, NNLContainer& nnl_uk, NNLContainer& nnl_ukSmall, std::function<CNode* (int)>& nodePool);
    double CalMinDisBetweenObjAndNode(TStream& tstream, Test& test, int objId);
    double CalMaxDisBetweenObjAndNode(TStream& tstream, Test& test, int objId);
    void Tighteningl_k(TStream& tstream, Test& test);
    void Call_kInNode(TStream& tstream, Test& test, multimap<double, int>& knnMap, CNode* nodeInNNr, double& minDis, vector<int>& indexVec);
    void UpdateParentNodel_kAndAlarmTime(TStream& tstream, Test& test);
    void UpdateNodeInformation(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool);
    void UpdateNodeInformation(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool, int& deleteBegin);
    bool UpwardFindOldKNode(TStream& tstream, Test& test, CNode*& oldKnode);
    void Creatennl_ukByOldKnode(TStream& tstream, Test& test, CNode*& oldKnode, std::function<CNode* (int)>& nodePool);
    void ChangeKNodeInformation(TStream& tstream, Test& test);
    void ChangeKNodeInformation(TStream& tstream, Test& test, bool flag);


    int GetNodeId();
    double GetSideLength();
    int GetMaintainDataNum();
    int GetChildNodeNum();
    unordered_map<short, CNode*>& GetChildList();
    CObjGroup* GetCObjGroupById(int id);
    double Getl_k();
    short GetAlarmTime();
    bool GetKNodeFlag();
    CNode* GetParentNode();
    NNLContainer& Getnnl_uk();
    NNLContainer& Getnnl_ukSmall();
    int GetStartIndex(TStream& tstream, Test& test);
    int GetEndIndex(TStream& tstream, Test& test);
    CNode* GetChildNodeByAddr(TStream& tstream, Test& test, short calAddr);
    int Getnnl_ukSize();
    int Getnnl_ukSmallSize();
    short GetTighteningl_kTime();
    void ClearNNL();
    void ReleaseAllChildren(std::function<void(CNode*)>& nodePool);
    void UpdateInfo(TStream& tstream, Test& test);
};

#endif