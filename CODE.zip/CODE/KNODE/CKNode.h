#ifndef CKNode_h
#define CKNode_h

#include"head.h"
#include"CNode.h"
#include"CKDNode.h"
#include"TStream.h"
#include"Test.h"
#include"CSlide.h"
#include"CNodePool.h"
#include "CObjectPool.h"  
#include "IdContainer.h"  
#include "NnlOps.h"  
class CKNode
{
private:
	CNode* root = nullptr;
	vector<CSlide*> slideArray;
	CNodePool nodePool;
	CObjectPool objectPool;

	list<CNode*> kNodeSmall;
	list<CNode*> kNodeLarge;
	unordered_map<int, CNode*> E_I;
	unordered_map<int, CNode*> E_L;
	unordered_map<int, CNode*> changeRMap;
	CKDNode* kdTreeRoot = nullptr;

	unordered_map<int, CNode*> newCreateNodeMap;
	unordered_map<int, CNode*> newObjectInsertNodeMap;

	double initDataSetMemory;
	vector<double> averageMemory;
	double peakMemory;
	short countSlideNum = 0;

public:
	CKNode();
	~CKNode();
	void Init(TStream& tstream, Test& test);
	void Init(TStream& tstream, Test& test, int dataBegin, int dataEnd);
	void InitSlideArray(TStream& tstream, Test& test);
	void InitRoot(TStream& tstream, Test& test);
	void AddObjToRoot(TStream& tstream, Test& test);
	void FindOutlier(TStream& tstream, Test& test);
	void FindKNodeSet(TStream& tstream, Test& test);
	void DivideKNodeLargeIntoE_IAndE_L(TStream& tstream, Test& test);
	void DivideKNodeLargeIntoE_IAndE_L(TStream& tstream, Test& test, list<CNode*>& newKNodeLarge);
	void RecordOutlierInNode(TStream& tstream, Test& test, CNode* node);
	void CreateONrForObject(TStream& tstream, Test& test, int objId, CNode* node);
	void AddRhoNeihborForObject(TStream& tstream, Test& test, CObject* object, CNode* node, vector<int>& groupIndex, int& neighborNum, int& index);
	void AddRhoNeihborForObject(TStream& tstream, Test& test, CObject* object, CNode* node, vector<int>& groupIndex, int& neighborNum, int& beginIndex, int& endIndex);
	void ReCreatONrForObject(TStream& tstream, Test& test, int objId, CNode* node, int index);
	void AddNeighborInIntermediateNode(TStream& tstream, Test& test, CObject* object, CNode* node, vector<int>& groupIndex, int& neighborNum, int& posIndex, list<CNode*>& NodeList);
	void Update(TStream& tstream, Test& test);
	void AddNewObjectToRoot(TStream& tstream, Test& test, int objectBeginId, int objectEndId);
	void DeleteWholeSubtree(TStream& tstream, Test& test, CNode* node);
	void DeleteEmptyNode(TStream& tstream, Test& test, CNode* node);
	void FindKNodeInUpdate(TStream& tstream, Test& test);
	void CheckNewKnodeSet(TStream& tstream, Test& test, list<CNode*>& newKNodeSet);
	void FindKNodeForNewCreateNode(TStream& tstream, Test& test);
	void FindNewKNodeLargeInNewNode(TStream& tstream, Test& test, CNode* newNode, list<CNode*>& newKNodeLarge);
	void UpdateDealWarningObjectAndNode(TStream& tstream, Test& test);
	void FindKNodeForNewObject(TStream& tstream, Test& test, CNode* currentNode, int objId);
	void DealNewCreateNode(TStream& tstream, Test& test, CNode* newNode);
	void DealNewCreateNode(TStream& tstream, Test& test, CNode* newNode, NNLContainer& nnl_uk, NNLContainer& nnl_ukSmall);
	void DealE_INode(TStream& tstream, Test& test, CNode* temNode);
	void DealE_LNode(TStream& tstream, Test& test, CNode* temNode);
	void UpdateDealAlarmTimeKNodeLarge(TStream& tstream, Test& test, CNode* kNodeLarge);
	CNode* SearchUpwardsKNode(TStream& tstream, Test& test, CNode* temNode);
	void UpdateDealDescendantNode(TStream& tstream, Test& test, CNode* node);
	void ReCall_kForObject(TStream& tstream, Test& test, CObject* object);
	CNode* FindBelongNodeForObj(TStream& tstream, Test& test, int objId);
	int CalCurrentWindowObjectNum(TStream& tstream, Test& test);
	void ChangeR(TStream& tstream, Test& test, int oldOutlierNum, list<int>& l);
	void FindLeafSet(TStream& tstream, Test& test, unordered_set<int>& leafNodeIdSet, int& count);
	double FindKNNForOutlier(TStream& tstream, Test& test, int outlierId, CNode* targetNode);
	double FindKNNForOutlierInRiseR(TStream& tstream, Test& test, CObject* object, CNode* targetNode);
	void AddTargetNodeObjectToNeighborSet(TStream& tstream, Test& test, int outlierId, CNode* node, double& kR, multiset<double>& neighborSet);
	void AddTargetNodeObjectToNeighborSet(TStream& tstream, Test& test, CObject* object, CNode* node, double& kR, multimap<double, int>& neighborMap);
	void ReDealKNodeSmall(TStream& tstream, Test& test);
	void ReDealE_I(TStream& tstream, Test& test);
	void ClearSlideArray(TStream& tstream, Test& test);
	void ChangeR_ReFindOutlier(TStream& tstream, Test& test);
	void ReDealE_L(TStream& tstream, Test& test);
	void FindNeighborForNewObjectInKD_Tree(TStream& tstream, Test& test, int objectBeginId, int objectEndId);
	void FindInKD_Tree(TStream& tstream, Test& test, int objId);
	void DealObjInLargeLeafNode(TStream& tstream, Test& test, int objId, CNode* node);
	void ReDealKNodeLarge(TStream& tstream, Test& test);
	void DealExpeirSlide(TStream& tstream, Test& test);
	void DealE_LChildNode(TStream& tstream, Test& test, CNode* node);
	void DealE_LObjChildNode(TStream& tstream, Test& test, CNode* node);
	void Change_RDealE_LChildNode(TStream& tstream, Test& test, CNode* node);
	void Change_RCreateONrForObject(TStream& tstream, Test& test, CNode* node);

	int GetStartIndex(TStream& tstream, Test& test);
	int GetEndIndex(TStream& tstream, Test& test);
	void CheckInsetKDTreeForObject(TStream& tstream, Test& test, CObject* object);

	void RegularCleanUpSlideArray(int& deleteSlideArrayTag,int deleteEndTag);
	void OutputMemory();
	double GetInitDataSetMemory();
	double GetAverageMemory();
	double GetPeakMemory();
	short GetCountSlideNum();

	void DestroyRoot();
	void DestroySlideArray();
};

#endif 