#ifndef CSlide_h
#define CSlide_h

#include"head.h"
#include"CNode.h"
#include"CObject.h"


class CSlide
{
private:
	list<CObject*> warningObj;
	list<CNode*> warningNode;

public:
	CSlide(short& slideIdCount);
	CSlide();
	~CSlide();
	void AddObjToWarningObj(CObject* obj);
	void AddNodeToWarningNode(CNode* node);
	void Clear();


	int GetWarningNodeSize();
	int GetWarningObjSize();
	list<CObject*>& GetWarningObj();
	list<CNode*>& GetWarningNode();
	CObject* GetWarningObjById(int id);
	void EraseWarningObjById(int id);

};

#endif