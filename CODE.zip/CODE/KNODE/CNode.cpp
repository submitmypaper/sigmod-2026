#include "CNode.h"
#include"Count.h"
CNode::CNode(int id)
{
	this->nodeId = id;
}

CNode::~CNode()
{
    nodeId = -1;
}

void CNode::Reset(int newId)
{
    addr = -1;
    alarmTime = 0;
    tighteningl_kTime = 0;
    kNodeFlag = false;
    nodeId = newId;
    maintainDataNum = 0;
    sideLength = 0;
    l_k = DBL_MAX;
    unordered_map<short, CNode*>().swap(childList);
    for (auto* g : dataMap) {
        delete g;
    }
    vector<CObjGroup*>().swap(dataMap);
    parentNode = nullptr;
    vector<float>().swap(vecLeftDown);
    nnl_clear(nnl_uk);
    nnl_clear(nnl_ukSmall);
}

void CNode::SetNodeInformation(TStream& tstream, Test& test, short calAddr, vector<float> calVecLeftDown, double calSideLength)
{
    addr = calAddr;
    vecLeftDown = calVecLeftDown;
    sideLength = calSideLength;
    dataMap.resize(tstream.GetTotalSlideNum() / test.GetMapCount() + 1);
    for (int i = 0; i < dataMap.size(); ++i) {
        dataMap[i] = new CObjGroup;
    }
}

void CNode::SetMaintainDataNum(int num)
{
    this->maintainDataNum = num;
}

void CNode::SetKNodeFlag(bool state)
{
    this->kNodeFlag = state;
}

void CNode::Setnnl_uk(NNLContainer& nnl)
{
    this->nnl_uk = nnl;
}

void CNode::Setnnl_ukSmall(NNLContainer& nnl)
{
    this->nnl_ukSmall = nnl;
}

void CNode::AddObjToNodeFront(int index, int objId)
{
    this->dataMap[index]->AddObjToObjectListFront(objId);
}

void CNode::AddObjToNodeBack(int index, int objId)
{
    this->dataMap[index]->AddObjToObjectListBack(objId);
}

void CNode::CheckSplit(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool)
{
    int startIndex = GetStartIndex(tstream, test);
    int endIndex = GetEndIndex(tstream, test);
    if (this->maintainDataNum > test.GetSplitThreshold() &&
        CalDiagonalLength(test.GetVirtualDim()) >= (test.GetRhoMin() * test.GetR()))
    {
        short temAddr = 0;
        std::vector<int> vecAddr(test.GetVirtualDim(), 0);
        for (int i = startIndex; i < endIndex; ++i) {
            if (dataMap.size() == 0) {
                break;
            }
            if (!dataMap[i]) continue;
            for (int objId : dataMap[i]->GetObjectList()) {
                temAddr = FindAddrForDataObj(tstream, test, objId, vecAddr);
                FindChildNode(tstream, test, nodePool, temAddr, objId, vecAddr);
            }
        }
        this->ClearDataMap();
        for (const auto& child : this->childList) {
            CNode* c = child.second;
            if (c &&
                c->maintainDataNum > test.GetSplitThreshold() &&
                c->CalDiagonalLength(test.GetVirtualDim()) >= (test.GetRhoMin() * test.GetR()))
            {
                c->CheckSplit(tstream, test, nodePool);
            }
        }
    }
}

double CNode::CalDiagonalLength(int dimension)
{
    return sideLength * sqrt(dimension);
}

short CNode::FindAddrForDataObj(TStream& tstream, Test& test, int objId, vector<int>& vecAddr)
{
    double halfSideLength = this->GetSideLength() / 2;
    vector<float> objIdVec = tstream.GetVirtualValue(objId);
    for (int i = 0; i < test.GetVirtualDim(); ++i) {
        vecAddr[i] = (objIdVec[i] - vecLeftDown[i]) / halfSideLength;
    }
    return CalAddr(tstream, test, vecAddr);
}

short CNode::CalAddr(TStream& tstream, Test& test, vector<int>& vecAddr)
{
    short returnAddr = 0;
    for (int i = 0; i < vecAddr.size(); ++i) {
        returnAddr = (returnAddr << 1) | vecAddr[i];
    }
    return returnAddr;
}

void CNode::FindChildNode(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool, short calAddr, int objId, vector<int>& vecAddr)
{
    auto temPointer = this->childList.find(calAddr);
    if (temPointer == this->childList.end()) {
        double treeSide = this->GetSideLength() / 2;
        vector<float> temVecLeftDown(test.GetVirtualDim(), 0.0);
        for (int i = 0; i < test.GetVirtualDim(); ++i) {
            temVecLeftDown[i] = this->vecLeftDown[i] + vecAddr[i] * treeSide;
        }
        this->childList[calAddr] = nodePool();
        this->childList[calAddr]->SetNodeInformation(tstream, test, calAddr, temVecLeftDown, treeSide);
        this->childList[calAddr]->parentNode = this;
    }
    this->childList[calAddr]->AddMaintainDataNum();
    this->childList[calAddr]->AddObjToNodeBack(tstream.GetObjectSlideId(objId) / test.GetMapCount(), objId);
}

void CNode::AddMaintainDataNum()
{
    this->maintainDataNum++;
}

void CNode::ClearDataMap()
{
    for (CObjGroup*& group : dataMap) {   
        delete group;
        group = nullptr;
    }
    vector<CObjGroup*>().swap(dataMap);
}

void CNode::CreateNN_l(TStream& tstream, Test& test)
{
    double u_k = this->CalDiagonalLength(test.GetVirtualDim()) * 2;
    queue<CNode*> queNode;
    queue<CNode*> stackNode;
    stackNode.push(this);
    CNode* temNode = this;
    int lambda_k = lambda * test.GetK();
    double NNl_ukSmallSize_r = NNl_ukSmallSize * test.GetR();
    this->AddOwnLeafToNN_l(tstream, test);
    if ((nnl_size(this->nnl_uk) + nnl_size(this->nnl_ukSmall)) >= lambda_k) {
        return;
    }
    while (temNode->parentNode != nullptr) {
        temNode = temNode->parentNode;
        stackNode.push(temNode);
    }
    temNode = nullptr;
    while (!stackNode.empty()) {
        if (stackNode.front()->parentNode != nullptr) {
            temNode = stackNode.front()->parentNode;
            for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
                if ((*it).second->nodeId != stackNode.front()->nodeId && (*it).second->GetMaintainDataNum() != 0 && this->CalMinDisToNode(tstream, test, (*it).second) <= u_k) {
                    queNode.push((*it).second);
                }
            }
        }
        temNode = nullptr;
        stackNode.pop();
        while (!queNode.empty()) {
            temNode = queNode.front();
            if (this->CalMinDisToNode(tstream, test, temNode) <= u_k) {
                if (temNode->childList.size() != 0) {
                    for (auto child : temNode->childList) {
                        if (child.second->GetMaintainDataNum() != 0 && this->CalMinDisToNode(tstream,test,child.second) <= u_k) {
                            queNode.push(child.second);
                        }
                    }
                }
                else {
                    if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= NNl_ukSmallSize_r) {
                        if (temNode->GetMaintainDataNum() != 0) {
                            nnl_add(this->nnl_ukSmall, temNode->nodeId);
                        }
                    }
                    else {
                        if (temNode->GetMaintainDataNum() != 0) {
                            nnl_add(this->nnl_uk, temNode->nodeId);
                        }
                    }
                    if ((nnl_size(this->nnl_uk) + nnl_size(this->nnl_ukSmall)) >= lambda_k) {
                        return;
                    }
                }
            }
            temNode = nullptr;
            queNode.pop();
        }
    }
}

void CNode::AddOwnLeafToNN_l(TStream& tstream, Test& test)
{
    queue<CNode*> queNode;
    queNode.push(this);
    double u_k = this->CalDiagonalLength(test.GetVirtualDim()) * 2;
    CNode* temNode = nullptr;
    int lambda_k = lambda * test.GetK();
    double NNl_ukSmallSize_r = NNl_ukSmallSize * test.GetR();
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                if (child.second->GetMaintainDataNum() != 0 && this->CalMinDisToNode(tstream, test, child.second) <= u_k) {
                    queNode.push(child.second);
                }
            }
        }
        else {
            if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= NNl_ukSmallSize_r) {
                nnl_add(this->nnl_ukSmall, temNode->nodeId);
            }
            else {
                nnl_add(this->nnl_uk, temNode->nodeId);
            }
            if ((nnl_size(this->nnl_uk) + nnl_size(this->nnl_ukSmall)) >= lambda_k) {
                return;
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
}

double CNode::CalMinDisToNode(TStream& tstream, Test& test, CNode* node)
{
    int dim = test.GetVirtualDim();
    double distanceSquared = 0.0;
    for (int i = 0; i < dim; ++i) {
        if ((node->vecLeftDown[i] + node->sideLength) < this->vecLeftDown[i]) {
            distanceSquared += pow(this->vecLeftDown[i] - (node->vecLeftDown[i] + node->sideLength), 2);
        }
        else if ((this->vecLeftDown[i] + this->sideLength) < node->vecLeftDown[i]) {
            distanceSquared += pow(node->vecLeftDown[i] - (this->vecLeftDown[i] + this->sideLength), 2);
        }
    }
    return sqrt(distanceSquared);
}

void CNode::SetUpl_k(TStream& tstream, Test& test, std::function<CNode* (int)>& nodePool)
{
    queue<CNode*> queNode;
    queNode.push(this);
    CNode* temNode = nullptr;
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= test.GetL_kThreshold()) {
            temNode->Call_k(tstream, test, this->nnl_uk, this->nnl_ukSmall, nodePool);
        }
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                queNode.push(child.second);
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
}

void CNode::SetUpl_k(TStream& tstream, Test& test, std::function<CNode* (int)>& nodePool, NNLContainer& nnl_uk, NNLContainer& nnl_ukSmall)
{
    queue<CNode*> queNode;
    queNode.push(this);
    CNode* temNode = nullptr;
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= test.GetL_kThreshold()) {
            temNode->Call_k(tstream, test, nnl_uk, nnl_ukSmall, nodePool);
        }
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                queNode.push(child.second);
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
}

void CNode::Call_k(TStream& tstream, Test& test, NNLContainer& nnl_uk, NNLContainer& nnl_ukSmall, std::function<CNode* (int)>& nodePool)
{
    this->tighteningl_kTime = tstream.GetSlideBegin();
    multimap<double, int> knnMap;
    vector<int> indexVec(tstream.GetTotalSlideNum());
    double dis = 0;
    double minDis = DBL_MAX;
    bool flag = false;
    int startIndex = GetStartIndex(tstream, test);
    int endIndex = GetEndIndex(tstream, test);
    CNode* temNode = nullptr;
    for (int nodeId : nnl_ukSmall) {
        flag = false;
        temNode = nullptr;
        temNode = nodePool(nodeId);
        if (temNode != nullptr) {
            dis = this->CalMinDisToNode(tstream, test, temNode);
            if (dis < minDis) {
                if (temNode->GetChildNodeNum() != 0) {
                    continue;
                }
                for (int i = startIndex; i < endIndex; ++i) {
                    if (flag) {
                        break;
                    }
                    for (auto id : temNode->dataMap[i]->GetObjectList()) {
                        if (dis < minDis) {
                            knnMap.emplace(dis, i);
                            indexVec[i]++;
                            if (knnMap.size() > (test.GetK() + 1)) {
                                auto it = knnMap.end();
                                it--;
                                indexVec[it->second]--;
                                knnMap.erase(it);
                                minDis = knnMap.rbegin()->first;
                            }
                        }
                        else {
                            flag = true;
                            break;
                        }
                    }
                }
            }
        }
    }
    for (auto nodeId : nnl_uk) {
        flag = false;
        temNode = nullptr;
        temNode = nodePool(nodeId);
        if (temNode != nullptr) {
            dis = this->CalMinDisToNode(tstream, test, temNode);
            if (dis < minDis) {
                if (temNode->GetChildNodeNum() != 0) {
                    continue;
                }
                for (int i = startIndex; i < endIndex; ++i) {
                    if (flag) {
                        break;
                    }
                    for (auto id : temNode->dataMap[i]->GetObjectList()) {
                        if (dis < minDis) {
                            knnMap.emplace(dis, i);
                            indexVec[i]++;
                            if (knnMap.size() > (test.GetK() + 1)) {
                                auto it = knnMap.end();
                                it--;
                                indexVec[it->second]--;
                                knnMap.erase(it);
                                minDis = knnMap.rbegin()->first;
                            }
                        }
                        else {
                            flag = true;
                            break;
                        }
                    }
                }
            }
        }
    }
    if (knnMap.size() != 0) {
        this->l_k = knnMap.rbegin()->first;
    }
    else {
        this->l_k = DBL_MAX;
    }
    for (int i = startIndex; i < endIndex; ++i) {
        if (indexVec[i] != 0) {
            this->alarmTime = i * test.GetMapCount() + 1;
            break;
        }
    }
}

double CNode::CalMinDisBetweenObjAndNode(TStream& tstream, Test& test, int objId)
{
    double result = 0;
    vector<float> obj = tstream.GetVirtualValue(objId);
    for (int i = 0; i < test.GetVirtualDim(); ++i)
    {
        double temp1, temp2;
        temp1 = this->vecLeftDown[i];
        temp2 = this->vecLeftDown[i] + this->sideLength;
        if (obj[i] < temp1)
        {
            result += pow(abs(obj[i] - temp1), 2);
        }
        else if (obj[i] > temp2)
        {
            result += pow(abs(temp2 - obj[i]), 2);
        }
    }
    return sqrt(result);
}

double CNode::CalMaxDisBetweenObjAndNode(TStream& tstream, Test& test, int objId)
{
    double result = 0;
    vector<float> obj = tstream.GetVirtualValue(objId);
    for (int i = 0; i < test.GetVirtualDim(); ++i)
    {
        if (obj[i] < this->vecLeftDown[i]) {
            result += pow(this->vecLeftDown[i] + this->sideLength - obj[i], 2);
        }
        else if (obj[i] > (this->vecLeftDown[i] + this->sideLength)) {
            result += pow(obj[i] - this->vecLeftDown[i], 2);
        }
        else {
            double distToLeft = fabs(obj[i] - this->vecLeftDown[i]);
            double distToRight = fabs(obj[i] - this->vecLeftDown[i] - this->sideLength);
            result += pow(max(distToLeft, distToRight), 2);
        }
    }
    return sqrt(result);
}

void CNode::Tighteningl_k(TStream& tstream, Test& test)
{
    this->tighteningl_kTime = tstream.GetSlideBegin();
    queue<CNode*> queNode;
    CNode* temNode = this;
    double dis = 0;
    double minDis = DBL_MAX;
    double r = test.GetR();
    int k = test.GetK();
    unordered_multimap<double, CNode*> NNr;
    int totalObjnum = 0;
    totalObjnum += this->maintainDataNum;
    queue<CNode*> stackNode;
    stackNode.push(this);
    while (temNode->parentNode != nullptr) {
        temNode = temNode->parentNode;
        stackNode.push(temNode);
    }
    temNode = nullptr;
    while (!stackNode.empty()) {
        if (stackNode.front()->parentNode != nullptr) {
            temNode = stackNode.front()->parentNode;
            for (auto it = temNode->childList.begin(); it != temNode->childList.end(); ++it) {
                if ((*it).second->GetNodeId() != stackNode.front()->GetNodeId() && (*it).second->GetMaintainDataNum() != 0 && CalMinDisToNode(tstream, test, (*it).second) <= r) {
                    queNode.push((*it).second);
                }
            }
        }
        temNode = nullptr;
        stackNode.pop();
        while (!queNode.empty()) {
            temNode = queNode.front();
            dis = CalMinDisToNode(tstream, test, temNode);
            if (dis <= r) {
                if (temNode->CalDiagonalLength(test.GetVirtualDim()) == this->CalDiagonalLength(test.GetVirtualDim())) {
                    NNr.emplace(dis, temNode);
                    totalObjnum += temNode->maintainDataNum;
                }
                else {
                    if (temNode->childList.size() != 0) {
                        for (auto child : temNode->childList) {
                            if (CalMinDisToNode(tstream, test, child.second) <= r) {
                                queNode.push(child.second);
                            }
                        }
                    }
                    else {
                        NNr.emplace(dis, temNode);
                        totalObjnum += temNode->maintainDataNum;
                    }
                }
            }
            temNode = nullptr;
            queNode.pop();
        }
    }
    int startIndex = GetStartIndex(tstream, test);
    int endIndex = GetEndIndex(tstream, test);
    bool flag = false;
    if (totalObjnum >= (k + 1)) {
        multimap<double, int> knnMap;
        vector<int> indexVec(tstream.GetTotalSlideNum());
        this->Call_kInNode(tstream, test, knnMap, this, minDis, indexVec);
        for (auto nodeInNNr : NNr) {
            if (nodeInNNr.second->childList.size() != 0 && CalMinDisToNode(tstream, test, nodeInNNr.second) < minDis) {
                this->Call_kInNode(tstream, test, knnMap, nodeInNNr.second, minDis, indexVec);
            }
            else {
                flag = false;
                dis = CalMinDisToNode(tstream, test, nodeInNNr.second);
                if (dis < minDis) {
                    for (int i = startIndex; i < endIndex; ++i) {
                        if (flag) {
                            break;
                        }
                        for (auto id : nodeInNNr.second->dataMap[i]->GetObjectList()) {
                            if (dis < minDis) {
                                knnMap.emplace(dis, i);
                                indexVec[i]++;
                                if (knnMap.size() > (test.GetK() + 1)) {
                                    auto it = knnMap.end();
                                    it--;
                                    indexVec[it->second]--;
                                    knnMap.erase(it);
                                    minDis = knnMap.rbegin()->first;
                                }
                            }
                            else {
                                flag = true;
                                break;
                            }
                        }
                    }
                }
            }
        }
        this->l_k = knnMap.rbegin()->first;
        for (int i = startIndex; i < endIndex; ++i) {
            if (indexVec[i] != 0) {
                this->alarmTime = i * test.GetMapCount() + 1;
                break;
            }
        }
    }
    else {
        this->alarmTime = tstream.GetSlideBegin() + 1;
    }
}

void CNode::Call_kInNode(TStream& tstream, Test& test, multimap<double, int>& knnMap, CNode* nodeInNNr, double& minDis, vector<int>& indexVec)
{
    queue<CNode*> queNode;
    queNode.push(nodeInNNr);
    double dis = 0;
    CNode* temNode = nullptr;
    bool flag = false;
    int startIndex = GetStartIndex(tstream, test);
    int endIndex = GetEndIndex(tstream, test);
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                if (this->CalMinDisToNode(tstream, test, child.second) < minDis) {
                    queNode.push(child.second);
                }
            }
        }
        else {
            dis = this->CalMinDisToNode(tstream, test, temNode);
            flag = false;
            for (int i = startIndex; i < endIndex; ++i) {
                if (flag) {
                    break;
                }
                for (auto neighborId : temNode->dataMap[i]->GetObjectList()) {
                    if (dis < minDis) {
                        knnMap.emplace(dis, i);
                        indexVec[i]++;
                        if (knnMap.size() > (test.GetK() + 1)) {
                            auto it = knnMap.end();
                            it--;
                            indexVec[it->second]--;
                            knnMap.erase(it);
                            minDis = knnMap.rbegin()->first;
                        }
                    }
                    else {
                        flag = true;
                        break;
                    }
                }
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
}

void CNode::UpdateParentNodel_kAndAlarmTime(TStream& tstream, Test& test)
{
    if (this->kNodeFlag) {
        return;
    }
    CNode* temNode = this->parentNode;
    while (temNode != nullptr && !temNode->kNodeFlag) {
        if (temNode->l_k > this->l_k) {
            temNode->l_k = this->l_k;
            temNode->alarmTime = this->alarmTime;
            temNode = temNode->parentNode;
        }
        else {
            break;
        }

    }
    if (temNode != nullptr) {
        if (temNode->l_k > this->l_k) {
            temNode->l_k = this->l_k;
            temNode->alarmTime = this->alarmTime;
        }
    }
}

void CNode::UpdateNodeInformation(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool)
{
    stack<pair<CNode*, bool>> s;
    s.push(make_pair(this, false));
    bool visited;
    CNode* temNode = nullptr;
    int startIndex = GetStartIndex(tstream, test);
    int endIndex = GetEndIndex(tstream, test);
    while (!s.empty()) {
        temNode = s.top().first;
        visited = s.top().second;
        s.pop();
        if (temNode->childList.size() == 0) {
            temNode->dataMap[startIndex]->DeleteExpireObject(tstream.GetDataStreamBegin());
            temNode->maintainDataNum = 0;
            for (int i = startIndex; i < endIndex; ++i) {
                temNode->maintainDataNum += temNode->dataMap[i]->GetObjectListSize();
            }
            temNode->CheckSplit(tstream, test, nodePool);
            continue;
        }
        if (visited) {
            temNode->maintainDataNum = 0;
            for (auto child : temNode->childList) {
                if (child.second->maintainDataNum != 0) {
                    temNode->maintainDataNum += child.second->maintainDataNum;
                }
            }
        }
        else {
            s.push(make_pair(temNode, true));
            for (auto child : temNode->childList) {
                s.push(make_pair(child.second, false));
            }
        }
    }
}

void CNode::UpdateNodeInformation(TStream& tstream, Test& test, std::function<CNode* ()>& nodePool, int& deleteBegin)
{
    stack<pair<CNode*, bool>> s;
    s.push(make_pair(this, false));
    bool visited;
    CNode* temNode = nullptr;
    int startIndex = GetStartIndex(tstream, test);
    int endIndex = GetEndIndex(tstream, test);
    while (!s.empty()) {
        temNode = s.top().first;
        visited = s.top().second;
        s.pop();
        if (temNode->childList.size() == 0) {
            for (int i = deleteBegin; i <= startIndex; ++i) {
                temNode->dataMap[i]->DeleteExpireObject(tstream.GetDataStreamBegin());
            }
            temNode->maintainDataNum = 0;
            for (int i = startIndex; i < endIndex; ++i) {
                temNode->maintainDataNum += temNode->dataMap[i]->GetObjectListSize();
            }
            temNode->CheckSplit(tstream, test, nodePool);
            continue;
        }
        if (visited) {
            temNode->maintainDataNum = 0;
            for (auto child : temNode->childList) {
                if (child.second->maintainDataNum != 0) {
                    temNode->maintainDataNum += child.second->maintainDataNum;
                }
            }
        }
        else {
            s.push(make_pair(temNode, true));
            for (auto child : temNode->childList) {
                s.push(make_pair(child.second, false));
            }
        }
    }
}

bool CNode::UpwardFindOldKNode(TStream& tstream, Test& test, CNode*& oldKnode)
{
    CNode* temNode = this->GetParentNode();
    while (temNode->GetParentNode() != nullptr) {
        if (temNode->GetKNodeFlag()) {
            oldKnode = temNode;
            return true;
        }
        temNode = temNode->GetParentNode();
    }
    return false;
}

void CNode::Creatennl_ukByOldKnode(TStream& tstream, Test& test, CNode*& oldKnode, std::function<CNode* (int)>& nodePool)
{
    double dis;
    double u_k = 2 * this->CalDiagonalLength(test.GetVirtualDim());
    int lambda_k = lambda * test.GetK();
    double NNl_ukSmallSize_r = NNl_ukSmallSize * test.GetR();
    queue<CNode*> queNode;
    CNode* temNode = nullptr;
    auto& nnl_uk = oldKnode->Getnnl_ukSmall();
    for (auto it = nnl_uk.begin(); it != nnl_uk.end();) {
        temNode = nodePool(*it);
        if (temNode == nullptr) {
            it = nnl_uk.erase(it);
            continue;
        }
        dis = this->CalMinDisToNode(tstream, test, temNode);
        if (dis <= u_k) {
            if (temNode->GetChildNodeNum() != 0) {
                queNode.push(temNode);
            }
            else {
                nnl_add(this->nnl_ukSmall, temNode->GetNodeId());
            }
        }
        temNode = nullptr;
        it++;
    }
    nnl_uk = oldKnode->Getnnl_uk();
    for (auto it = nnl_uk.begin(); it != nnl_uk.end();) {
        temNode = nodePool(*it);
        if (temNode == nullptr) {
            it = nnl_uk.erase(it);
            continue;
        }
        dis = this->CalMinDisToNode(tstream, test, temNode);
        if (dis <= u_k) {
            if (temNode->GetChildNodeNum() != 0) {
                queNode.push(temNode);
            }
            else {
                nnl_add(this->nnl_uk, temNode->GetNodeId());
            }
        }
        temNode = nullptr;
        it++;
    }
    if ((nnl_size(this->nnl_uk) + nnl_size(this->nnl_ukSmall)) >= lambda_k) {
        return;
    }
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                if (this->CalMinDisToNode(tstream,test,child.second) <= u_k) {
                    queNode.push(child.second);
                }
            }
        }
        else {
            if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= NNl_ukSmallSize_r) {
                nnl_add(this->nnl_ukSmall, temNode->GetNodeId());
            }
            else {
                nnl_add(this->nnl_uk, temNode->GetNodeId());
            }
            if ((nnl_size(this->nnl_uk) + nnl_size(this->nnl_ukSmall)) >= lambda_k) {
                return;
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
}

void CNode::ChangeKNodeInformation(TStream& tstream, Test& test)
{
    queue<CNode*> queNode;
    queNode.push(this);
    CNode* temNode = nullptr;
    map<int, CNode*, greater<int>> map;
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                if (child.second->kNodeFlag) {
                    map.emplace((nnl_size(child.second->nnl_uk) + nnl_size(child.second->nnl_ukSmall)), child.second);
                    child.second->kNodeFlag = false;
                }
                else {
                    queNode.push(child.second);
                }
            }
        }
        else {
            if (temNode->kNodeFlag) {
                map.emplace((nnl_size(temNode->nnl_uk) + nnl_size(temNode->nnl_ukSmall)), temNode);
                temNode->kNodeFlag = false;
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
    if (map.size() == 0) {
        this->CreateNN_l(tstream, test);
    }
    else {
        this->nnl_uk = map.begin()->second->nnl_uk;
        this->nnl_ukSmall = map.begin()->second->nnl_ukSmall;
    }
}

void CNode::ChangeKNodeInformation(TStream& tstream, Test& test, bool flag)
{
    queue<CNode*> queNode;
    queNode.push(this);
    CNode* temNode = nullptr;
    while (!queNode.empty()) {
        temNode = queNode.front();
        if (temNode->childList.size() != 0) {
            for (auto child : temNode->childList) {
                if (child.second->kNodeFlag) {
                    child.second->kNodeFlag = false;
                }
                else {
                    queNode.push(child.second);
                }
            }
        }
        else {
            if (temNode->kNodeFlag) {
                temNode->kNodeFlag = false;
            }
        }
        temNode = nullptr;
        queNode.pop();
    }
}

int CNode::GetNodeId()
{
    return this->nodeId;
}

double CNode::GetSideLength()
{
    return this->sideLength;
}

int CNode::GetMaintainDataNum()
{
    return this->maintainDataNum;
}

int CNode::GetChildNodeNum()
{
    return this->childList.size();
}

unordered_map<short, CNode*>& CNode::GetChildList()
{
    return this->childList;
}

CObjGroup* CNode::GetCObjGroupById(int id)
{
    return this->dataMap[id];
}

double CNode::Getl_k()
{
    return this->l_k;
}

short CNode::GetAlarmTime()
{
    return this->alarmTime;
}

bool CNode::GetKNodeFlag()
{
    return this->kNodeFlag;
}

CNode* CNode::GetParentNode()
{
    return this->parentNode;
}

NNLContainer& CNode::Getnnl_uk()
{
    return this->nnl_uk;
}

NNLContainer& CNode::Getnnl_ukSmall()
{
    return this->nnl_ukSmall;
}

int CNode::GetStartIndex(TStream& tstream, Test& test)
{
    return tstream.GetSlideBegin() / test.GetMapCount();
}

int CNode::GetEndIndex(TStream& tstream, Test& test)
{
    return tstream.GetSlideTag() / test.GetMapCount() + 1;
}

CNode* CNode::GetChildNodeByAddr(TStream& tstream, Test& test, short calAddr)
{
    if (this->childList.find(calAddr) != this->childList.end()) {
        return childList.find(calAddr)->second;
    }
    else {
        return nullptr;
    }
}

int CNode::Getnnl_ukSize()
{
    return nnl_size(nnl_uk);
}

int CNode::Getnnl_ukSmallSize()
{
    return nnl_size(nnl_ukSmall);
}

short CNode::GetTighteningl_kTime()
{
    return this->tighteningl_kTime;
}

void CNode::ClearNNL()
{
    nnl_clear(this->nnl_uk);
    nnl_clear(this->nnl_ukSmall);
}

void CNode::ReleaseAllChildren(std::function<void(CNode*)>& nodePool)
{
    for (auto& kv : childList)
    {
        CNode* child = kv.second;
        if (!child) continue;
        child->ReleaseAllChildren(nodePool);
        nodePool(child);
    }
    unordered_map<short, CNode*>().swap(childList);
}

void CNode::UpdateInfo(TStream& tstream, Test& test)
{
    this->alarmTime = 0;
    this->tighteningl_kTime = 0;
    this->kNodeFlag = false;
    this->maintainDataNum = 0;
    this->l_k = DBL_MAX;
    if (this->dataMap.size() != 0) {
        for (auto* g : this->dataMap) {
            delete g;
        }
        vector<CObjGroup*>().swap(this->dataMap);
    }
    this->dataMap.resize(tstream.GetTotalSlideNum() / test.GetMapCount() + 1);
    for (int i = 0; i < dataMap.size(); ++i) {
        this->dataMap[i] = new CObjGroup;
    }
    nnl_clear(this->nnl_uk);
    nnl_clear(this->nnl_ukSmall);
}



