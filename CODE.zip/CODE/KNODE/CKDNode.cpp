#include "CKDNode.h"

CKDNode::CKDNode()
{
}

CKDNode::~CKDNode()
{
}

void CKDNode::SetKDNodeInfo(vector<float>& temVecLeftDown, vector<float>& temVecRightUp)
{
	this->vecLeftDown = temVecLeftDown;
	this->vecRightUp = temVecRightUp;
}

void CKDNode::reSetInfo()
{
    divideDimension = 0;
}

void CKDNode::SetMaintainNum()
{
    this->maintainNum = this->objects.size();
}

void CKDNode::ClearObjects()
{
	this->objects.clear();
}

void CKDNode::InitRealBoundsFromObjects(TStream& tstream, Test& test)
{
    int virDim = test.GetVirtualDim();
    realVecLeftDown.assign(virDim, std::numeric_limits<float>::infinity());
    realVecRightUp.assign(virDim, -std::numeric_limits<float>::infinity());
    for (auto obj : objects) {
        for (int d = 0; d < virDim; ++d) {
            float v = tstream.GetVirtualDataCoordinates(obj->GetObjectId(), d);
            realVecLeftDown[d] = min(realVecLeftDown[d], v);
            realVecRightUp[d] = max(realVecRightUp[d], v);
        }
    }
}

void CKDNode::CheckSplit(TStream& tstream, Test& test)
{
    int KD_ChildNum = test.GetkdTreeChildNum();
    this->InitRealBoundsFromObjects(tstream, test);
    if (objects.size() <= test.GetkdTree_SplitThreshold())
        return;
    int virDim = test.GetVirtualDim();
    int bestDim = 0;
    double maxSpread = 0.0;
    for (int i = 0; i < virDim; ++i) {
        double spread = realVecRightUp[i] - realVecLeftDown[i];
        if (spread > maxSpread) {
            maxSpread = spread;
            bestDim = i;
        }
    }
    if (maxSpread <= 0) return; 
    this->divideDimension = bestDim;
    double minVal = vecLeftDown[bestDim];
    double maxVal = vecRightUp[bestDim];
    double delta = (maxVal - minVal) / KD_ChildNum;
    children.resize(KD_ChildNum, nullptr);
    for (int i = 0; i < KD_ChildNum; ++i) {
        children[i] = new CKDNode();
        children[i]->parentNode = this;
        children[i]->vecLeftDown = vecLeftDown;
        children[i]->vecRightUp = vecRightUp;
        children[i]->vecLeftDown[bestDim] = minVal + i * delta;
        children[i]->vecRightUp[bestDim] = minVal + (i + 1) * delta;
    }
    vector<int> counts(KD_ChildNum, 0);
    for (auto obj : objects) {
        double val = tstream.GetVirtualDataCoordinates(obj->GetObjectId(), bestDim);
        int index = (int)((val - minVal) / delta);
        if (index >= KD_ChildNum) index = KD_ChildNum - 1; 
        children[index]->objects.push_back(obj);
        counts[index]++;
    }
    int nonEmptyCount = 0;
    for (int i = 0; i < KD_ChildNum; ++i) {
        if (!children[i]->objects.empty()) nonEmptyCount++;
    }
    if (nonEmptyCount <= 1) {
        for (int i = 0; i < KD_ChildNum; ++i) {
            delete children[i];
        }
        vector<CKDNode*>().swap(children);
        this->reSetInfo();
        return;
    }
    this->objects.clear();
    this->maintainNum = 0;
    for (int i = 0; i < KD_ChildNum; ++i) {
        if (!children[i]->objects.empty()) {
            children[i]->InitRealBoundsFromObjects(tstream, test);
            children[i]->SetMaintainNum();
            this->maintainNum += children[i]->maintainNum;
            if (children[i]->maintainNum > test.GetkdTree_SplitThreshold()) {
                children[i]->CheckSplit(tstream, test);
            }
        }
    }
}

void CKDNode::DeleteExpiredObject(TStream& tstream, Test& test)
{
    this->maintainNum = 0; 
    if (children.empty()) {
        for (auto it = objects.begin(); it != objects.end(); ) {
            if ((*it)->GetObjectId() < tstream.GetDataStreamBegin()) {
                delete* it;
                it = objects.erase(it);  
            }
            else {
                ++it;
            }
        }
        this->maintainNum = objects.size(); 

        if (this->maintainNum > test.GetkdTree_SplitThreshold()) {
            this->CheckSplit(tstream, test);
        }
        return;
    }
    for (CKDNode* child : children) {
        child->DeleteExpiredObject(tstream, test);
        this->maintainNum += child->maintainNum;
    }
    this->TryCollapse(tstream, test);
}

void CKDNode::DeleteExpiredObject(TStream& tstream, Test& test, std::function<void(CObject*)>& objectPool)
{
    this->maintainNum = 0;
    if (children.empty()) {
        for (auto it = objects.begin(); it != objects.end(); ) {
            if ((*it)->GetObjectId() < tstream.GetDataStreamBegin()) {
                objectPool(*it);
                it = objects.erase(it);
            }
            else {
                ++it;
            }
        }
        this->maintainNum = objects.size();

        if (this->maintainNum > test.GetkdTree_SplitThreshold()) {
            this->CheckSplit(tstream, test);
        }
        return;
    }
    for (CKDNode* child : children) {
        child->DeleteExpiredObject(tstream, test, objectPool);
        this->maintainNum += child->maintainNum;
    }
    this->TryCollapse(tstream, test);
}

void CKDNode::InsertObject(TStream& tstream, Test& test, CObject* object)
{
    int KD_ChildNum = test.GetkdTreeChildNum();
    if (realVecLeftDown.empty() || realVecRightUp.empty()) {
        realVecLeftDown = tstream.GetVirtualValue(object->GetObjectId());
        realVecRightUp = realVecLeftDown;
    }
    else {
        for (int i = 0; i < test.GetVirtualDim(); ++i) {
            float coord = tstream.GetVirtualDataCoordinates(object->GetObjectId(), i);
            realVecLeftDown[i] = min(realVecLeftDown[i], coord);
            realVecRightUp[i] = max(realVecRightUp[i], coord);
        }
    }

    if (children.empty()) {
        objects.push_back(object);
        maintainNum++;
        return;
    }

    double val = tstream.GetVirtualDataCoordinates(object->GetObjectId(), divideDimension);
    double dimMin = vecLeftDown[divideDimension];
    double dimMax = vecRightUp[divideDimension];
    double length = dimMax - dimMin;
    int childIndex = 0;
    if (length > 1e-12) {  
        double offset = val - dimMin;
        double ratio = offset / length;
        childIndex = static_cast<int>(ratio * KD_ChildNum);
        if (childIndex < 0) childIndex = 0;
        if (childIndex >= KD_ChildNum) childIndex = KD_ChildNum - 1;
    }
    else {
        childIndex = 0;
    }
    children[childIndex]->InsertObject(tstream, test, object);
    maintainNum++;
}

double CKDNode::CalMinDisBetweenNodeAndObj(TStream& tstream, Test& test, int objId)
{
    double distSq = 0.0;
    int vDim = test.GetVirtualDim();
    for (int i = 0; i < vDim; ++i) {
        double val = tstream.GetVirtualDataCoordinates(objId, i);
        if (val < this->realVecLeftDown[i])
            distSq += (this->realVecLeftDown[i] - val) * (this->realVecLeftDown[i] - val);
        else if (val > this->realVecRightUp[i])
            distSq += (val - this->realVecRightUp[i]) * (val - this->realVecRightUp[i]);
    }
    return sqrt(distSq);
}

int CKDNode::FindNeighbor(TStream& tstream, Test& test, int objId)
{
    int count = 0;
    if (objects.empty()) return count;
    int begin = tstream.GetDataStreamBegin();
    double r = test.GetR();
    for (auto it = objects.begin(); it != objects.end(); )
    {
        CObject* p = *it;
        if (p->GetObjectId() < begin) {
            
            delete p;
            it = objects.erase(it);
            ++count;
            continue;
        }
        double dis = tstream.CalTwoObjectRealDistance(objId, p->GetObjectId(), test.GetDim());
        if (dis <= r) {
            if (p->AddSucNeighborNum(tstream, test)) {
                delete p;
                it = objects.erase(it);
                ++count;
                continue;
            }
        }
        ++it;
    }
    return count;
}

int CKDNode::FindNeighbor(TStream& tstream, Test& test, int objId, std::function<void(CObject*)>& objectPool)
{
    int count = 0;
    if (objects.empty()) return count;
    int begin = tstream.GetDataStreamBegin();
    double r = test.GetR();
    for (auto it = objects.begin(); it != objects.end(); )
    {
        CObject* p = *it;
        if (p->GetObjectId() < begin) {
            objectPool(p);
            it = objects.erase(it);
            ++count;
            continue;
        }
        double dis = tstream.CalTwoObjectRealDistance(objId, p->GetObjectId(), test.GetDim());
        if (dis <= r) {
            if (p->AddSucNeighborNum(tstream, test)) {
                objectPool(p);
                it = objects.erase(it);
                ++count;
                continue;
            }
        }
        ++it;
    }
    return count;
}

void CKDNode::SubMaintainNum(int subNum)
{
    this->maintainNum -= subNum;
    if (this->maintainNum < 0) {
        this->maintainNum = 0;
    }
}

void CKDNode::AddMaintainNum()
{
    this->maintainNum++;
}

void CKDNode::TryCollapse(TStream& tstream, Test& test)
{

    if (children.empty()) return;

    for (auto child : children) {
        if (!child) return;
        if (!child->children.empty()) return;
    }

    int total = 0;
    for (auto child : children) {
        total += child->maintainNum;
    }
    if (total > test.GetkdTree_SplitThreshold()) return;

    for (auto child : children) {
        objects.splice(objects.end(), child->objects);
    }

    for (auto child : children) {
        delete child;
    }
    vector<CKDNode*>().swap(children);

    divideDimension = 0;

    maintainNum = total;
}

void CKDNode::ClearTree(bool keepPartitionBounds)
{
    for (auto& child : children) {
        if (child) {
            child->ClearTree(false);
            delete child;
            child = nullptr;
        }
    }
    std::vector<CKDNode*>().swap(children);
    for (auto& obj : objects) {
        delete obj;
        obj = nullptr;
    }
    objects.clear();
    parentNode = nullptr;
    divideDimension = 0;
    maintainNum = 0;
    std::vector<float>().swap(realVecLeftDown);
    std::vector<float>().swap(realVecRightUp);
    if (!keepPartitionBounds) {
        std::vector<float>().swap(vecLeftDown);
        std::vector<float>().swap(vecRightUp);
    }
}

void CKDNode::ClearTree(bool keepPartitionBounds, std::function<void(CObject*)>& objectPool)
{
    for (auto& child : children) {
        if (child) {
            child->ClearTree(false, objectPool);
            delete child;
            child = nullptr;
        }
    }
    std::vector<CKDNode*>().swap(children);
    for (auto& obj : objects) {
        objectPool(obj);
        obj = nullptr;
    }
    objects.clear();
    parentNode = nullptr;
    divideDimension = 0;
    maintainNum = 0;
    std::vector<float>().swap(realVecLeftDown);
    std::vector<float>().swap(realVecRightUp);
    if (!keepPartitionBounds) {
        std::vector<float>().swap(vecLeftDown);
        std::vector<float>().swap(vecRightUp);
    }
}

void CKDNode::ClearTree(bool keepPartitionBounds, int& deleteObjCount)
{
    for (auto& child : children) {
        if (child) {
            child->ClearTree(false, deleteObjCount);
            delete child;
            child = nullptr;
        }
    }
    std::vector<CKDNode*>().swap(children);
    for (auto& obj : objects) {
        delete obj;
        obj = nullptr;
        ++deleteObjCount;
    }
    objects.clear();
    parentNode = nullptr;
    divideDimension = 0;
    maintainNum = 0;
    std::vector<float>().swap(realVecLeftDown);
    std::vector<float>().swap(realVecRightUp);
    if (!keepPartitionBounds) {
        std::vector<float>().swap(vecLeftDown);
        std::vector<float>().swap(vecRightUp);
    }
}

void CKDNode::CollectValidObjectIDs(TStream& tstream, Test& test, list<int>& l)
{
    if (children.empty()) {
        for (auto obj : objects) {
            if (obj->GetObjectId() >= tstream.GetDataStreamBegin()) {
                l.push_back(obj->GetObjectId());
            }
        }
        return;
    }

    for (auto child : children) {
        if (child) {
            child->CollectValidObjectIDs(tstream, test, l);
        }
    }
}

void CKDNode::FindKD_TreeOutlierNum(TStream& tstream, Test& test, list<int>& l, int& count)
{
    if (children.empty()) {
        for (auto it = objects.begin(); it != objects.end(); ) {
            if ((*it)->GetObjectId() < tstream.GetDataStreamBegin()) {
                delete* it;
                it = objects.erase(it);  
            }
            else {
                if ((*it)->CheckOutlierState(tstream, test)) {
                    l.push_back((*it)->GetObjectId());
                    count++;
                }
                ++it;
            }
        }
        return;
    }
    for (auto child : children) {
        if (child) {
            child->FindKD_TreeOutlierNum(tstream, test, l, count);
        }
    }
}

void CKDNode::FindKD_TreeOutlierNum(TStream& tstream, Test& test, list<int>& l, int& count, std::function<void(CObject*)>& objectPool)
{
    if (children.empty()) {
        for (auto it = objects.begin(); it != objects.end(); ) {
            if ((*it)->GetObjectId() < tstream.GetDataStreamBegin()) {
                objectPool(*it);
                it = objects.erase(it);
            }
            else {
                if ((*it)->CheckOutlierState(tstream, test)) {
                    l.push_back((*it)->GetObjectId());
                    count++;
                }
                ++it;
            }
        }
        return;
    }
    for (auto child : children) {
        if (child) {
            child->FindKD_TreeOutlierNum(tstream, test, l, count, objectPool);
        }
    }
}

int CKDNode::GetMaintainNum()
{
    return this->maintainNum;
}

int CKDNode::GetObjectNum()
{
    return this->objects.size();
}

vector<CKDNode*>& CKDNode::GetChildren()
{
    return this->children;
}

CKDNode* CKDNode::GetParentNode()
{
    return this->parentNode;
}

void CKDNode::CheckObj(TStream& tstream, Test& test)
{
    int n = test.GetN() / test.GetMapCount() + 1;
    if (children.empty()) {
        for (auto obj : objects) {
            if (obj->GetNeighborCountSize() != n || obj->GetNeighborCountCapacity() != n) {
                cout << "wrong!" << endl;
            }
        }
        return;
    }

    for (auto child : children) {
        if (child) {
            child->CheckObj(tstream, test);
        }
    }
}
