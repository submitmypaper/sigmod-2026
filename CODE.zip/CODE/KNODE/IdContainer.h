#pragma once
#include <vector>


using NNLContainer = std::vector<int>;
