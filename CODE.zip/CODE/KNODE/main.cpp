#include"head.h"
#include"Test.h"
#include"TStream.h"
#include"CKNode.h"
void PrintLogMain(TStream& tstream, Test& test, CKNode& kN, double time1, double time2) {
	ofstream data;
	data.open("KNODELogFlie.txt", ofstream::app);
	data << "Dimension= " << test.GetDim() << " N= " << test.GetN() << " K= " << test.GetK() << endl;
	data << "InitTime= " << time1 << "s" << endl;
	data << "RunningTime= " << time2 << "s" << endl;
	data << "=====================================" << endl;
	data.close();
}
int main() {
	clock_t startTime, endTime, createTime;
	double initTime, updateTime;
	for (int j = 0; j < 5; ++j) {
		vector<Test> vecTest;
		Test t;
		TStream tstream;
		t.Init(vecTest, j);
		tstream.ReadFile(vecTest[0], j);
		for (int i = 1; i < vecTest.size(); ++i) {
			vecTest[i].SetVirtualDim(vecTest[0].GetVirtualDim());
		}
		for (int i = 0; i < vecTest.size(); ++i) {
			startTime = clock();
			CKNode knode;
			knode.Init(tstream, vecTest[i]);
			endTime = clock();
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			std::cout << std::fixed << std::setprecision(3);
			cout << "Init Time = " << initTime << 's' << endl;
			startTime = clock();
			knode.Update(tstream, vecTest[i]);
			endTime = clock();
			updateTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Running Time = " << updateTime << "s" << endl;
			PrintLogMain(tstream, vecTest[i], knode, initTime, updateTime);
		}
	}
	return 0;
}