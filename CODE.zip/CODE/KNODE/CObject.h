#ifndef CObject_h
#define CObject_h
#include"head.h"
#include"TStream.h"
#include"Test.h"
class CObject
{
private:
	int objectId;
	short alarmTime = 0;
	vector<unsigned char> neighborCount;
	unordered_set<int> onrNodeList;
	int belongNodeId = -1;
	int sucNeighborNum = 0;
	short slideFlag = 0;
public:
	CObject(int id);
	CObject();
	~CObject();
	void SetNeighborCountSize(int size);
	void SetAlarmTime(short time);
	void SetBelongNodeId(int nodeId);
	void SetObjectId(int id);
	void AddNodeToOnrNodeList(int nodeId);
	void AddNeighborCount(int groupId);
	void AddNeighborCount(int groupId, int addNum);
	int GetObjectId();
	short GetAlarmTime();
	bool GetONrNodeList(unordered_set<int>& temList);
	int GetBelongNodeId();

	bool AddSucNeighborNum(TStream& tstream, Test& test);
	int CalUnExpiredNeighborNum(TStream& tstream, Test& test);
	bool CheckOutlierState(TStream& tstream, Test& test);


	bool CheckNeedInsert(TStream& tstream, Test& test, vector<int>& groupIndex);

	int CalAlarmTime(TStream& tstream, Test& test, vector<int>& groupIndex);

	void SetNeighborCount(TStream& tstream, Test& test, multimap<double, int>& neighborMap);
	void ReleaseonrNodeList(TStream& tstream, Test& test);
	void Reset();

	void SetSlideFlag(short flag);
	short GetSlideFlag();
	void AddSucNeighborNumWithNum(int addNum);
	bool ChangeRReCheckNeedInsert(TStream& tstream, Test& test);
	int GetSucNeighborNum();
	int GetNeighborCountSize();
	int GetNeighborCountCapacity();
};

#endif