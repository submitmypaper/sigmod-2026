#include "CObject.h"
CObject::CObject(int id)
{
	this->objectId = id;
}

CObject::CObject()
{
}

CObject::~CObject()
{
	objectId = 0;
	double l_k = DBL_MAX;
	short alarmTime = 0;
	vector<unsigned char>().swap(neighborCount);
	unordered_set<int>().swap(onrNodeList);
	belongNodeId = -1;
}

void CObject::SetNeighborCountSize(int size)
{
	neighborCount.resize(size);
}

void CObject::SetAlarmTime(short time)
{
	this->alarmTime = time;
}

void CObject::SetBelongNodeId(int nodeId)
{
	this->belongNodeId = nodeId;
}

void CObject::SetObjectId(int id)
{
	this->objectId = id;
}

void CObject::AddNodeToOnrNodeList(int nodeId)
{
	onrNodeList.emplace(nodeId);
}

void CObject::AddNeighborCount(int groupId)
{
	int temp = neighborCount[groupId] + 1;
	if (temp > 255) {
		neighborCount[groupId] = 255;
	}
	else {
		neighborCount[groupId] = temp;
	}
}

void CObject::AddNeighborCount(int groupId, int addNum)
{
	int temp = neighborCount[groupId] + addNum;
	if (temp > 255) {
		neighborCount[groupId] = 255;
	}
	else {
		neighborCount[groupId] = temp;
	}
}

int CObject::GetObjectId()
{
	return this->objectId;
}

short CObject::GetAlarmTime()
{
	return this->alarmTime;
}

bool CObject::GetONrNodeList(unordered_set<int>& temList)
{
	if (this->onrNodeList.size() != 0) {
		temList = this->onrNodeList;
		return true;
	}
	else return false;
}

int CObject::GetBelongNodeId()
{
	return this->belongNodeId;
}

bool CObject::AddSucNeighborNum(TStream& tstream, Test& test)
{
	sucNeighborNum++;
	if(sucNeighborNum >= test.GetK()) return true;
	else return false;
}

int CObject::CalUnExpiredNeighborNum(TStream& tstream, Test& test)
{
	int curIndex = tstream.GetObjectSlideId(this->objectId) / test.GetMapCount() - this->slideFlag;
	int startIndex = tstream.GetSlideBegin() / test.GetMapCount() - this->slideFlag;
	int num = 0;
	for (int i = startIndex; i < curIndex; ++i) {
		num += neighborCount[i];
	}
	return num;
}

bool CObject::CheckOutlierState(TStream& tstream, Test& test)
{
	int preNeighborNum = this->CalUnExpiredNeighborNum(tstream, test);
	if ((preNeighborNum + this->sucNeighborNum) < test.GetK()) {
		return true;
	}
	else {
		return false;
	}
}

bool CObject::CheckNeedInsert(TStream& tstream, Test& test, vector<int>& groupIndex)
{
	int slideBegin = tstream.GetSlideBegin();
	int slideEnd = tstream.GetSlideTag();
	int midSlide = (slideBegin + slideEnd) / 2;
	int calAlarmTime = this->CalAlarmTime(tstream, test, groupIndex);
	if (calAlarmTime < midSlide) {
		return true;
	}
	else {
		return false;
	}
}

int CObject::CalAlarmTime(TStream& tstream, Test& test, vector<int>& groupIndex)
{
	int aTime = tstream.GetSlideBegin();
	int count = test.GetK();
	int startIndex = tstream.GetSlideBegin() / test.GetMapCount();
	int endIndex = tstream.GetSlideTag() / test.GetMapCount();
	int objectSlideId = tstream.GetObjectSlideId(this->GetObjectId()) / test.GetMapCount();
	int temp = 0;
	for (int i = endIndex; i >= startIndex; --i) {
		temp = i - this->GetSlideFlag();
		if (i < objectSlideId) {
			this->AddNeighborCount(temp, groupIndex[i]);
		}
		else {
			this->AddSucNeighborNumWithNum(groupIndex[i]);
		}
		count -= groupIndex[i];
		if (count <= 0) {
			if (i * test.GetMapCount() < tstream.GetObjectSlideId(this->GetObjectId())) {
				aTime = i * test.GetMapCount() + 1;
				this->SetAlarmTime(aTime);
			}
			else {
				aTime = tstream.GetTotalSlideNum() - 1;
				this->SetAlarmTime(aTime);
			}
			break;
		}
	}
	return aTime;
}

void CObject::SetNeighborCount(TStream& tstream, Test& test, multimap<double, int>& neighborMap)
{
	int temGroupId = 0;
	int ownSlideId = tstream.GetObjectSlideId(this->GetObjectId()) / test.GetMapCount() - this->slideFlag;
	for (auto it : neighborMap) {
		temGroupId = tstream.GetObjectSlideId(it.second) / test.GetMapCount() - this->slideFlag;
		if (temGroupId < ownSlideId) {
			this->AddNeighborCount(temGroupId);
		}
		else {
			this->AddSucNeighborNum(tstream, test);
		}
		
	}
}

void CObject::ReleaseonrNodeList(TStream& tstream, Test& test)
{
	unordered_set<int>().swap(this->onrNodeList);
}

void CObject::Reset()
{
	this->objectId = -1;
	this->alarmTime = 0;
	for (unsigned char& x : neighborCount) {
		x = 0;
	}
	unordered_set<int>().swap(onrNodeList);
	this->belongNodeId = -1;
	this->sucNeighborNum = 0;
	this->slideFlag = 0;
}

void CObject::SetSlideFlag(short flag)
{
	this->slideFlag = flag;
}

short CObject::GetSlideFlag()
{
	return this->slideFlag;
}

void CObject::AddSucNeighborNumWithNum(int addNum)
{
	this->sucNeighborNum += addNum;
}

bool CObject::ChangeRReCheckNeedInsert(TStream& tstream, Test& test)
{
	int slideBegin = tstream.GetSlideBegin();
	int slideEnd = tstream.GetSlideTag();
	int midSlide = (slideBegin + slideEnd) / 2;
	int needNum = test.GetK() - this->GetSucNeighborNum();
	if (needNum <= 0) {
		return false;
	}
	int curIndex = tstream.GetObjectSlideId(this->objectId) / test.GetMapCount() - this->slideFlag - 1;
	int startIndex = tstream.GetSlideBegin() / test.GetMapCount() - this->slideFlag;
	int temp = 0;
	for (int i = curIndex; i >= startIndex; --i) {
		needNum -= this->neighborCount[i];
		if (needNum <= 0) {
			temp = (i + this->slideFlag) * test.GetMapCount() + 1;
			if (temp < midSlide) {
				return true;
			}
			else {
				return false;
			}
		}
	}
	return false;
}

int CObject::GetSucNeighborNum()
{
	return this->sucNeighborNum;
}

int CObject::GetNeighborCountSize()
{
	return this->neighborCount.size();
}

int CObject::GetNeighborCountCapacity()
{
	return this->neighborCount.capacity();
}

