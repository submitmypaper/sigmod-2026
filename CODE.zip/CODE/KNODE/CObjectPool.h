#ifndef CObjectPool_h
#define CObjectPool_h
#include"head.h"
#include"CObject.h";
class CObjectPool {
private:
	queue<CObject*> objectPool;
public:
	CObjectPool();
	~CObjectPool();
	CObject* AcquireObject();
	void ReleaseObject(CObject* needReleaseObject);
	void InitializeObjectPool(int initializeSize);
	void DestroyObjectPool();
};



#endif