#pragma once

#include <algorithm>
#include <cassert>
#include <cstddef>
#include <iterator>
#include <type_traits>
#include <utility>


template <class Container>
inline void nnl_add(Container& c, int x) {
    c.push_back(x);
}

template <class Container>
inline void nnl_clear(Container& c) {
    Container().swap(c);
}

template <class Container>
inline std::size_t nnl_size(const Container& c) {
    return c.size();
}
