#pragma once
#include"head.h"
extern std::vector<std::vector<int>> tVec2;
extern std::vector<std::vector<int>> tVec3;
extern std::vector<std::vector<int>> tVec7;
extern std::vector<std::vector<int>> tVec10;
extern std::vector<std::vector<int>> tVec16EM;