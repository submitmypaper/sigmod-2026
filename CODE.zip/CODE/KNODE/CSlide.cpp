#include "CSlide.h"
CSlide::CSlide(short& slideIdCount)
{
}

CSlide::CSlide()
{
}

CSlide::~CSlide()
{
}

void CSlide::AddObjToWarningObj(CObject* obj)
{
	this->warningObj.push_back(obj);
}

void CSlide::AddNodeToWarningNode(CNode* node)
{
	this->warningNode.push_back(node);
}

void CSlide::Clear()
{
	warningObj.clear();
	warningNode.clear();
}

int CSlide::GetWarningNodeSize()
{
	return this->warningNode.size();
}

int CSlide::GetWarningObjSize()
{
	return this->warningObj.size();
}

list<CObject*>& CSlide::GetWarningObj()
{
	return this->warningObj;
}

list<CNode*>& CSlide::GetWarningNode()
{
	return this->warningNode;
}

CObject* CSlide::GetWarningObjById(int id)
{
	for (auto& obj : this->warningObj) {
		if (obj->GetObjectId() == id) {
			return obj;
		}
	}
	return nullptr;
}

void CSlide::EraseWarningObjById(int id)
{
	for (auto it = warningObj.begin(); it != warningObj.end(); ++it) {
		if ((*it)->GetObjectId() == id) {
			warningObj.erase(it);
			return;
		}
	}
}
