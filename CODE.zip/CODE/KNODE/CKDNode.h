#ifndef CKDNode_h
#define CKDNode_h
#include"head.h"
#include"TStream.h"
#include"Test.h"
#include"CObject.h"



class CKDNode {
private:
	list<CObject*> objects;
	vector<CKDNode*> children;
	CKDNode* parentNode = nullptr;
	vector<float> vecLeftDown;
	vector<float> vecRightUp;
	vector<float> realVecLeftDown;
	vector<float> realVecRightUp;
	int divideDimension = 0;
	int maintainNum = 0;
public:
	CKDNode();
	~CKDNode();
	void SetKDNodeInfo(vector<float>& temVecLeftDown, vector<float>& temVecRightUp);
	void reSetInfo();
	void SetMaintainNum();



	void ClearObjects();
	void InitRealBoundsFromObjects(TStream& tstream, Test& test);
	void CheckSplit(TStream& tstream, Test& test);
	void DeleteExpiredObject(TStream& tstream, Test& test);
	void DeleteExpiredObject(TStream& tstream, Test& test, std::function<void(CObject*)>& objectPool);
	void InsertObject(TStream& tstream, Test& test, CObject* object);
	double CalMinDisBetweenNodeAndObj(TStream& tstream, Test& test, int objId);
	int FindNeighbor(TStream& tstream, Test& test, int objId);
	int FindNeighbor(TStream& tstream, Test& test, int objId, std::function<void(CObject*)>& objectPool);
	void SubMaintainNum(int subNum);
	void AddMaintainNum();
	void TryCollapse(TStream& tstream, Test& test);
	void ClearTree(bool keepPartitionBounds);
	void ClearTree(bool keepPartitionBounds, std::function<void(CObject*)>& objectPool);
	void ClearTree(bool keepPartitionBounds, int& deleteObjCount);
	void CollectValidObjectIDs(TStream& tstream, Test& test, list<int>& l);
	void FindKD_TreeOutlierNum(TStream& tstream, Test& test, list<int>& l, int& count);
	void FindKD_TreeOutlierNum(TStream& tstream, Test& test, list<int>& l, int& count, std::function<void(CObject*)>& objectPool);

	int GetMaintainNum();
	int GetObjectNum();
	vector<CKDNode*>& GetChildren();
	CKDNode* GetParentNode();


	void CheckObj(TStream& tstream, Test& test);


};

#endif