#include "CObjGroup.h"

CObjGroup::CObjGroup()
{
}

CObjGroup::~CObjGroup()
{
}

void CObjGroup::AddObjToObjectListFront(int id)
{
    objectList.push_front(id);
}

void CObjGroup::AddObjToObjectListBack(int id)
{
    objectList.push_back(id);
}

list<int>& CObjGroup::GetObjectList()
{
	return this->objectList;
}

int CObjGroup::GetObjectListSize()
{
	return this->objectList.size();
}

void CObjGroup::DeleteExpireObject(int minObjectId)
{
    auto it = objectList.begin();
    while (it != objectList.end()) {
        if (*it < minObjectId) {
            objectList.erase(it, objectList.end());
            break;
        }
        ++it;
    }
}

void CObjGroup::ClearObjectList()
{
    this->objectList.clear();
}

