#include "Test.h"

Test::Test()
{
    this->dim = 0;
    this->K = 0;
    this->R = 0;
    this->N = 0;
    this->inFlow = 1;
    this->splitThreshold = 0;
    this->Rho = 0;
    this->rhoMin = 0.25;
    this->mapCount = 1;
    this->virtualDim = 0;
    this->l_kThreshold = 0;
}

Test::~Test()
{
}

int Test::GetDim()
{
    return this->dim;
}

int Test::GetK()
{
    return this->K;
}

double Test::GetR()
{
    return this->R;
}

int Test::GetInFlow()
{
    return this->inFlow;
}

int Test::GetN()
{
    return this->N;
}

int Test::GetSplitThreshold()
{
    return splitThreshold;
}

double Test::GetRho()
{
    return Rho;
}

short Test::GetMapCount()
{
    return mapCount;
}

double Test::GetRhoMin()
{
    return rhoMin;
}

int Test::GetVirtualDim()
{
    return virtualDim;
}

double Test::GetL_kThreshold()
{
    return l_kThreshold;
}

int Test::GetkdTree_SplitThreshold()
{
    return this->kdTree_SplitThreshold;
}

int Test::GetkdTreeChildNum()
{
    return this->kdTreeChildNum;
}

double Test::GetVirtualDimThreshold()
{
    return this->virtualDimThreshold;
}

void Test::SetVirtualDim(int vDim)
{
    this->virtualDim = vDim;
}

void Test::SetDim(int dim)
{
    this->dim = dim;
}

void Test::SetK(int k)
{
    this->K = k;
}

void Test::SetR(double r)
{
    this->R = r;
}

void Test::SetInFlow(int iF)
{
    this->inFlow = iF;
}

void Test::SetN(int n)
{
    this->N = n;
}

void Test::SetSplitThreshold(int threshold)
{
    this->splitThreshold = threshold;
}

void Test::SetRho(double inrho)
{
    this->Rho = inrho;
}

void Test::SetMapCount(short count)
{
    mapCount = count;
}

void Test::SetL_kThreshold()
{
    this->l_kThreshold = (1 + this->Rho) * this->R / 2;
}

void Test::SetkdTree_SplitThreshold(int threshold)
{
    this->kdTree_SplitThreshold = threshold;
}

void Test::SetkdTreeChildNum(int childNum)
{
    this->kdTreeChildNum = childNum;
}

void Test::SetVirtualDimThreshold(double threshold)
{
    this->virtualDimThreshold = threshold;
}

void Test::Init(int j)
{
    string fileName = "test" + to_string(j) + ".txt";
    FILE* fp = fopen(fileName.data(), "r");
    double temp;
    int i = 0;
    while (fscanf(fp, "%lf", &temp) != EOF) {
        if (i % 8 == 0) {
            this->dim = int(temp);
        }
        else if (i % 8 == 1) {
            this->R = double(temp);
        }
        else if (i % 8 == 2) {
            this->K = int(temp);
        }
        else if (i % 8 == 3) {
            this->N = int(temp);
        }
        else if (i % 8 == 4) {
            this->splitThreshold = int(temp);
        }
        else if (i % 8 == 5) {
            this->SetkdTree_SplitThreshold(int(temp));
        }
        else if (i % 8 == 6) {
            this->SetkdTreeChildNum(int(temp));
        }
        else if (i % 8 == 7) {
            this->SetMapCount(short(temp));
        }
        this->SetRho(0);
        if (this->GetDim() >= 16) {
            this->SetVirtualDimThreshold(0.7);
        }
        else {
            this->SetVirtualDimThreshold(0);
        }
        i++;
    }
    SetL_kThreshold();
}

void Test::Init(vector<Test>& vec, int j)
{
    string fileName = "test" + to_string(j) + ".txt";
    FILE* fp = fopen(fileName.data(), "r");
    double temp;
    int i = 0;
    Test t;
    while (fscanf(fp, "%lf", &temp) != EOF) {
        if (i % 4 == 0) {
            t.SetDim(int(temp));
        }
        else if (i % 4 == 1) {
            t.SetR(double(temp));
        }
        else if (i % 4 == 2) {
            t.SetK(int(temp));
        }
        else if (i % 4 == 3) {
            t.SetN(int(temp));
        }
        t.SetRho(0);
        if (t.GetDim() == 3) {
            SetThresholdWithTAO(t);
        }
        if (t.GetDim() == 2) {
            SetThresholdWithSTK(t);
        }
        if (t.GetDim() == 7) {
            SetThresholdWithHPC(t);
        }
        if (t.GetDim() == 10) {
            SetThresholdWithGAS(t);
        }
        if (t.GetDim() == 16) {
            SetThresholdWithEM(t);
        }
        i++;
        t.SetL_kThreshold();
        if (i % 4 == 0 && i != 0) {
            vec.push_back(t);
        }
    }
}

void Test::PrintLog(double init, double upd)
{
    ofstream data;
    data.open("log_KNode.txt", ofstream::app);

    if (data.is_open()) {
        switch (this->dim)
        {
        default:
            break;
        }

        data << "Dim = " << this->dim << endl;
        data << "N = " << this->N << endl;
        data << "K = " << this->K << endl;
        data << "R = " << this->R << endl;
        data << "SplitThreshold = " << this->splitThreshold << endl;
        data << "Rho = " << this->Rho << endl;
        data << "MapCount = " << this->mapCount << endl;
        data << "InitTime: " << init << "s" << endl;
        data << "Running Time: " << upd << "s" << endl;
        data.close();
    }
    else cout << data.goodbit << endl;    
}

void Test::SetThresholdWithTAO(Test& t)
{
    t.SetVirtualDimThreshold(0);
    if (t.GetK() == 50 && t.GetN() == 5) {
        t.SetSplitThreshold(tVec3[0][0]);
        t.SetkdTree_SplitThreshold(tVec3[0][1]);
        t.SetkdTreeChildNum(tVec3[0][2]);
        t.SetMapCount(short(tVec3[0][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 10) {
        t.SetSplitThreshold(tVec3[1][0]);
        t.SetkdTree_SplitThreshold(tVec3[1][1]);
        t.SetkdTreeChildNum(tVec3[1][2]);
        t.SetMapCount(short(tVec3[1][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec3[2][0]);
        t.SetkdTree_SplitThreshold(tVec3[2][1]);
        t.SetkdTreeChildNum(tVec3[2][2]);
        t.SetMapCount(short(tVec3[2][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 30) {
        t.SetSplitThreshold(tVec3[3][0]);
        t.SetkdTree_SplitThreshold(tVec3[3][1]);
        t.SetkdTreeChildNum(tVec3[3][2]);
        t.SetMapCount(short(tVec3[3][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 40) {
        t.SetSplitThreshold(tVec3[4][0]);
        t.SetkdTree_SplitThreshold(tVec3[4][1]);
        t.SetkdTreeChildNum(tVec3[4][2]);
        t.SetMapCount(short(tVec3[4][3]));
        return;
    }
    if (t.GetK() == 10 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec3[5][0]);
        t.SetkdTree_SplitThreshold(tVec3[5][1]);
        t.SetkdTreeChildNum(tVec3[5][2]);
        t.SetMapCount(short(tVec3[5][3]));
        return;
    }
    if (t.GetK() == 30 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec3[6][0]);
        t.SetkdTree_SplitThreshold(tVec3[6][1]);
        t.SetkdTreeChildNum(tVec3[6][2]);
        t.SetMapCount(short(tVec3[6][3]));
        return;
    }
    if (t.GetK() == 70 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec3[7][0]);
        t.SetkdTree_SplitThreshold(tVec3[7][1]);
        t.SetkdTreeChildNum(tVec3[7][2]);
        t.SetMapCount(short(tVec3[7][3]));
        return;
    }
    if (t.GetK() == 100 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec3[8][0]);
        t.SetkdTree_SplitThreshold(tVec3[8][1]);
        t.SetkdTreeChildNum(tVec3[8][2]);
        t.SetMapCount(short(tVec3[8][3]));
        return;
    }
    t.SetSplitThreshold(tVec3[9][0]);
    t.SetkdTree_SplitThreshold(tVec3[9][1]);
    t.SetkdTreeChildNum(tVec3[9][2]);
    t.SetMapCount(short(tVec3[9][3]));
    return;
}

void Test::SetThresholdWithSTK(Test& t)
{
    t.SetVirtualDimThreshold(0);
    if (t.GetK() == 50 && t.GetN() == 5) {
        t.SetSplitThreshold(tVec2[0][0]);
        t.SetkdTree_SplitThreshold(tVec2[0][1]);
        t.SetkdTreeChildNum(tVec2[0][2]);
        t.SetMapCount(short(tVec2[0][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 10) {
        t.SetSplitThreshold(tVec2[1][0]);
        t.SetkdTree_SplitThreshold(tVec2[1][1]);
        t.SetkdTreeChildNum(tVec2[1][2]);
        t.SetMapCount(short(tVec2[1][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec2[2][0]);
        t.SetkdTree_SplitThreshold(tVec2[2][1]);
        t.SetkdTreeChildNum(tVec2[2][2]);
        t.SetMapCount(short(tVec2[2][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 30) {
        t.SetSplitThreshold(tVec2[3][0]);
        t.SetkdTree_SplitThreshold(tVec2[3][1]);
        t.SetkdTreeChildNum(tVec2[3][2]);
        t.SetMapCount(short(tVec2[3][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 40) {
        t.SetSplitThreshold(tVec2[4][0]);
        t.SetkdTree_SplitThreshold(tVec2[4][1]);
        t.SetkdTreeChildNum(tVec2[4][2]);
        t.SetMapCount(short(tVec2[4][3]));
        return;
    }
    if (t.GetK() == 10 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec2[5][0]);
        t.SetkdTree_SplitThreshold(tVec2[5][1]);
        t.SetkdTreeChildNum(tVec2[5][2]);
        t.SetMapCount(short(tVec2[5][3]));
        return;
    }
    if (t.GetK() == 30 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec2[6][0]);
        t.SetkdTree_SplitThreshold(tVec2[6][1]);
        t.SetkdTreeChildNum(tVec2[6][2]);
        t.SetMapCount(short(tVec2[6][3]));
        return;
    }
    if (t.GetK() == 70 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec2[7][0]);
        t.SetkdTree_SplitThreshold(tVec2[7][1]);
        t.SetkdTreeChildNum(tVec2[7][2]);
        t.SetMapCount(short(tVec2[7][3]));
        return;
    }
    if (t.GetK() == 100 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec2[8][0]);
        t.SetkdTree_SplitThreshold(tVec2[8][1]);
        t.SetkdTreeChildNum(tVec2[8][2]);
        t.SetMapCount(short(tVec2[8][3]));
        return;
    }
    t.SetSplitThreshold(tVec2[9][0]);
    t.SetkdTree_SplitThreshold(tVec2[9][1]);
    t.SetkdTreeChildNum(tVec2[9][2]);
    t.SetMapCount(short(tVec2[9][3]));
    return;
}

void Test::SetThresholdWithHPC(Test& t)
{
    t.SetVirtualDimThreshold(0);
    if (t.GetK() == 50 && t.GetN() == 5) {
        t.SetSplitThreshold(tVec7[0][0]);
        t.SetkdTree_SplitThreshold(tVec7[0][1]);
        t.SetkdTreeChildNum(tVec7[0][2]);
        t.SetMapCount(short(tVec7[0][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 10) {
        t.SetSplitThreshold(tVec7[1][0]);
        t.SetkdTree_SplitThreshold(tVec7[1][1]);
        t.SetkdTreeChildNum(tVec7[1][2]);
        t.SetMapCount(short(tVec7[1][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec7[2][0]);
        t.SetkdTree_SplitThreshold(tVec7[2][1]);
        t.SetkdTreeChildNum(tVec7[2][2]);
        t.SetMapCount(short(tVec7[2][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 30) {
        t.SetSplitThreshold(tVec7[3][0]);
        t.SetkdTree_SplitThreshold(tVec7[3][1]);
        t.SetkdTreeChildNum(tVec7[3][2]);
        t.SetMapCount(short(tVec7[3][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 40) {
        t.SetSplitThreshold(tVec7[4][0]);
        t.SetkdTree_SplitThreshold(tVec7[4][1]);
        t.SetkdTreeChildNum(tVec7[4][2]);
        t.SetMapCount(short(tVec7[4][3]));
        return;
    }
    if (t.GetK() == 10 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec7[5][0]);
        t.SetkdTree_SplitThreshold(tVec7[5][1]);
        t.SetkdTreeChildNum(tVec7[5][2]);
        t.SetMapCount(short(tVec7[5][3]));
        return;
    }
    if (t.GetK() == 30 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec7[6][0]);
        t.SetkdTree_SplitThreshold(tVec7[6][1]);
        t.SetkdTreeChildNum(tVec7[6][2]);
        t.SetMapCount(short(tVec7[6][3]));
        return;
    }
    if (t.GetK() == 70 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec7[7][0]);
        t.SetkdTree_SplitThreshold(tVec7[7][1]);
        t.SetkdTreeChildNum(tVec7[7][2]);
        t.SetMapCount(short(tVec7[7][3]));
        return;
    }
    if (t.GetK() == 100 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec7[8][0]);
        t.SetkdTree_SplitThreshold(tVec7[8][1]);
        t.SetkdTreeChildNum(tVec7[8][2]);
        t.SetMapCount(short(tVec7[8][3]));
        return;
    }
    t.SetSplitThreshold(tVec7[9][0]);
    t.SetkdTree_SplitThreshold(tVec7[9][1]);
    t.SetkdTreeChildNum(tVec7[9][2]);
    t.SetMapCount(short(tVec7[9][3]));
    return;
}

void Test::SetThresholdWithGAS(Test& t)
{
    t.SetVirtualDimThreshold(0);
    if (t.GetK() == 50 && t.GetN() == 5) {
        t.SetSplitThreshold(tVec10[0][0]);
        t.SetkdTree_SplitThreshold(tVec10[0][1]);
        t.SetkdTreeChildNum(tVec10[0][2]);
        t.SetMapCount(short(tVec10[0][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 10) {
        t.SetSplitThreshold(tVec10[1][0]);
        t.SetkdTree_SplitThreshold(tVec10[1][1]);
        t.SetkdTreeChildNum(tVec10[1][2]);
        t.SetMapCount(short(tVec10[1][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec10[2][0]);
        t.SetkdTree_SplitThreshold(tVec10[2][1]);
        t.SetkdTreeChildNum(tVec10[2][2]);
        t.SetMapCount(short(tVec10[2][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 30) {
        t.SetSplitThreshold(tVec10[3][0]);
        t.SetkdTree_SplitThreshold(tVec10[3][1]);
        t.SetkdTreeChildNum(tVec10[3][2]);
        t.SetMapCount(short(tVec10[3][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 40) {
        t.SetSplitThreshold(tVec10[4][0]);
        t.SetkdTree_SplitThreshold(tVec10[4][1]);
        t.SetkdTreeChildNum(tVec10[4][2]);
        t.SetMapCount(short(tVec10[4][3]));
        return;
    }
    if (t.GetK() == 10 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec10[5][0]);
        t.SetkdTree_SplitThreshold(tVec10[5][1]);
        t.SetkdTreeChildNum(tVec10[5][2]);
        t.SetMapCount(short(tVec10[5][3]));
        return;
    }
    if (t.GetK() == 30 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec10[6][0]);
        t.SetkdTree_SplitThreshold(tVec10[6][1]);
        t.SetkdTreeChildNum(tVec10[6][2]);
        t.SetMapCount(short(tVec10[6][3]));
        return;
    }
    if (t.GetK() == 70 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec10[7][0]);
        t.SetkdTree_SplitThreshold(tVec10[7][1]);
        t.SetkdTreeChildNum(tVec10[7][2]);
        t.SetMapCount(short(tVec10[7][3]));
        return;
    }
    if (t.GetK() == 100 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec10[8][0]);
        t.SetkdTree_SplitThreshold(tVec10[8][1]);
        t.SetkdTreeChildNum(tVec10[8][2]);
        t.SetMapCount(short(tVec10[8][3]));
        return;
    }
    t.SetSplitThreshold(tVec10[9][0]);
    t.SetkdTree_SplitThreshold(tVec10[9][1]);
    t.SetkdTreeChildNum(tVec10[9][2]);
    t.SetMapCount(short(tVec10[9][3]));
    return;
}

void Test::SetThresholdWithEM(Test& t)
{
    t.SetVirtualDimThreshold(0.7);
    if (t.GetK() == 50 && t.GetN() == 5) {
        t.SetSplitThreshold(tVec16EM[0][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[0][1]);
        t.SetkdTreeChildNum(tVec16EM[0][2]);
        t.SetMapCount(short(tVec16EM[0][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 10) {
        t.SetSplitThreshold(tVec16EM[1][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[1][1]);
        t.SetkdTreeChildNum(tVec16EM[1][2]);
        t.SetMapCount(short(tVec16EM[1][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec16EM[2][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[2][1]);
        t.SetkdTreeChildNum(tVec16EM[2][2]);
        t.SetMapCount(short(tVec16EM[2][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 30) {
        t.SetSplitThreshold(tVec16EM[3][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[3][1]);
        t.SetkdTreeChildNum(tVec16EM[3][2]);
        t.SetMapCount(short(tVec16EM[3][3]));
        return;
    }
    if (t.GetK() == 50 && t.GetN() == 40) {
        t.SetSplitThreshold(tVec16EM[4][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[4][1]);
        t.SetkdTreeChildNum(tVec16EM[4][2]);
        t.SetMapCount(short(tVec16EM[4][3]));
        return;
    }
    if (t.GetK() == 10 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec16EM[5][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[5][1]);
        t.SetkdTreeChildNum(tVec16EM[5][2]);
        t.SetMapCount(short(tVec16EM[5][3]));
        return;
    }
    if (t.GetK() == 30 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec16EM[6][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[6][1]);
        t.SetkdTreeChildNum(tVec16EM[6][2]);
        t.SetMapCount(short(tVec16EM[6][3]));
        return;
    }
    if (t.GetK() == 70 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec16EM[7][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[7][1]);
        t.SetkdTreeChildNum(tVec16EM[7][2]);
        t.SetMapCount(short(tVec16EM[7][3]));
        return;
    }
    if (t.GetK() == 100 && t.GetN() == 20) {
        t.SetSplitThreshold(tVec16EM[8][0]);
        t.SetkdTree_SplitThreshold(tVec16EM[8][1]);
        t.SetkdTreeChildNum(tVec16EM[8][2]);
        t.SetMapCount(short(tVec16EM[8][3]));
        return;
    }
    t.SetSplitThreshold(tVec16EM[9][0]);
    t.SetkdTree_SplitThreshold(tVec16EM[9][1]);
    t.SetkdTreeChildNum(tVec16EM[9][2]);
    t.SetMapCount(short(tVec16EM[9][3]));
    return;
}
