#include "CKNode.h"
#include"Count.h"
#include <windows.h>
#include <psapi.h>
#pragma comment(lib, "psapi.lib")

double getProcessMemoryMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	GetProcessMemoryInfo(GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc));

	return pmc.WorkingSetSize / (1024.0 * 1024.0);
}

double getPeakProcessMemoryMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	if (!GetProcessMemoryInfo(
		GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc)))
	{
		return 0.0;
	}

	return pmc.PeakWorkingSetSize / (1024.0 * 1024.0);
}

double getPrivateUsageMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	GetProcessMemoryInfo(
		GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc)
	);
	return pmc.PrivateUsage / (1024.0 * 1024.0);
}

CKNode::CKNode()
{
}

CKNode::~CKNode()
{
	DestroyRoot();

	DestroySlideArray();
	kdTreeRoot->ClearTree(true);
	delete kdTreeRoot;
	kdTreeRoot = nullptr;
	nodePool.DestroyNodePool();
	objectPool.DestroyObjectPool();
	kNodeSmall.clear();
	kNodeLarge.clear();
	unordered_map<int, CNode*>().swap(E_I);
	unordered_map<int, CNode*>().swap(E_L);
	unordered_map<int, CNode*>().swap(changeRMap);
	unordered_map<int, CNode*>().swap(newCreateNodeMap);
	unordered_map<int, CNode*>().swap(newObjectInsertNodeMap);

}

void CKNode::Init(TStream& tstream, Test& test)
{
	initDataSetMemory = getProcessMemoryMB();
	int calPoolCapacity = 10000;
	nodePool.Initialize(calPoolCapacity);
	objectPool.InitializeObjectPool(100);
	InitSlideArray(tstream, test);
	InitRoot(tstream, test);
	FindOutlier(tstream, test);
	kdTreeRoot->SetMaintainNum();
	kdTreeRoot->CheckSplit(tstream, test);

	int currentObjectNum = CalCurrentWindowObjectNum(tstream, test);
	int lowerBound = ChangeRLowerBound * currentObjectNum;
	int upperBound = ChangeRUpperBound * currentObjectNum;
	list<int> kdTreeOutlier;
	int count = 0;
	kdTreeRoot->FindKD_TreeOutlierNum(tstream, test, kdTreeOutlier, count);
	int outlierNum = changeRMap.size() + count;
	if (outlierNum < lowerBound || outlierNum > upperBound) {
		ChangeR(tstream, test, outlierNum, kdTreeOutlier);
	}
	averageMemory.push_back(getProcessMemoryMB());
}

void CKNode::Init(TStream& tstream, Test& test, int dataBegin, int dataEnd)
{
	ClearSlideArray(tstream, test);
	kdTreeRoot->ClearTree(true);
	std::function<void(CNode*)> release_node_pointer = [this](CNode* needReleaseNode) {
		if (needReleaseNode)
		{
			nodePool.ReleaseNode(needReleaseNode);
		}
	};
	this->root->ReleaseAllChildren(release_node_pointer);
	this->root->UpdateInfo(tstream, test);
	int totalObjNum = dataEnd - dataBegin;
	for (int i = dataBegin; i < dataEnd; ++i) {
		this->root->AddObjToNodeFront(tstream.GetObjectSlideId(i) / test.GetMapCount(), i);
	}
	this->root->SetMaintainDataNum(totalObjNum);
	std::function<CNode* ()> get_node_pointer = [this]() {
		return nodePool.AcquireNode();
		};
	this->root->CheckSplit(tstream, test, get_node_pointer);
	kNodeLarge.clear();
	kNodeSmall.clear();
	unordered_map<int, CNode*>().swap(E_I);
	unordered_map<int, CNode*>().swap(E_L);
	FindOutlier(tstream, test);
	kdTreeRoot->SetMaintainNum();
	kdTreeRoot->CheckSplit(tstream, test);

	int currentObjectNum = CalCurrentWindowObjectNum(tstream, test);
	int lowerBound = ChangeRLowerBound * currentObjectNum;
	int upperBound = ChangeRUpperBound * currentObjectNum;
	list<int> kdTreeOutlier;
	int count = 0;
	kdTreeRoot->FindKD_TreeOutlierNum(tstream, test, kdTreeOutlier, count);
	int outlierNum = changeRMap.size() + count;
	if (outlierNum < lowerBound || outlierNum > upperBound) {
		ChangeR(tstream, test, outlierNum, kdTreeOutlier);
	}
	averageMemory.push_back(getProcessMemoryMB());
}

void CKNode::InitSlideArray(TStream& tstream, Test& test)
{
	slideArray.resize(tstream.GetTotalSlideNum() + 1);
	for (int i = 0; i <= tstream.GetTotalSlideNum(); ++i) {
		slideArray[i] = new CSlide();  
	}
}

void CKNode::InitRoot(TStream& tstream, Test& test)
{
	int vDim = test.GetVirtualDim();
	double side = tstream.GetMaxSideLength();
	vector<float> calVecLeftDown(vDim, 0.0);
	vector<float> calVecRightUp(vDim, 0.0);
	for (int i = 0; i < vDim; ++i) {
		calVecLeftDown[i] = tstream.GetEveryDimensionMinAndMax(i, 0);
		calVecRightUp[i] = tstream.GetEveryDimensionMinAndMax(i, 1);
	}
	root = nodePool.AcquireNode();
	root->SetNodeInformation(tstream, test, -1, calVecLeftDown, side);
	kdTreeRoot = new CKDNode();
	kdTreeRoot->SetKDNodeInfo(calVecLeftDown, calVecRightUp);
	AddObjToRoot(tstream, test);
}

void CKNode::AddObjToRoot(TStream& tstream, Test& test)
{
	int firstWindowObjNum = 0;
	for (int i = 0; i < test.GetN(); ++i) {
		firstWindowObjNum += tstream.GetS_Change(i);
	}
	int dataBack = 0;
	int temp = 0;
	for (int i = 0; i < test.GetN(); ++i) {
		temp = dataBack;
		dataBack += tstream.GetS_Change(i);
		for (int j = temp; j < dataBack; ++j) {
			this->root->AddObjToNodeFront(i / test.GetMapCount(), j);
		}
	}
	tstream.SetDataStreamBegin(0);
	tstream.SetDataStreamTag(firstWindowObjNum);
	tstream.SetSlideBegin(0);
	tstream.SetSlideTag(test.GetN());
	this->root->SetMaintainDataNum(firstWindowObjNum);
	std::function<CNode*()> get_node_pointer = [this](){
		return nodePool.AcquireNode();
	};
	this->root->CheckSplit(tstream, test, get_node_pointer);
}

void CKNode::FindOutlier(TStream& tstream, Test& test)
{
	FindKNodeSet(tstream, test);
	DivideKNodeLargeIntoE_IAndE_L(tstream, test);
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
	};
	for (auto& kNodeS : kNodeSmall) {
		kNodeS->SetUpl_k(tstream, test, get_node_pointer_by_nodeid);
		slideArray[kNodeS->GetAlarmTime()]->AddNodeToWarningNode(kNodeS);
	}
	for (auto& kNodeL : kNodeLarge) {
		kNodeL->SetUpl_k(tstream, test, get_node_pointer_by_nodeid);
	}
	double r = test.GetR();
	for (auto& node : E_I) {
		if (node.second->Getl_k() > r) {
			node.second->Tighteningl_k(tstream, test);
			if (node.second->Getl_k() > r) {
				slideArray[tstream.GetSlideBegin() + 1]->AddNodeToWarningNode(node.second);
				RecordOutlierInNode(tstream, test, node.second);
			}
			else {
				slideArray[node.second->GetAlarmTime()]->AddNodeToWarningNode(node.second);
			}
			node.second->UpdateParentNodel_kAndAlarmTime(tstream, test);
		}
	}
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	for (auto& node : E_L) {
		if (node.second->CalDiagonalLength(test.GetVirtualDim()) > test.GetL_kThreshold()) {
			for (int i = startIndex; i < endIndex; ++i) {
				for (auto& objId : node.second->GetCObjGroupById(i)->GetObjectList()) {
					DealObjInLargeLeafNode(tstream, test, objId, node.second);
				}
			}
		}
		else {
			if (node.second->Getl_k() > r || ((node.second->Getl_k() + 2 * node.second->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r)) {
				node.second->Tighteningl_k(tstream, test);
				if (node.second->Getl_k() > r) {
					slideArray[tstream.GetSlideBegin() + 1]->AddNodeToWarningNode(node.second);
					RecordOutlierInNode(tstream, test, node.second);
					continue;
				}
				else if ((node.second->Getl_k() + 2 * node.second->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r) {
					for (int i = startIndex; i < endIndex; ++i) {
						for (auto& objId : node.second->GetCObjGroupById(i)->GetObjectList()) {
							CreateONrForObject(tstream, test, objId, node.second);
						}
					}
				}
				else {
					slideArray[node.second->GetAlarmTime()]->AddNodeToWarningNode(node.second);
				}
				node.second->UpdateParentNodel_kAndAlarmTime(tstream, test);
			}
			else {
				slideArray[node.second->GetAlarmTime()]->AddNodeToWarningNode(node.second);
			}
		}
	}
}

void CKNode::FindKNodeSet(TStream& tstream, Test& test)
{
	queue<CNode*> queNode;
	queNode.push(root);
	CNode* temNode = nullptr;
	int k = test.GetK();
	double threshold = test.GetL_kThreshold();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetMaintainDataNum() > k) {
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					queNode.push(child.second);
				}
			}
		}
		else {
			temNode->SetKNodeFlag(true);
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
				kNodeSmall.push_back(temNode);
				temNode->CreateNN_l(tstream, test);
			}
			else {
				kNodeLarge.push_back(temNode);
				temNode->CreateNN_l(tstream, test);
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::DivideKNodeLargeIntoE_IAndE_L(TStream& tstream, Test& test)
{
	CNode* temNode = nullptr;
	double threshold = test.GetR() * test.GetRho() / 2;
	for (auto knode : kNodeLarge) {
		queue<CNode*> queKNode;
		queKNode.push(knode);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->GetChildNodeNum() == 0) {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					if (temNode->GetMaintainDataNum() != 0) {
						E_L.emplace(temNode->GetNodeId(), temNode);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			else {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					for (auto child : temNode->GetChildList()) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			queKNode.pop();
		}
	}
}

void CKNode::RecordOutlierInNode(TStream& tstream, Test& test, CNode* node)
{
	queue<CNode*> queNode;
	if (node->GetMaintainDataNum() == 0) {
		return;
	}
	queNode.push(node);
	CNode* temNode = nullptr;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetChildNodeNum() != 0) {
			for (auto child : temNode->GetChildList()) {
				if (child.second->GetMaintainDataNum() != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (int i = startIndex; i < endIndex; ++i) {
				for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
					if (objId < tstream.GetDataStreamBegin()) {
						break;
					}
					changeRMap.emplace(objId, temNode);
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::CreateONrForObject(TStream& tstream, Test& test, int objId, CNode* node)
{
	CObject* object = objectPool.AcquireObject();
	object->SetObjectId(objId);
	object->SetBelongNodeId(node->GetNodeId());
	object->SetNeighborCountSize(test.GetN() / test.GetMapCount() + 1);
	object->SetSlideFlag(tstream.GetSlideBegin() / test.GetMapCount());
	double r = test.GetR();
	int k = test.GetK();
	vector<int> groupIndex(tstream.GetTotalSlideNum() / test.GetMapCount() + 1);
	int neighborNum = 0;
	int posIndex = (tstream.GetSlideBegin() + tstream.GetSlideTag()) / 2 / test.GetMapCount();
	CNode* kNode = node;
	double dis1 = 0, dis2 = 0;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
	};
	while (kNode != nullptr) {
		if (kNode->GetKNodeFlag()) {
			break;
		}
		else {
			kNode = kNode->GetParentNode();
		}
	}
	if (kNode == nullptr) {
		kNode = node;
		node->CreateNN_l(tstream, test);
		node->SetUpl_k(tstream, test, get_node_pointer_by_nodeid);
	}
	CNode* temNode = nullptr;
	auto& nnl_ukFromKNode = kNode->Getnnl_ukSmall();
	for (auto it = nnl_ukFromKNode.begin(); it != nnl_ukFromKNode.end();) {
		if (neighborNum >= k) {
			break;
		}
		temNode = nodePool.GetNodeByNodeId(*it);
		if (temNode != nullptr) {
			dis1 = temNode->CalMinDisBetweenObjAndNode(tstream, test, objId);
			dis2 = temNode->CalMaxDisBetweenObjAndNode(tstream, test, objId);
			if (dis1 <= r && dis2 <= (1 + test.GetRho()) * r) {
				object->AddNodeToOnrNodeList(*it);
				AddRhoNeihborForObject(tstream, test, object, temNode, groupIndex, neighborNum, posIndex);
			}
		}
		else {
			it = nnl_ukFromKNode.erase(it);
			continue;
		}
		it++;
		temNode = nullptr;
	}
	kNode->Setnnl_ukSmall(nnl_ukFromKNode);
	nnl_ukFromKNode = kNode->Getnnl_uk();
	for (auto it = nnl_ukFromKNode.begin(); it != nnl_ukFromKNode.end();) {
		if (neighborNum >= k) {
			break;
		}
		temNode = nodePool.GetNodeByNodeId(*it);
		if (temNode != nullptr) {
			dis1 = temNode->CalMinDisBetweenObjAndNode(tstream, test, objId);
			dis2 = temNode->CalMaxDisBetweenObjAndNode(tstream, test, objId);
			if (dis1 <= r && dis2 <= (1 + test.GetRho()) * r) {
				object->AddNodeToOnrNodeList(*it);
				AddRhoNeihborForObject(tstream, test, object, temNode, groupIndex, neighborNum, posIndex);
			}
		}
		else {
			it = nnl_ukFromKNode.erase(it);
			continue;
		}
		it++;
		temNode = nullptr;
	}
	kNode->Setnnl_uk(nnl_ukFromKNode);
	if (neighborNum < k) {
		objectPool.ReleaseObject(object);
		ReCreatONrForObject(tstream, test, objId, node, posIndex);
	}
	else {
		if (object->CheckNeedInsert(tstream, test, groupIndex)) {
			CheckInsetKDTreeForObject(tstream, test, object);
		}
		else {
			objectPool.ReleaseObject(object);
		}
	}
}

void CKNode::DivideKNodeLargeIntoE_IAndE_L(TStream& tstream, Test& test, list<CNode*>& newKNodeLarge)
{
	CNode* temNode = nullptr;
	double threshold = test.GetR() * test.GetRho() / 2;
	queue<CNode*> queKNode;
	for (auto KNode : newKNodeLarge) {
		queKNode.push(KNode);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->GetChildNodeNum() == 0) {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					if (temNode->GetMaintainDataNum() != 0) {
						E_L.emplace(temNode->GetNodeId(), temNode);
					}
				}
				else {
					if (temNode->GetChildNodeNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);

					}
				}
			}
			else {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					for (auto child : temNode->GetChildList()) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			temNode = nullptr;
			queKNode.pop();
		}
	}
}

void CKNode::AddRhoNeihborForObject(TStream& tstream, Test& test, CObject* object, CNode* node, vector<int>& groupIndex, int& neighborNum, int& index)
{
	queue<CNode*> queNode;
	queNode.push(node);
	CNode* temNode = nullptr;
	int windowBegin = tstream.GetDataStreamBegin();
	int endIndex = GetEndIndex(tstream, test);
	list<int> temObjList;
	while (!queNode.empty()) {
		if (neighborNum >= (test.GetK() + 0)) {
			return;
		}
		temNode = queNode.front();
		if (temNode->GetChildNodeNum() != 0) {
			for (auto child : temNode->GetChildList()) {
				if (nodePool.GetNodeByNodeId(child.first) != nullptr && child.second->GetMaintainDataNum() != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (int i = index; i < endIndex; ++i) {
				if (neighborNum >= (test.GetK() + 0)) {
					return;
				}
				if (i == index) {
					if (temNode->GetCObjGroupById(i)->GetObjectListSize() != 0) {
						temObjList.clear();
						temObjList = temNode->GetCObjGroupById(i)->GetObjectList();
						auto temobj = temObjList.rbegin();
						for (; temobj != temObjList.rend(); ++temobj) {
							if (*temobj >= windowBegin) {
								break;
							}
						}
						temObjList.erase(temobj.base(), temObjList.end());
						if (temNode->GetCObjGroupById(i)->GetObjectListSize() != 0) {
							groupIndex[i] += temNode->GetCObjGroupById(i)->GetObjectListSize();
							neighborNum += temNode->GetCObjGroupById(i)->GetObjectListSize();
						}
					}
				}
				else {
					groupIndex[i] += temNode->GetCObjGroupById(i)->GetObjectListSize();
					neighborNum += temNode->GetCObjGroupById(i)->GetObjectListSize();
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::AddRhoNeihborForObject(TStream& tstream, Test& test, CObject* object, CNode* node, vector<int>& groupIndex, int& neighborNum, int& beginIndex, int& endIndex)
{
	queue<CNode*> queNode;
	queNode.push(node);
	CNode* temNode = nullptr;
	int windowBegin = tstream.GetDataStreamBegin();
	list<int> temObjList;
	while (!queNode.empty()) {
		if (neighborNum >= (test.GetK() + 0)) {
			return;
		}
		temNode = queNode.front();
		if (temNode->GetChildNodeNum() != 0) {
			for (auto child : temNode->GetChildList()) {
				if (nodePool.GetNodeByNodeId(child.first) != nullptr && child.second->GetMaintainDataNum() != 0) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (int i = beginIndex; i < endIndex; ++i) {
				if (neighborNum >= (test.GetK() + 0)) {
					break;
				}
				if (i == beginIndex) {
					temObjList.clear();
					temObjList = temNode->GetCObjGroupById(i)->GetObjectList();
					auto temobj = temObjList.rbegin();
					for (; temobj != temObjList.rend(); ++temobj) {
						if (*temobj >= windowBegin) {
							break;
						}
					}
					temObjList.erase(temobj.base(), temObjList.end());
					if (temNode->GetCObjGroupById(i)->GetObjectListSize() != 0) {
						groupIndex[i] += temNode->GetCObjGroupById(i)->GetObjectListSize();
						neighborNum += temNode->GetCObjGroupById(i)->GetObjectListSize();
					}
				}
				else {
					groupIndex[i] += temNode->GetCObjGroupById(i)->GetObjectListSize();
					neighborNum += temNode->GetCObjGroupById(i)->GetObjectListSize();
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::ReCreatONrForObject(TStream& tstream, Test& test, int objId, CNode* node, int index)
{
	queue<CNode*> queNode;
	queue<CNode*> stackNode;
	stackNode.push(node);
	CNode* temNode = node;
	double r = test.GetR();
	CObject* object = objectPool.AcquireObject();
	object->SetObjectId(objId);
	object->SetBelongNodeId(node->GetNodeId());
	object->SetNeighborCountSize(test.GetN() / test.GetMapCount() + 1);
	object->SetSlideFlag(tstream.GetSlideBegin() / test.GetMapCount());
	double dis = 0;
	vector<int> groupIndex(tstream.GetTotalSlideNum() / test.GetMapCount() + 1);
	int neighborNum = 0;
	list<CNode*> NodeList;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	AddNeighborInIntermediateNode(tstream, test, object, node, groupIndex, neighborNum, index, NodeList);
	CNode* nodeInONr = nullptr;
	int countNum = 0;
	unordered_set<int> temList;
	if (neighborNum >= test.GetK()) {
		if (object->CheckNeedInsert(tstream, test, groupIndex)) {
			CheckInsetKDTreeForObject(tstream, test, object);
		}
		else {
			objectPool.ReleaseObject(object);
		}
		return;
	}
	else {
		while (temNode->GetParentNode() != nullptr) {
			temNode = temNode->GetParentNode();
			stackNode.push(temNode);
		}
		while (!stackNode.empty()) {
			if (stackNode.front()->GetParentNode() != nullptr) {
				temNode = stackNode.front()->GetParentNode();
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetNodeId() != stackNode.front()->GetNodeId() && node->CalMinDisToNode(tstream, test, child.second) <= r) {
						queNode.push(child.second);
					}
				}
			}
			stackNode.pop();
			while (!queNode.empty()) {
				temNode = queNode.front();
				if (temNode->GetMaintainDataNum() > 0) {
					AddNeighborInIntermediateNode(tstream, test, object, temNode, groupIndex, neighborNum, index, NodeList);
				}
				queNode.pop();
			}
		}
		if (neighborNum < test.GetK()) {
			unordered_set<int>().swap(temList);
			if (object->GetONrNodeList(temList)) {
				for (auto nodeInONrId : temList) {
					nodeInONr = nodePool.GetNodeByNodeId(nodeInONrId);
					if (nodeInONr != nullptr) {
						AddRhoNeihborForObject(tstream, test, object, nodeInONr, groupIndex, neighborNum, startIndex, index);
						if (neighborNum >= (test.GetK() + 0)) {
							break;
						}
					}
				}
			}
			for (auto leafNode : NodeList) {
				for (int i = startIndex; i < index; ++i) {
					if (neighborNum >= (test.GetK() + 0)) {
						break;
					}
					if (i == startIndex) {
						for (auto id : leafNode->GetCObjGroupById(i)->GetObjectList()) {
							if (id < tstream.GetDataStreamBegin()) {
								break;
							}
							if (id != object->GetObjectId() && tstream.CalTwoObjectRealDistance(object->GetObjectId(), id, test.GetDim()) <= r) {
								groupIndex[i]++;
								neighborNum++;
							}
						}
					}
					else {
						for (auto id : leafNode->GetCObjGroupById(i)->GetObjectList()) {
							if (id != object->GetObjectId() && tstream.CalTwoObjectRealDistance(object->GetObjectId(), id, test.GetDim()) <= r) {
								groupIndex[i]++;
								neighborNum++;
							}
						}
					}
				}
			}
			if (neighborNum < test.GetK()) {
				if (tstream.GetObjectSlideId(object->GetObjectId()) > tstream.GetSlideBegin()) {
					kdTreeRoot->InsertObject(tstream, test, object);
					kdTreeRoot->AddMaintainNum();
					object->CalAlarmTime(tstream, test, groupIndex);
				}
				else {
					objectPool.ReleaseObject(object);
					changeRMap.emplace(objId, node);
				}
			}
			else {
				if (object->CheckNeedInsert(tstream, test, groupIndex)) {
					CheckInsetKDTreeForObject(tstream, test, object);
				}
				else {
					objectPool.ReleaseObject(object);
				}
			}
			return;
		}
		else {
			if (object->CheckNeedInsert(tstream, test, groupIndex)) {
				CheckInsetKDTreeForObject(tstream, test, object);
			}
			else {
				objectPool.ReleaseObject(object);
			}
			return;
		}
	}
}

void CKNode::AddNeighborInIntermediateNode(TStream& tstream, Test& test, CObject* object, CNode* node, vector<int>& groupIndex, int& neighborNum, int& posIndex, list<CNode*>& NodeList)
{
	queue<CNode*> queNode;
	queNode.push(node);
	CNode* temNode = nullptr;
	double r = test.GetR();
	int endIndex = GetEndIndex(tstream, test);
	while (!queNode.empty()) {
		if (neighborNum >= test.GetK()) {
			break;
		}
		temNode = queNode.front();
		if (temNode->CalMinDisBetweenObjAndNode(tstream, test, object->GetObjectId()) <= r && temNode->CalMaxDisBetweenObjAndNode(tstream, test, object->GetObjectId()) <= (1 + test.GetRho()) * r) {
			object->AddNodeToOnrNodeList(temNode->GetNodeId());
			AddRhoNeihborForObject(tstream, test, object, temNode, groupIndex, neighborNum, posIndex);
		}
		else {
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetMaintainDataNum() != 0 && child.second->CalMinDisBetweenObjAndNode(tstream, test, object->GetObjectId()) <= r) {
						queNode.push(child.second);
					}
				}
			}
			else {
				NodeList.push_back(temNode);
				for (int i = posIndex; i < endIndex; ++i) {
					if (neighborNum >= test.GetK()) {
						break;
					}
					if (i == posIndex) {
						for (auto id : temNode->GetCObjGroupById(i)->GetObjectList()) {
							if (id < tstream.GetDataStreamBegin()) {
								break;
							}
							if (id != object->GetObjectId() && tstream.CalTwoObjectRealDistance(object->GetObjectId(), id, test.GetDim()) <= r) {
								groupIndex[i]++;
								neighborNum++;
								if (neighborNum >= test.GetK()) {
									break;
								}
							}
						}
					}
					else {
						for (auto id : temNode->GetCObjGroupById(i)->GetObjectList()) {
							if (id != object->GetObjectId() && tstream.CalTwoObjectRealDistance(object->GetObjectId(), id, test.GetDim()) <= r) {
								groupIndex[i]++;
								neighborNum++;
								if (neighborNum >= test.GetK()) {
									break;
								}
							}
						}
					}
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::Update(TStream& tstream, Test& test)
{
	clock_t startTime, endTime;
	startTime = clock();
	double outPutTime;
	int countSize = test.GetN();
	int deleteNullNodeCount = test.GetN() * deleteSize;
	int newEntryId = tstream.GetDataStreamTag();
	std::function<CNode* ()> get_node_pointer = [this]() {
		return nodePool.AcquireNode();
	};
	if (deleteNullNodeCount == 0) {
		deleteNullNodeCount = 1;
	}
	int firstTag = tstream.GetSlideTag();
	bool flag = false;
	int deleteSlideArrayTag = 0;
	int deletSlideMapBegin = 0;
	list<int> kdTreeOutlier;
	int count = 0;
	int currentObjectNum = 0;
	int lowerBound = 0;
	int upperBound = 0;
	int outlierNum = 0;
	countSlideNum = tstream.GetTotalSlideNum() - 1 - tstream.GetSlideTag();
	for (int i = tstream.GetSlideTag(); i < tstream.GetTotalSlideNum() - 1; ++i) {
		if (i % countSize == 0 && i != firstTag) {
			endTime = clock();
			outPutTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			std::cout << "Current cursor: " << tstream.GetDataStreamBegin() << "     Time = " << outPutTime << "s" << endl;
			startTime = clock();
		}
		tstream.AddDataStreamBegin(tstream.GetS_Change(tstream.GetSlideBegin()));
		tstream.AddDataStreamTag(tstream.GetS_Change(i));
		tstream.AddSlideBegin(1);
		tstream.AddSlideTag(1);
		unordered_map<int, CNode*>().swap(newCreateNodeMap);
		unordered_map<int, CNode*>().swap(newObjectInsertNodeMap);
		unordered_map<int, CNode*>().swap(changeRMap);
		flag = false;
		AddNewObjectToRoot(tstream, test, newEntryId, tstream.GetDataStreamTag());
		if (i % deleteNullNodeCount == 0 && i != firstTag) {
			root->UpdateNodeInformation(tstream, test, get_node_pointer, deletSlideMapBegin);
			deletSlideMapBegin = tstream.GetSlideBegin() / test.GetMapCount();
			DeleteEmptyNode(tstream, test, root);
			FindKNodeInUpdate(tstream, test);
			kdTreeRoot->DeleteExpiredObject(tstream, test);
			RegularCleanUpSlideArray(deleteSlideArrayTag, tstream.GetSlideTag());
			deleteSlideArrayTag = tstream.GetSlideTag();
			flag = true;
		}
		FindNeighborForNewObjectInKD_Tree(tstream, test, newEntryId, tstream.GetDataStreamTag());
		newEntryId = tstream.GetDataStreamTag();
		FindKNodeForNewCreateNode(tstream, test);
		for (auto it : newObjectInsertNodeMap) {
			FindKNodeForNewObject(tstream, test, it.second, it.first);
		}
		UpdateDealWarningObjectAndNode(tstream, test);
		
		currentObjectNum = CalCurrentWindowObjectNum(tstream, test);
		lowerBound = ChangeRLowerBound * currentObjectNum;
		upperBound = ChangeRUpperBound * currentObjectNum;
		kdTreeOutlier.clear();
		count = 0;
		kdTreeRoot->FindKD_TreeOutlierNum(tstream, test, kdTreeOutlier, count);
		outlierNum = changeRMap.size() + count;
		if (outlierNum < lowerBound || outlierNum > upperBound) {
			if (!flag) {
				root->UpdateNodeInformation(tstream, test, get_node_pointer, deletSlideMapBegin);
				deletSlideMapBegin = tstream.GetSlideBegin() / test.GetMapCount();
			}
			ChangeR(tstream, test, outlierNum, kdTreeOutlier);
		}
		averageMemory.push_back(getProcessMemoryMB());
	}
	peakMemory = getPeakProcessMemoryMB();
}

void CKNode::AddNewObjectToRoot(TStream& tstream, Test& test, int objectBeginId, int objectEndId)
{
	CNode* temNode = nullptr;
	vector<int> vecAddr(test.GetVirtualDim(), 0);
	std::function<CNode* ()> get_node_pointer = [this]() {
		return nodePool.AcquireNode();
	};
	CNode* findAns = nullptr;
	short calAddr = 0;
	bool flag = false;
	for (int i = objectBeginId; i < objectEndId; ++i) {
		temNode = this->root;
		while (true) {
			if (temNode->GetChildNodeNum() != 0) {
				calAddr = temNode->FindAddrForDataObj(tstream, test, i, vecAddr);
				findAns = nullptr;
				findAns = temNode->GetChildNodeByAddr(tstream, test, calAddr);
				if (findAns != nullptr) {
					temNode = findAns;
				}
				else {
					temNode->FindChildNode(tstream, test, get_node_pointer, calAddr, i, vecAddr);
					findAns = temNode->GetChildNodeByAddr(tstream, test, calAddr);
					newCreateNodeMap.emplace(findAns->GetNodeId(), findAns);
					break;
				}
			}
			else {
				temNode->AddMaintainDataNum();
				temNode->AddObjToNodeFront(tstream.GetObjectSlideId(i) / test.GetMapCount(), i);
				if (newCreateNodeMap.find(temNode->GetNodeId()) == newCreateNodeMap.end()) {
					newObjectInsertNodeMap.emplace(i, temNode);
				}
				break;
			}
		}
		temNode = nullptr;
	}
}

void CKNode::DeleteWholeSubtree(TStream& tstream, Test& test, CNode* node)
{
	if (!node) return;
	for (auto& kv : node->GetChildList()) {
		DeleteWholeSubtree(tstream, test, kv.second);
	}
	nodePool.ReleaseNode(node);
}

void CKNode::DeleteEmptyNode(TStream& tstream, Test& test, CNode* node)
{
	if (!node) return;
	auto& children = node->GetChildList();
	CNode* child = nullptr;
	for (auto it = children.begin(); it != children.end(); ) {
		child = nullptr;
		child = it->second;
		DeleteEmptyNode(tstream, test, child);
		if (child->GetMaintainDataNum() == 0) {
			DeleteWholeSubtree(tstream, test, child);   
			it = children.erase(it); 
			continue;
		}
		else {
			++it;
		}
	}
}

void CKNode::FindKNodeInUpdate(TStream& tstream, Test& test)
{
	queue<CNode*> queNode;
	queNode.push(root);
	CNode* temNode = nullptr;
	int k = test.GetK();
	list<CNode*> newKNodeSet;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetMaintainDataNum() > k) {
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					queNode.push(child.second);
				}
			}
		}
		else {
			if (temNode->GetMaintainDataNum() != 0) {
				newKNodeSet.push_back(temNode);
			}

		}
		queNode.pop();
	}
	CheckNewKnodeSet(tstream, test, newKNodeSet);
	kNodeSmall.clear();
	kNodeLarge.clear();
	double threshold = test.GetL_kThreshold();
	for (auto KNode : newKNodeSet) {
		if (KNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
			kNodeSmall.push_back(KNode);
		}
		else {
			kNodeLarge.push_back(KNode);
		}
	}
	unordered_map<int, CNode*>().swap(E_I);
	unordered_map<int, CNode*>().swap(E_L);
	DivideKNodeLargeIntoE_IAndE_L(tstream, test);
}

void CKNode::CheckNewKnodeSet(TStream& tstream, Test& test, list<CNode*>& newKNodeSet)
{
	list<CNode*> finallKnodeSet;
	unordered_map<int, CNode*> oldKNodeMap;
	list<CNode*> changeKnodeFlag;
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
	};
	CNode* oldKNode = nullptr;
	for (auto newKNode = newKNodeSet.begin(); newKNode != newKNodeSet.end(); ++newKNode) {
		if (!(*newKNode)->GetKNodeFlag()) {
			oldKNode = nullptr;
			if ((*newKNode)->UpwardFindOldKNode(tstream,test, oldKNode)) {
				if (oldKNode->GetMaintainDataNum() > (test.GetK() * 2 + 1)) {
					changeKnodeFlag.push_back(oldKNode);
					(*newKNode)->SetKNodeFlag(true);
					if ((*newKNode)->Getnnl_ukSize() == 0 && (*newKNode)->Getnnl_ukSmallSize() == 0) {
						(*newKNode)->Creatennl_ukByOldKnode(tstream, test, oldKNode, get_node_pointer_by_nodeid);
					}
					finallKnodeSet.push_back(*newKNode);
				}
				else {
					if (oldKNodeMap.find(oldKNode->GetNodeId()) == oldKNodeMap.end()) {
						oldKNodeMap.emplace(oldKNode->GetNodeId(), oldKNode);
					}
				}
			}
			else {
				(*newKNode)->SetKNodeFlag(true);
				if ((*newKNode)->GetChildNodeNum() == 0) {
					if ((*newKNode)->Getnnl_ukSize() == 0 && (*newKNode)->Getnnl_ukSmallSize() == 0) {
						(*newKNode)->CreateNN_l(tstream, test);
					}
				}
				else {
					if ((*newKNode)->Getnnl_ukSize() == 0 && (*newKNode)->Getnnl_ukSmallSize() == 0) {
						(*newKNode)->ChangeKNodeInformation(tstream, test);
					}
					else {
						(*newKNode)->ChangeKNodeInformation(tstream, test, true);
					}
				}
				finallKnodeSet.push_back(*newKNode);
			}
		}
		else {
			finallKnodeSet.push_back(*newKNode);
		}
	}
	for (auto it : oldKNodeMap) {
		finallKnodeSet.push_back(it.second);
	}
	for (auto it : changeKnodeFlag) {
		it->SetKNodeFlag(false);
		it->ClearNNL();
	}
	newKNodeSet.clear();
	newKNodeSet = finallKnodeSet;
}

void CKNode::FindKNodeForNewCreateNode(TStream& tstream, Test& test)
{
	int flag = 0;
	double threshold = test.GetL_kThreshold();
	list<CNode*> newKNodeLarge;
	std::function<CNode* ()> get_node_pointer = [this]() {
		return nodePool.AcquireNode();
	};
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
	};
	CNode* KNode = nullptr;
	for (auto newNode : newCreateNodeMap) {
		flag = 0;
		KNode = nullptr;
		KNode = newNode.second;
		while (KNode != nullptr) {
			if (E_I.find(KNode->GetNodeId()) != E_I.end()) {
				flag = 2;
				break;
			}
			if (KNode->GetKNodeFlag()) {
				flag = 1;
				break;
			}
			KNode = KNode->GetParentNode();
		}
		if (flag == 0) {
			if (newNode.second->GetMaintainDataNum() > test.GetK()) {
				newNode.second->CheckSplit(tstream, test, get_node_pointer);
				FindNewKNodeLargeInNewNode(tstream, test, newNode.second, newKNodeLarge);
			}
			else {
				newNode.second->SetKNodeFlag(true);
				newNode.second->CreateNN_l(tstream, test);
				if (newNode.second->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
					kNodeSmall.push_back(newNode.second);
					newNode.second->SetUpl_k(tstream, test, get_node_pointer_by_nodeid);
					slideArray[newNode.second->GetAlarmTime()]->AddNodeToWarningNode(newNode.second);
				}
				else {
					newKNodeLarge.push_back(newNode.second);
				}
			}
			for (auto newKNode : newKNodeLarge) {
				newKNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid);
				DealNewCreateNode(tstream, test, newKNode);
			}
			newKNodeLarge.clear();
		}
		else {
			if (flag == 1) {
				if (KNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					if (newNode.second->GetMaintainDataNum() > test.GetK()) {
						newNode.second->CheckSplit(tstream, test, get_node_pointer);
					}
					DealNewCreateNode(tstream, test, newNode.second, KNode->Getnnl_uk(), KNode->Getnnl_ukSmall());
				}
				else {
					continue;
				}
			}
		}
	}
	
}

void CKNode::FindNewKNodeLargeInNewNode(TStream& tstream, Test& test, CNode* newNode, list<CNode*>& newKNodeLarge)
{
	queue<CNode*> queNode;
	queNode.push(newNode);
	CNode* temNode = nullptr;
	int k = test.GetK();
	double threshold = test.GetL_kThreshold();
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
	};
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetMaintainDataNum() > k) {
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					queNode.push(child.second);
				}
			}
		}
		else {
			temNode->SetKNodeFlag(true);
			temNode->CreateNN_l(tstream, test);
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
				kNodeSmall.push_back(temNode);
				temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid);
				slideArray[temNode->GetAlarmTime()]->AddNodeToWarningNode(temNode);
			}
			else {
				newKNodeLarge.push_back(temNode);
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::UpdateDealWarningObjectAndNode(TStream& tstream, Test& test)
{
	list<CObject*> warningObj = slideArray[tstream.GetSlideBegin()]->GetWarningObj();
	list<CNode*> warningNode = slideArray[tstream.GetSlideBegin()]->GetWarningNode();
	double threshold = test.GetR() * test.GetRho() / 2;
	CNode* kNode = nullptr;
	for (auto& node : warningNode) {
		if (node->GetKNodeFlag()) {
			if (node->CalDiagonalLength(test.GetVirtualDim() <= test.GetL_kThreshold())) {
				if (node->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
					node->Tighteningl_k(tstream, test);
					slideArray[node->GetAlarmTime()]->AddNodeToWarningNode(node);
				}
			}
			else {
				UpdateDealAlarmTimeKNodeLarge(tstream, test, node);
			}
		}
		else {
			kNode = nullptr;
			kNode = SearchUpwardsKNode(tstream, test, node);
			if (kNode != nullptr) {
				if (kNode->CalDiagonalLength(test.GetVirtualDim() <= test.GetL_kThreshold())) {
					if (kNode->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
						kNode->Tighteningl_k(tstream, test);
						slideArray[kNode->GetAlarmTime()]->AddNodeToWarningNode(node);
					}
				}
				else {
					if (node->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
						E_I.emplace(node->GetNodeId(), node);
						DealE_INode(tstream, test, node);
					}
					else {
						E_L.emplace(node->GetNodeId(), node);
						DealE_LNode(tstream, test, node);
					}
				}
			}
			else {
				UpdateDealDescendantNode(tstream, test, node);
			}
		}
	}
	for (auto& object : warningObj) {
		if (object->GetObjectId() >= tstream.GetDataStreamBegin()) {
			ReCall_kForObject(tstream, test, object);
		}
	}
}

void CKNode::FindKNodeForNewObject(TStream& tstream, Test& test, CNode* currentNode, int objId)
{
	double threshold = test.GetL_kThreshold();
	double threshold2 = test.GetR() * test.GetRho() / 2;
	double r = test.GetR();
	CNode* belongKNode = currentNode;
	while (belongKNode != nullptr) {
		if (belongKNode->GetKNodeFlag()) {
			break;
		}
		else{
			belongKNode = belongKNode->GetParentNode();
		}
	}
	if (belongKNode == nullptr) {
		currentNode->SetKNodeFlag(true);
		belongKNode = currentNode;
		if (currentNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
			kNodeSmall.push_back(currentNode);
		}
		else {
			kNodeLarge.push_back(currentNode);
		}
		if ((belongKNode->Getnnl_ukSize() + belongKNode->Getnnl_ukSmallSize()) == 0) {
			belongKNode->CreateNN_l(tstream, test);
		}
	}
	if (belongKNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
		return;
	}
	else {
		if (currentNode->CalDiagonalLength(test.GetVirtualDim()) > threshold2) {
			if (currentNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				DealObjInLargeLeafNode(tstream, test, objId, currentNode);
			}
			else {
				if (currentNode->Getl_k() > r || ((currentNode->Getl_k() + 2 * currentNode->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r)) {
					if (currentNode->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
						currentNode->Tighteningl_k(tstream, test);
					}
					if (currentNode->Getl_k() > r) {
						changeRMap.emplace(objId, currentNode);
					}
					else if ((currentNode->Getl_k() + 2 * currentNode->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r) {
						CreateONrForObject(tstream, test, objId, currentNode);
					}
				}
			}
			return;
		}
		else {
			CNode* temNode = currentNode;
			while (temNode->GetParentNode() != nullptr) {
				if (temNode->GetParentNode()->CalDiagonalLength(test.GetVirtualDim()) > threshold2 && temNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold2) {
					if (temNode->Getl_k() > r) {
						if (temNode->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
							temNode->Tighteningl_k(tstream, test);
						}
						if (temNode->Getl_k() > r) {
							changeRMap.emplace(objId, currentNode);
						}
					}
					break;
				}
				else {
					temNode = temNode->GetParentNode();
				}
			}
			return;
		}
	}
}

void CKNode::DealNewCreateNode(TStream& tstream, Test& test, CNode* newNode)
{
	queue<CNode*> queKNode;
	queKNode.push(newNode);
	CNode* temNode = nullptr;
	double threshold = test.GetR() * test.GetRho() / 2;
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
		};
	while (!queKNode.empty()) {
		temNode = queKNode.front();
		if (temNode->GetChildNodeNum() == 0) {
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				if (temNode->GetMaintainDataNum() != 0) {
					temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid, newNode->Getnnl_uk(), newNode->Getnnl_ukSmall());
					E_L.emplace(temNode->GetNodeId(), temNode);
					DealE_LNode(tstream, test, temNode);
				}
			}
			else {
				if (temNode->GetMaintainDataNum() != 0) {
					temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid, newNode->Getnnl_uk(), newNode->Getnnl_ukSmall());
					E_I.emplace(temNode->GetNodeId(), temNode);
					DealE_INode(tstream, test, temNode);
				}
			}
		}
		else {
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				for (auto child : temNode->GetChildList()) {
					queKNode.push(child.second);
				}
			}
			else {
				if (temNode->GetMaintainDataNum() != 0) {
					temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid, newNode->Getnnl_uk(), newNode->Getnnl_ukSmall());
					E_I.emplace(temNode->GetNodeId(), temNode);
					DealE_INode(tstream, test, temNode);
				}
			}
		}
		temNode = nullptr;
		queKNode.pop();
	}
}

void CKNode::DealNewCreateNode(TStream& tstream, Test& test, CNode* newNode, NNLContainer& nnl_uk, NNLContainer& nnl_ukSmall)
{
	queue<CNode*> queKNode;
	queKNode.push(newNode);
	CNode* temNode = nullptr;
	double threshold = test.GetR() * test.GetRho() / 2;
	std::function<CNode* (int)> get_node_pointer_by_nodeid = [this](int id) {
		return nodePool.GetNodeByNodeId(id);
		};
	while (!queKNode.empty()) {
		temNode = queKNode.front();
		if (temNode->GetChildNodeNum() == 0) {
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				if (temNode->GetMaintainDataNum() != 0) {
					temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid, nnl_uk, nnl_ukSmall);
					E_L.emplace(temNode->GetNodeId(), temNode);
					DealE_LNode(tstream, test, temNode);
				}
			}
			else {
				if (temNode->GetMaintainDataNum() != 0) {
					temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid, nnl_uk, nnl_ukSmall);
					E_I.emplace(temNode->GetNodeId(), temNode);
					DealE_INode(tstream, test, temNode);
				}
			}
		}
		else {
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				for (auto child : temNode->GetChildList()) {
					queKNode.push(child.second);
				}
			}
			else {
				if (temNode->GetMaintainDataNum() != 0) {
					temNode->SetUpl_k(tstream, test, get_node_pointer_by_nodeid, nnl_uk, nnl_ukSmall);
					E_I.emplace(temNode->GetNodeId(), temNode);
					DealE_INode(tstream, test, temNode);
				}
			}
		}
		temNode = nullptr;
		queKNode.pop();
	}
}

void CKNode::DealE_INode(TStream& tstream, Test& test, CNode* temNode)
{
	double r = test.GetR();
	if (temNode->Getl_k() > r || temNode->GetAlarmTime() < tstream.GetSlideBegin()) {
		if (temNode->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
			temNode->Tighteningl_k(tstream, test);
		}
	}
	if (temNode->Getl_k() > r) {
		if (temNode->Getl_k() > r) {
			slideArray[tstream.GetSlideBegin() + 1]->AddNodeToWarningNode(temNode);
			RecordOutlierInNode(tstream, test, temNode);
		}
		else {
			slideArray[temNode->GetAlarmTime()]->AddNodeToWarningNode(temNode);
		}
	}
}

void CKNode::DealE_LNode(TStream& tstream, Test& test, CNode* temNode)
{
	double r = test.GetR();
	if (temNode->CalDiagonalLength(test.GetVirtualDim()) > test.GetL_kThreshold()) {
		DealE_LChildNode(tstream, test, temNode);
	}
	else {
		if (temNode->Getl_k() > r || temNode->GetAlarmTime() < tstream.GetSlideBegin()) {
			if (temNode->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
				temNode->Tighteningl_k(tstream, test);
			}
		}
		if (temNode->Getl_k() > r || ((temNode->Getl_k() + 2 * temNode->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r)) {
			if (temNode->Getl_k() > r) {
				slideArray[tstream.GetSlideBegin() + 1]->AddNodeToWarningNode(temNode);
				RecordOutlierInNode(tstream, test, temNode);
				return;
			}
			else if ((temNode->Getl_k() + 2 * temNode->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r) {
				DealE_LObjChildNode(tstream, test, temNode);
			}
			else {
				temNode->UpdateParentNodel_kAndAlarmTime(tstream, test);
				slideArray[temNode->GetAlarmTime()]->AddNodeToWarningNode(temNode);
			}
		}
		else {
			slideArray[temNode->GetAlarmTime()]->AddNodeToWarningNode(temNode);
		}
	}
}

void CKNode::UpdateDealAlarmTimeKNodeLarge(TStream& tstream, Test& test, CNode* kNodeLarge)
{
	CNode* temNode = nullptr;
	double threshold = test.GetR() * test.GetRho() / 2;
	queue<CNode*> queKNode;
	queKNode.push(kNodeLarge);
	while (!queKNode.empty()) {
		temNode = queKNode.front();
		if (temNode->GetChildNodeNum() == 0) {
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				if (temNode->GetMaintainDataNum() != 0) {
					E_L.emplace(temNode->GetNodeId(), temNode);
					DealE_LNode(tstream, test, temNode);
				}
			}
			else {
				if (temNode->GetMaintainDataNum() != 0) {
					E_I.emplace(temNode->GetNodeId(), temNode);
					DealE_INode(tstream, test, temNode);
				}
			}
		}
		else {
			if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
				for (auto child : temNode->GetChildList()) {
					queKNode.push(child.second);
				}
			}
			else {
				if (temNode->GetMaintainDataNum() != 0) {
					E_I.emplace(temNode->GetNodeId(), temNode);
					DealE_INode(tstream, test, temNode);
				}
			}
		}
		temNode = nullptr;
		queKNode.pop();
	}
}

CNode* CKNode::SearchUpwardsKNode(TStream& tstream, Test& test, CNode* temNode)
{
	CNode* targetKNode = temNode->GetParentNode();
	while (targetKNode != nullptr) {
		if (targetKNode->GetKNodeFlag()) {
			return targetKNode;
		}
		else {
			targetKNode = targetKNode->GetParentNode();
		}
	}
	return nullptr;
}

void CKNode::UpdateDealDescendantNode(TStream& tstream, Test& test, CNode* node)
{
	list<CNode*> temKNodeSmall;
	list<CNode*> temKNodeLarge;
	queue<CNode*> queNode;
	queNode.push(node);
	CNode* temNode = nullptr;
	int k = test.GetK();
	double threshold = test.GetL_kThreshold();
	double threshold2 = test.GetR() * test.GetRho() / 2;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (nodePool.GetNodeByNodeId(temNode->GetNodeId()) != nullptr) {
			if (temNode->GetKNodeFlag()) {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
					temKNodeSmall.push_back(temNode);
				}
				else {
					temKNodeLarge.push_back(temNode);
				}
			}
			else {
				for (auto child : temNode->GetChildList()) {
					if (nodePool.GetNodeByNodeId(child.second->GetNodeId()) != nullptr) {
						queNode.push(child.second);
					}
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
	for (auto& kNodeS : temKNodeSmall) {
		if (kNodeS->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
			kNodeS->Tighteningl_k(tstream, test);
		}
		slideArray[kNodeS->GetAlarmTime()]->AddNodeToWarningNode(kNodeS);
	}
	queue<CNode*> queKNode;
	for (auto& kNodeL : temKNodeLarge) {
		queKNode.push(kNodeL);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->GetChildNodeNum() == 0) {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold2) {
					if (temNode->GetMaintainDataNum() != 0) {
						E_L.emplace(temNode->GetNodeId(), temNode);
						DealE_LNode(tstream, test, temNode);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
						DealE_INode(tstream, test, temNode);
					}
				}
			}
			else {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold2) {
					for (auto child : temNode->GetChildList()) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
						DealE_INode(tstream, test, temNode);
					}
				}
			}
			temNode = nullptr;
			queKNode.pop();
		}
	}
}

void CKNode::ReCall_kForObject(TStream& tstream, Test& test, CObject* object)
{
	vector<int> groupIndex(tstream.GetTotalSlideNum() / test.GetMapCount() + 1);
	int neighborNum = 0;
	CNode* temNode = nullptr;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	unordered_set<int> temOnrNodeList;
	if (object->GetONrNodeList(temOnrNodeList)) {
		for (auto it = temOnrNodeList.begin(); it != temOnrNodeList.end();) {
			if (neighborNum >= test.GetK()) {
				break;
			}
			temNode = nodePool.GetNodeByNodeId(*it);
			if (temNode == nullptr) {
				it = temOnrNodeList.erase(it);
				continue;
			}
			if (temNode->CalMinDisBetweenObjAndNode(tstream, test, object->GetObjectId()) <= test.GetR() && temNode->CalMaxDisBetweenObjAndNode(tstream, test, object->GetObjectId()) <= (1 + test.GetRho()) * test.GetR()) {
				AddRhoNeihborForObject(tstream, test, object, temNode, groupIndex, neighborNum, startIndex);
			}
			else {
				it = temOnrNodeList.erase(it);
				continue;
			}
			it++;
		}
	}
	int countNum = 0;
	CNode* belongNode = nullptr;
	if (neighborNum >= test.GetK()) {
		if (object->CheckNeedInsert(tstream, test, groupIndex)) {
			CheckInsetKDTreeForObject(tstream, test, object);
		}
		else {
			objectPool.ReleaseObject(object);
			object = nullptr;
			return;
		}
	}
	else {
		belongNode = nodePool.GetNodeByNodeId(object->GetBelongNodeId());
		int objectId = object->GetObjectId();
		objectPool.ReleaseObject(object);
		object = nullptr;
		if (belongNode != nullptr) {
			CreateONrForObject(tstream, test, objectId, belongNode);
		}
		else {
			belongNode = FindBelongNodeForObj(tstream, test, objectId);
			if (belongNode != nullptr) {
				CreateONrForObject(tstream, test, objectId, belongNode);
			}
		}
	}
}

CNode* CKNode::FindBelongNodeForObj(TStream& tstream, Test& test, int objId)
{
	CNode* temNode = root;
	vector<int> vecAddr(test.GetVirtualDim(), 0);
	CNode* findAns = nullptr;
	while (true) {
		if (temNode->GetChildNodeNum() != 0) {
			short calAddr = temNode->FindAddrForDataObj(tstream, test, objId, vecAddr);
			findAns = nullptr;
			findAns = temNode->GetChildNodeByAddr(tstream, test, calAddr);
			if (findAns != nullptr) {
				if (findAns->GetChildNodeNum() == 0) {
					return findAns;
				}
				else {
					temNode = findAns;
				}
			}
			else {
				return nullptr;
			}
		}
		else {
			return temNode;
		}
	}
}

int CKNode::CalCurrentWindowObjectNum(TStream& tstream, Test& test)
{
	int count = 0;
	for (int i = tstream.GetSlideBegin(); i < tstream.GetSlideTag(); ++i) {
		count += tstream.GetS_Change(i);
	}
	return count;
}

void CKNode::FindLeafSet(TStream& tstream, Test& test, unordered_set<int>& leafNodeIdSet, int& count)
{
	queue<CNode*> queNode;
	queNode.push(root);
	CNode* temNode = nullptr;
	double dis = 0;
	int temCount = 0;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (nodePool.GetNodeByNodeId(temNode->GetNodeId()) != nullptr) {
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetMaintainDataNum() != 0) {
						queNode.push(child.second);
					}
				}
			}
			else {
				leafNodeIdSet.emplace(temNode->GetNodeId());
				temCount += temNode->GetMaintainDataNum();
				if (temCount >= count) {
					return;
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

double CKNode::FindKNNForOutlier(TStream& tstream, Test& test, int outlierId, CNode* targetNode)
{
	multiset<double> neighborSet;
	double kR = DBL_MAX;
	queue<CNode*> queNode;
	queue<CNode*> stackNode;
	stackNode.push(targetNode);
	CNode* temNode = targetNode;
	AddTargetNodeObjectToNeighborSet(tstream, test, outlierId, targetNode, kR, neighborSet);
	while (temNode->GetParentNode() != nullptr) {
		temNode = temNode->GetParentNode();
		stackNode.push(temNode);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->GetParentNode() != nullptr) {
			temNode = stackNode.front()->GetParentNode();
			for (auto& child : temNode->GetChildList()) {
				if (child.second->GetNodeId() != stackNode.front()->GetNodeId() && child.second->CalMinDisToNode(tstream, test, targetNode) <= kR) {
					queNode.push(child.second);
				}
			}
		}
		stackNode.pop();
		while (!queNode.empty()) {
			temNode = queNode.front();
			if (temNode->GetMaintainDataNum() > 0) {
				AddTargetNodeObjectToNeighborSet(tstream, test, outlierId, temNode, kR, neighborSet);
			}
			temNode = nullptr;
			queNode.pop();
		}
	}
	if (neighborSet.size() == test.GetK()) {
		return *(--neighborSet.end());
	}
	else {
		return DBL_MAX;
	}
}

double CKNode::FindKNNForOutlierInRiseR(TStream& tstream, Test& test, CObject* object, CNode* targetNode)
{
	double kR = DBL_MAX;
	queue<CNode*> queNode;
	queue<CNode*> stackNode;
	stackNode.push(targetNode);
	CNode* temNode = targetNode;
	multimap<double, int> neighborMap;
	AddTargetNodeObjectToNeighborSet(tstream, test, object, targetNode, kR, neighborMap);
	while (temNode->GetParentNode() != nullptr) {
		temNode = temNode->GetParentNode();
		stackNode.push(temNode);
	}
	while (!stackNode.empty()) {
		if (stackNode.front()->GetParentNode() != nullptr) {
			temNode = stackNode.front()->GetParentNode();
			for (auto& child : temNode->GetChildList()) {
				if (child.second->GetNodeId() != stackNode.front()->GetNodeId() && child.second->CalMinDisToNode(tstream, test, targetNode) <= kR) {
					queNode.push(child.second);
				}
			}
		}
		stackNode.pop();
		while (!queNode.empty()) {
			temNode = queNode.front();
			if (temNode->GetMaintainDataNum() > 0) {
				AddTargetNodeObjectToNeighborSet(tstream, test, object, temNode, kR, neighborMap);
			}
			queNode.pop();
		}
	}
	object->SetNeighborCount(tstream, test, neighborMap);
	if (neighborMap.size() == test.GetK()) {
		return (--neighborMap.end())->first;
	}
	else {
		return DBL_MAX;
	}
}

void CKNode::AddTargetNodeObjectToNeighborSet(TStream& tstream, Test& test, int outlierId, CNode* node, double& kR, multiset<double>& neighborSet)
{
	queue<CNode*> queNode;
	queNode.push(node);
	CNode* temNode = nullptr;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	int begin = tstream.GetDataStreamBegin();
	double dis = 0;
	int k = test.GetK();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetChildNodeNum() != 0) {
			for (auto child : temNode->GetChildList()) {
				if (child.second->GetMaintainDataNum() != 0 && child.second->CalMinDisBetweenObjAndNode(tstream,test,outlierId) < kR) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (int i = startIndex; i < endIndex; ++i) {
				if (i == startIndex) {
					for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
						if (objId < begin) {
							break;
						}
						if (objId != outlierId) {
							dis = tstream.CalTwoObjectRealDistance(objId, outlierId, test.GetDim());
							if (dis < kR) {
								neighborSet.emplace(dis);
								if (neighborSet.size() > k) {
									neighborSet.erase(--neighborSet.end());
									kR = *(--neighborSet.end());
								}
							}
						}
					}
				}
				else {
					for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
						if (objId != outlierId) {
							dis = tstream.CalTwoObjectRealDistance(objId, outlierId, test.GetDim());
							if (dis < kR) {
								neighborSet.emplace(dis);
								if (neighborSet.size() > k) {
									neighborSet.erase(--neighborSet.end());
									kR = *(--neighborSet.end());
								}
							}
						}
					}
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::AddTargetNodeObjectToNeighborSet(TStream& tstream, Test& test, CObject* object, CNode* node, double& kR, multimap<double, int>& neighborMap)
{
	queue<CNode*> queNode;
	queNode.push(node);
	CNode* temNode = nullptr;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	int begin = tstream.GetDataStreamBegin();
	double dis = 0;
	int k = test.GetK();
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetChildNodeNum() != 0) {
			for (auto child : temNode->GetChildList()) {
				if (child.second->GetMaintainDataNum() != 0 && child.second->CalMinDisBetweenObjAndNode(tstream, test, object->GetObjectId()) < kR) {
					queNode.push(child.second);
				}
			}
		}
		else {
			for (int i = startIndex; i < endIndex; ++i) {
				if (i == startIndex) {
					for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
						if (objId < begin) {
							break;
						}
						if (objId != object->GetObjectId()) {
							dis = tstream.CalTwoObjectRealDistance(objId, object->GetObjectId(), test.GetDim());
							if (dis < kR) {
								neighborMap.emplace(dis, objId);
								if (neighborMap.size() > k) {
									neighborMap.erase(--neighborMap.end());
									kR = (--neighborMap.end())->first;
								}
							}
						}
					}
				}
				else {
					for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
						if (objId != object->GetObjectId()) {
							dis = tstream.CalTwoObjectRealDistance(objId, object->GetObjectId(), test.GetDim());
							if (dis < kR) {
								neighborMap.emplace(dis, objId);
								if (neighborMap.size() > k) {
									neighborMap.erase(--neighborMap.end());
									kR = (--neighborMap.end())->first;
								}
							}
						}
					}
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::ReDealKNodeSmall(TStream& tstream, Test& test)
{
	list<CNode*> newKnodeLarge;
	double threshold = test.GetL_kThreshold();
	for (auto kNodeS = kNodeSmall.begin(); kNodeS != kNodeSmall.end();) {
		if ((*kNodeS)->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
			newKnodeLarge.push_back(*kNodeS);
			kNodeS = kNodeSmall.erase(kNodeS);
			continue;
		}
		kNodeS++;
	}
	DivideKNodeLargeIntoE_IAndE_L(tstream, test, newKnodeLarge);
}

void CKNode::ReDealE_I(TStream& tstream, Test& test)
{
	double threshold = test.GetR() * test.GetRho() / 2;
	CNode* temNode = nullptr;
	unordered_map<int, CNode*> newE_I;
	queue<CNode*> queKNode;
	for (auto NodeInE_I : E_I) {
		if (NodeInE_I.second->CalDiagonalLength(test.GetVirtualDim()) <= threshold) {
			newE_I.emplace(NodeInE_I.first, NodeInE_I.second);
			continue;
		}
		queKNode.push(NodeInE_I.second);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->GetChildNodeNum() == 0) {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					if (temNode->GetMaintainDataNum() != 0) {
						E_L.emplace(temNode->GetNodeId(), temNode);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						newE_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			else {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					for (auto child : temNode->GetChildList()) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						newE_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			temNode = nullptr;
			queKNode.pop();
		}
	}
	E_I.clear();
	E_I = newE_I;
}

void CKNode::ClearSlideArray(TStream& tstream, Test& test)
{
	for (int i = tstream.GetSlideBegin(); i < tstream.GetSlideTag(); ++i) {
		slideArray[i]->Clear();
	}
}

void CKNode::ChangeR_ReFindOutlier(TStream& tstream, Test& test)
{
	for (auto& kNodeS : kNodeSmall) {
		if (kNodeS->GetTighteningl_kTime() < tstream.GetSlideBegin() || kNodeS->Getl_k() > test.GetR()) {
			kNodeS->Tighteningl_k(tstream, test);
		}
		slideArray[kNodeS->GetAlarmTime()]->AddNodeToWarningNode(kNodeS);
	}
	double r = test.GetR();
	for (auto& node : E_I) {
		if (node.second->Getl_k() > r || node.second->GetAlarmTime() < tstream.GetSlideBegin()) {
			if (node.second->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
				node.second->Tighteningl_k(tstream, test);
			}
		}
		if (node.second->Getl_k() > r) {
			slideArray[tstream.GetSlideBegin() + 1]->AddNodeToWarningNode(node.second);
			RecordOutlierInNode(tstream, test, node.second);
		}
		else {
			slideArray[node.second->GetAlarmTime()]->AddNodeToWarningNode(node.second);
		}
		node.second->UpdateParentNodel_kAndAlarmTime(tstream, test);
	}
	for (auto& node : E_L) {
		if (node.second->CalDiagonalLength(test.GetVirtualDim()) > test.GetL_kThreshold()) {
			Change_RDealE_LChildNode(tstream, test, node.second);
		}
		else {
			if (node.second->Getl_k() > r || node.second->GetAlarmTime() < tstream.GetSlideBegin()) {
				if (node.second->GetTighteningl_kTime() < tstream.GetSlideBegin()) {
					node.second->Tighteningl_k(tstream, test);
				}
			}
			if (node.second->Getl_k() > r || ((node.second->Getl_k() + 2 * node.second->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r)) {
				if (node.second->Getl_k() > r) {
					slideArray[tstream.GetSlideBegin() + 1]->AddNodeToWarningNode(node.second);
					RecordOutlierInNode(tstream, test, node.second);
					continue;
				}
				else if ((node.second->Getl_k() + 2 * node.second->CalDiagonalLength(test.GetVirtualDim())) > (1 + test.GetRho()) * r) {
					Change_RCreateONrForObject(tstream, test, node.second);
				}
				else {
					node.second->UpdateParentNodel_kAndAlarmTime(tstream, test);
					slideArray[node.second->GetAlarmTime()]->AddNodeToWarningNode(node.second);
				}
			}
			else {
				slideArray[node.second->GetAlarmTime()]->AddNodeToWarningNode(node.second);
			}
		}
	}
}

void CKNode::ReDealE_L(TStream& tstream, Test& test)
{
	double threshold = test.GetR() * test.GetRho() / 2;
	CNode* temNode = nullptr;
	unordered_map<int, CNode*> newE_L;
	queue<CNode*> queKNode;
	for (auto NodeInE_L : E_L) {
		if (NodeInE_L.second->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
			newE_L.emplace(NodeInE_L.first, NodeInE_L.second);
			continue;
		}
		queKNode.push(NodeInE_L.second);
		while (!queKNode.empty()) {
			temNode = queKNode.front();
			if (temNode->GetChildNodeNum() == 0) {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					if (temNode->GetMaintainDataNum() != 0) {
						newE_L.emplace(temNode->GetNodeId(), temNode);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			else {
				if (temNode->CalDiagonalLength(test.GetVirtualDim()) > threshold) {
					for (auto child : temNode->GetChildList()) {
						queKNode.push(child.second);
					}
				}
				else {
					if (temNode->GetMaintainDataNum() != 0) {
						E_I.emplace(temNode->GetNodeId(), temNode);
					}
				}
			}
			queKNode.pop();
		}
	}
	E_L.clear();
	E_L = newE_L;
}

void CKNode::ChangeR(TStream& tstream, Test& test, int oldOutlierNum, list<int>& l) {
	int dataNum = CalCurrentWindowObjectNum(tstream, test);
	int lowerBound = ChangeRLowerBound * dataNum;
	int upperBound = ChangeRUpperBound * dataNum;
	int count = 0.01 * dataNum + 1;
	int count2 = 0.01 * dataNum + 1;
	int countOutlier = 0;
	CNode* temNode = nullptr;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	CNode* belongNode = nullptr;
	double oldR = test.GetR();
	int objId = 0;
	int num = 0;
	while (true) {
		if (oldOutlierNum < lowerBound) {
			double temOldR = test.GetR();
			unordered_set<int> leafNodeIdSet;
			FindLeafSet(tstream, test, leafNodeIdSet, count2);
			multimap<double, int, greater<double>> Map;
			for (auto& leafNodeId : leafNodeIdSet) {
				temNode = nodePool.GetNodeByNodeId(leafNodeId);
				if (temNode != nullptr) {
					for (int i = startIndex; i < endIndex; ++i) {
						if (i == startIndex) {
							for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
								if (objId < tstream.GetDataStreamBegin()) {
									break;
								}
								Map.emplace(FindKNNForOutlier(tstream, test, objId, temNode), objId);
							}
						}
						else {
							for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
								Map.emplace(FindKNNForOutlier(tstream, test, objId, temNode), objId);
							}
						}
					}
				}
			}
			num = 0;
			for (auto& it : Map) {
				num++;
				if (num >= count) {
					if (fabs(it.first - temOldR) < ChangeRTag) {
						return;
					}
					else {
						double newR = (it.first + temOldR) / 2;
						test.SetR(newR);
						break;
					}
				}
			}
			test.SetL_kThreshold();
			unordered_map<int, CNode*>().swap(changeRMap);
			kdTreeRoot->ClearTree(true);
			ClearSlideArray(tstream, test);
			ReDealKNodeSmall(tstream, test);
			ReDealE_I(tstream, test);
			ChangeR_ReFindOutlier(tstream, test);
			kdTreeRoot->SetMaintainNum();
			kdTreeRoot->CheckSplit(tstream, test);
			unordered_set<int>().swap(leafNodeIdSet);
			multimap<double, int, greater<double>>().swap(Map);
			l.clear();
			countOutlier = 0;
			kdTreeRoot->FindKD_TreeOutlierNum(tstream, test, l, countOutlier);
			int outlierNum = changeRMap.size() + countOutlier;
			if (outlierNum >= lowerBound && outlierNum <= upperBound) {
				return;
			}
			oldOutlierNum = outlierNum;
			
		}
		else if (oldOutlierNum > upperBound) {
			multimap<double, CObject*, greater<double>> Map;
			for (auto outlier : changeRMap) {
				CObject* object = objectPool.AcquireObject();
				object->SetObjectId(outlier.first);
				object->SetBelongNodeId(outlier.second->GetNodeId());
				object->SetNeighborCountSize(test.GetN() / test.GetMapCount() + 1);
				object->SetSlideFlag(tstream.GetSlideBegin() / test.GetMapCount());
				Map.emplace(FindKNNForOutlierInRiseR(tstream, test, object, outlier.second), object);
			}
			for (auto outlierId : l) {
				belongNode = FindBelongNodeForObj(tstream, test, outlierId);
				CObject* object = objectPool.AcquireObject();
				object->SetObjectId(outlierId);
				object->SetBelongNodeId(belongNode->GetNodeId());
				object->SetNeighborCountSize(test.GetN() / test.GetMapCount() + 1);
				object->SetSlideFlag(tstream.GetSlideBegin() / test.GetMapCount());
				Map.emplace(FindKNNForOutlierInRiseR(tstream, test, object, belongNode), object);
				belongNode = nullptr;
			}
			num = 0;
			kdTreeRoot->ClearTree(true);
			for (auto& it : Map) {
				num++;
				if (num == count) {
					test.SetR(it.first);
					test.SetL_kThreshold();
				}
				if (num > count) {
					if (tstream.GetObjectSlideId(it.second->GetObjectId()) <= tstream.GetSlideBegin()) {
						objectPool.ReleaseObject(it.second);
						it.second = nullptr;
						continue;
					}
					if (it.second->ChangeRReCheckNeedInsert(tstream, test)) {
						kdTreeRoot->InsertObject(tstream, test, it.second);
						it.second->ReleaseonrNodeList(tstream, test);
						it.second = nullptr;
					}
					else {
						objectPool.ReleaseObject(it.second);
						it.second = nullptr;
					}
				}
			}
			num = 0;
			objId = 0;
			for (auto& it : Map) {
				num++;
				if (num <= count && it.second) {
					objId = it.second->GetObjectId();
					CNode* temNode = nodePool.GetNodeByNodeId(it.second->GetBelongNodeId());
					objectPool.ReleaseObject(it.second);
					it.second = nullptr;
					DealObjInLargeLeafNode(tstream, test, objId, temNode);
				}
				else if(num > count){
					break;
				}
			}
			kdTreeRoot->SetMaintainNum();
			kdTreeRoot->CheckSplit(tstream, test);
			ReDealE_L(tstream, test);
			multimap<double, CObject*, greater<double>>().swap(Map);
			return;
		}
	}
}

void CKNode::FindNeighborForNewObjectInKD_Tree(TStream& tstream, Test& test, int objectBeginId, int objectEndId)
{
	for (int i = objectBeginId; i < objectEndId; ++i) {
		FindInKD_Tree(tstream, test, i);
	}
}

void CKNode::FindInKD_Tree(TStream& tstream, Test& test, int objId)
{
	queue<CKDNode*> queNode;
	queNode.push(kdTreeRoot);
	double r = test.GetR();
	CKDNode* temNode = nullptr;
	int subNum = 0;
	std::function<void(CObject*)> release_object = [this](CObject* obj) {
		objectPool.ReleaseObject(obj);
		};
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->GetObjectNum() != 0) {
			subNum = temNode->FindNeighbor(tstream, test, objId);
			kdTreeRoot->SubMaintainNum(subNum);
		}
		else {
			for (auto child : temNode->GetChildren()) {
				if (child && child->GetMaintainNum() != 0 && child->CalMinDisBetweenNodeAndObj(tstream, test, objId) <= r) {
					queNode.push(child);
				}
			}
		}
		temNode = nullptr;
		queNode.pop();
	}
}

void CKNode::DealObjInLargeLeafNode(TStream& tstream, Test& test, int objId, CNode* node)
{
	int posIndex = (tstream.GetSlideBegin() + tstream.GetSlideTag()) / 2 / test.GetMapCount();
	queue<CNode*> queNode;
	queue<CNode*> stackNode;
	stackNode.push(node);
	CNode* temNode = node;
	double r = test.GetR();
	CObject* object = objectPool.AcquireObject();
	object->SetObjectId(objId);
	object->SetBelongNodeId(node->GetNodeId());
	object->SetNeighborCountSize(test.GetN() / test.GetMapCount() + 1);
	object->SetSlideFlag(tstream.GetSlideBegin() / test.GetMapCount());
	double dis = 0;
	vector<int> groupIndex(tstream.GetTotalSlideNum() / test.GetMapCount() + 1);
	int neighborNum = 0;
	list<CNode*> NodeList;
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	AddNeighborInIntermediateNode(tstream, test, object, node, groupIndex, neighborNum, posIndex, NodeList);
	CNode* nodeInONr = nullptr;
	unordered_set<int> temList;
	if (neighborNum >= test.GetK()) {
		if (object->CheckNeedInsert(tstream, test, groupIndex)) {
			CheckInsetKDTreeForObject(tstream, test, object);
		}
		else {
			objectPool.ReleaseObject(object);
		}
		return;
	}
	else {
		while (temNode->GetParentNode() != nullptr) {
			temNode = temNode->GetParentNode();
			stackNode.push(temNode);
		}
		while (!stackNode.empty()) { 
			if (stackNode.front()->GetParentNode() != nullptr) {
				temNode = stackNode.front()->GetParentNode();
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetNodeId() != stackNode.front()->GetNodeId() && node->CalMinDisToNode(tstream, test, child.second) <= r) {
						queNode.push(child.second);
					}
				}
			}
			stackNode.pop();
			while (!queNode.empty()) {
				temNode = queNode.front();
				if (temNode->GetMaintainDataNum() > 0) {
					AddNeighborInIntermediateNode(tstream, test, object, temNode, groupIndex, neighborNum, posIndex, NodeList);
				}
				queNode.pop();
			}
		}
		if (neighborNum < test.GetK()) {
			temList.clear();
			if (object->GetONrNodeList(temList)) {
				for (auto nodeInONrId : temList) {
					nodeInONr = nodePool.GetNodeByNodeId(nodeInONrId);
					if (nodeInONr != nullptr) {
						AddRhoNeihborForObject(tstream, test, object, nodeInONr, groupIndex, neighborNum, startIndex, posIndex);
						if (neighborNum >= test.GetK()) {
							break;
						}
					}
				}
			}
			for (auto leafNode : NodeList) {
				for (int i = startIndex; i < posIndex; ++i) {
					if (neighborNum >= test.GetK()) {
						break;
					}
					if (i == startIndex) {
						for (auto id : leafNode->GetCObjGroupById(i)->GetObjectList()) {
							if (id < tstream.GetDataStreamBegin()) {
								break;
							}
							if (id != object->GetObjectId() && tstream.CalTwoObjectRealDistance(object->GetObjectId(), id, test.GetDim()) <= r) {
								groupIndex[i]++;
								neighborNum++;
							}
						}
					}
					else {
						for (auto id : leafNode->GetCObjGroupById(i)->GetObjectList()) {
							if (id != object->GetObjectId() && tstream.CalTwoObjectRealDistance(object->GetObjectId(), id, test.GetDim()) <= r) {
								groupIndex[i]++;
								neighborNum++;
							}
						}
					}
				}
			}
			if (neighborNum < test.GetK()) {
				if (tstream.GetObjectSlideId(object->GetObjectId()) > tstream.GetSlideBegin()) {
					kdTreeRoot->InsertObject(tstream, test, object);
					kdTreeRoot->AddMaintainNum();
					object->CalAlarmTime(tstream, test, groupIndex);
				}
				else {
					objectPool.ReleaseObject(object);
					changeRMap.emplace(objId, node);
				}
			}
			else {
				if (object->CheckNeedInsert(tstream, test, groupIndex)) {
					CheckInsetKDTreeForObject(tstream, test, object);
				}
				else {
					objectPool.ReleaseObject(object);
				}
			}
			return;
		}
		else {
			if (object->CheckNeedInsert(tstream, test, groupIndex)) {
				CheckInsetKDTreeForObject(tstream, test, object);
			}
			else {
				objectPool.ReleaseObject(object);
			}
			return;
		}
	}
}

void CKNode::ReDealKNodeLarge(TStream& tstream, Test& test)
{
	for (auto kNodeL = kNodeLarge.begin(); kNodeL != kNodeLarge.end();) {
		if ((*kNodeL)->CalDiagonalLength(test.GetVirtualDim()) <= test.GetL_kThreshold()) {
			kNodeSmall.push_back(*kNodeL);
			kNodeL = kNodeLarge.erase(kNodeL);
			continue;
		}
		kNodeL++;
	}
	E_I.clear();
	E_L.clear();
	DivideKNodeLargeIntoE_IAndE_L(tstream, test);
}

void CKNode::DealExpeirSlide(TStream& tstream, Test& test)
{
	int startIndex = GetStartIndex(tstream, test);
	for (int i = 0; i < startIndex; ++i) {
		slideArray[i]->Clear();
	}
}

void CKNode::DealE_LChildNode(TStream& tstream, Test& test, CNode* node)
{
	if (node->GetChildNodeNum() != 0) {
		queue<CNode*> queNode;
		CNode* temNode = nullptr;
		queNode.push(node);
		while (queNode.empty()) {
			temNode = queNode.front();
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetMaintainDataNum() != 0) {
						queNode.push(child.second);
					}
				}
			}
			else {
				for (auto& objId : temNode->GetCObjGroupById(GetEndIndex(tstream, test) - 1)->GetObjectList()) {
					DealObjInLargeLeafNode(tstream, test, objId, temNode);
				}
			}
			temNode = nullptr;
			queNode.pop();
		}
	}
	else {
		for (auto& objId : node->GetCObjGroupById(GetEndIndex(tstream, test) - 1)->GetObjectList()) {
			DealObjInLargeLeafNode(tstream, test, objId, node);
		}
	}
}

void CKNode::DealE_LObjChildNode(TStream& tstream, Test& test, CNode* node)
{
	if (node->GetChildNodeNum() != 0) {
		queue<CNode*> queNode;
		CNode* temNode = nullptr;
		queNode.push(node);
		while (queNode.empty()) {
			temNode = queNode.front();
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetMaintainDataNum() != 0) {
						queNode.push(child.second);
					}
				}
			}
			else {
				for (auto& objId : temNode->GetCObjGroupById(GetEndIndex(tstream, test) - 1)->GetObjectList()) {
					CreateONrForObject(tstream, test, objId, temNode);
				}
			}
			temNode = nullptr;
			queNode.pop();
		}
	}
	else {
		for (auto& objId : node->GetCObjGroupById(GetEndIndex(tstream, test) - 1)->GetObjectList()) {
			CreateONrForObject(tstream, test, objId, node);
		}
	}	
}

void CKNode::Change_RDealE_LChildNode(TStream& tstream, Test& test, CNode* node)
{
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	if (node->GetChildNodeNum() != 0) {
		queue<CNode*> queNode;
		CNode* temNode = nullptr;
		queNode.push(node);
		while (queNode.empty()) {
			temNode = queNode.front();
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetMaintainDataNum() != 0) {
						queNode.push(child.second);
					}
				}
			}
			else {
				for (int i = startIndex; i < endIndex; ++i) {
					for (auto& objId : node->GetCObjGroupById(i)->GetObjectList()) {
						if (objId < tstream.GetDataStreamBegin()) {
							break;
						}
						DealObjInLargeLeafNode(tstream, test, objId, node);
					}
				}
			}
			temNode = nullptr;
			queNode.pop();
		}
	}
	else {
		for (int i = startIndex; i < endIndex; ++i) {
			for (auto& objId : node->GetCObjGroupById(i)->GetObjectList()) {
				if (objId < tstream.GetDataStreamBegin()) {
					break;
				}
				DealObjInLargeLeafNode(tstream, test, objId, node);
			}
		}
	}	
}

void CKNode::Change_RCreateONrForObject(TStream& tstream, Test& test, CNode* node)
{
	int startIndex = GetStartIndex(tstream, test);
	int endIndex = GetEndIndex(tstream, test);
	if (node->GetChildNodeNum() != 0) {
		queue<CNode*> queNode;
		CNode* temNode = nullptr;
		queNode.push(node);
		while (queNode.empty()) {
			temNode = queNode.front();
			if (temNode->GetChildNodeNum() != 0) {
				for (auto child : temNode->GetChildList()) {
					if (child.second->GetMaintainDataNum() != 0) {
						queNode.push(child.second);
					}
				}
			}
			else {
				for (int i = startIndex; i < endIndex; ++i) {
					for (auto& objId : temNode->GetCObjGroupById(i)->GetObjectList()) {
						if (objId < tstream.GetDataStreamBegin()) {
							break;
						}
						CreateONrForObject(tstream, test, objId, temNode);
					}
				}
			}
			temNode = nullptr;
			queNode.pop();
		}
	}
	else {
		for (int i = startIndex; i < endIndex; ++i) {
			for (auto& objId : node->GetCObjGroupById(i)->GetObjectList()) {
				if (objId < tstream.GetDataStreamBegin()) {
					break;
				}
				CreateONrForObject(tstream, test, objId, node);
			}
		}
	}
}

int CKNode::GetStartIndex(TStream& tstream, Test& test)
{
	return tstream.GetSlideBegin() / test.GetMapCount();
}

int CKNode::GetEndIndex(TStream& tstream, Test& test)
{
	return tstream.GetSlideTag() / test.GetMapCount() + 1;
}

void CKNode::CheckInsetKDTreeForObject(TStream& tstream, Test& test, CObject* object)
{
	kdTreeRoot->InsertObject(tstream, test, object);
	kdTreeRoot->AddMaintainNum();
	object->ReleaseonrNodeList(tstream, test);
}

void CKNode::RegularCleanUpSlideArray(int& deleteSlideArrayTag, int deleteEndTag)
{
	for (int i = deleteSlideArrayTag; i < deleteEndTag; ++i) {
		slideArray[i]->Clear();
	}
}

void CKNode::OutputMemory()
{
	std::cout << "Init DataSet Memory = " << initDataSetMemory << " MB" << endl;
	std::cout << "Init Memory = " << averageMemory[0] << " MB" << endl;
	std::cout << "Finally Memory = " << averageMemory[averageMemory.size()-1] << " MB" << endl;
	std::cout << "Peak Memory = " << peakMemory << " MB" << endl;
}

double CKNode::GetInitDataSetMemory()
{
	return this->initDataSetMemory;
}

double CKNode::GetAverageMemory()
{
	double count = 0;
	double dataSetMemory = GetInitDataSetMemory();
	for (int i = 0; i < averageMemory.size(); ++i) {
		count += (averageMemory[i] - GetInitDataSetMemory());
	}
	return count / averageMemory.size();
}

double CKNode::GetPeakMemory()
{
	return this->peakMemory - GetInitDataSetMemory();
}

short CKNode::GetCountSlideNum()
{
	return this->countSlideNum;
}

void CKNode::DestroyRoot()
{
	std::function<void(CNode*)> release_node_pointer = [this](CNode* needReleaseNode) {
		if (needReleaseNode)
		{
			nodePool.ReleaseNode(needReleaseNode);
		}
		};
	this->root->ReleaseAllChildren(release_node_pointer);
	nodePool.ReleaseNode(root);
}

void CKNode::DestroySlideArray()
{
	for (int i = 0; i < slideArray.size(); ++i) {
		slideArray[i]->Clear();
	}
	for (CSlide* slide : slideArray)
	{
		if (slide != nullptr)
		{
			delete slide;
		}
	}
	slideArray.clear();
	std::vector<CSlide*>().swap(slideArray);
}
