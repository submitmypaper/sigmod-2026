#include "TStream.h"

TStream::TStream()
{
    streamFront = 0;
    idx = 1;
    maxSideLength = 0.0;
    dataStreamBegin = 0;
    dataStreamTag = 0;
    totalSlideNum = 0;
	slideBegin = 0;
	slideTag = 0;
}

TStream::~TStream()
{
}
vector<double>& TStream::GetValue(int id)
{
	return dataStream[id];
}

vector<float>& TStream::GetVirtualValue(int id)
{
	return virtualDataStream[id];
}

void TStream::ReadFile(Test& t, int j)
{
	string fileName = "SourceFile" + to_string(j) + ".txt";
	FILE* fp;
	int dim = t.GetDim();
	int flag = 0;
	vector<double>vTemp(dim);
	double temp;
	vector<double> minDimension(dim, DBL_MAX);
	vector<double> maxDimension(dim, 0.0);
	if ((fp = fopen(fileName.data(), "r")) != NULL) {
		while (fscanf(fp, "%lf", &temp) != EOF) {
			if (temp < minDimension[flag]) {
				minDimension[flag] = temp;
			}
			if (temp > maxDimension[flag]) {
				maxDimension[flag] = temp;
			}
			vTemp[flag++] = temp;
			if (flag % dim == 0) {
				dataStream.push_back(vTemp);
				vTemp.clear();
				vTemp.resize(dim);
				flag = 0;
			}
		}
	}
	everyDimensionMinAndMax.resize(2 * dim);
	for (auto i = 0; i < dim; ++i) {
		if (maxSideLength < (maxDimension[i] - minDimension[i])) {
			maxSideLength = maxDimension[i] - minDimension[i];
		}
		everyDimensionMinAndMax[i * 2] = minDimension[i];
		everyDimensionMinAndMax[i * 2 + 1] = maxDimension[i];
	}
	ChooseVirtualDim(t);
	fileName = "change_s.txt";
	int temp2;
	if ((fp = fopen(fileName.data(), "r")) != NULL) {
		while (fscanf(fp, "%d", &temp2) != EOF) {
			if (t.GetDim() == 3) {
				s_change.push_back(temp2 / 10);
			}
			else {
				s_change.push_back(temp2);
			}
		}
	}
	else {
		int temp = 5000;
		if (t.GetDim() == 3)temp = 500;
		s_change = vector<int>(temp, 5000);
	}
	int dataObjTotalNum = dataStream.size();
	int tag = 0;
	pointSet.resize(dataStream.size());
	for (int i = 0; i < s_change.size(); ++i) {
		for (int j = 0; j < s_change[i]; ++j) {
			pointSet[tag++] = i;
			if (tag == dataStream.size()) {
				break;
			}
		}
		dataObjTotalNum -= s_change[i];
		if (dataObjTotalNum <= 0) {
			totalSlideNum = i + 1;
			break;
		}
	}
}

int TStream::GetS_Change(int time)
{
	return s_change[time];
}

void TStream::ExpendS_Change()
{
	s_change.push_back(s_change[idx++]);
}

int TStream::GetDataStreamSize()
{
	return dataStream.size();
}

void TStream::SetDataStreamBegin(int beginId)
{
	dataStreamBegin = beginId;
}

void TStream::SetDataStreamTag(int endId)
{
	dataStreamTag = endId;
}

void TStream::SetSlideBegin(int beginSlideId)
{
	slideBegin = beginSlideId;
}

void TStream::SetSlideTag(int endSlideId)
{
	slideTag = endSlideId;
}

void TStream::AddDataStreamBegin(int addNum)
{
	dataStreamBegin += addNum;
}

void TStream::AddDataStreamTag(int addNum)
{
	dataStreamTag += addNum;
}

void TStream::AddSlideBegin(int addNum)
{
	slideBegin += addNum;
}

void TStream::AddSlideTag(int addNum)
{
	slideTag += addNum;
}

int TStream::GetDataStreamBegin()
{
	return dataStreamBegin;
}

int TStream::GetDataStreamTag()
{
	return dataStreamTag;
}

int TStream::GetSlideBegin()
{
	return slideBegin;
}

int TStream::GetSlideTag()
{
	return slideTag;
}

double TStream::GetEveryDimensionMinAndMax(int dimension, int index)
{
	return everyDimensionMinAndMax[dimension * 2 + index];
}

double TStream::GetMaxSideLength()
{
	return maxSideLength;
}

short TStream::GetTotalSlideNum()
{
	return totalSlideNum;
}

double TStream::GetDataCoordinates(int id, int dimension)
{
	vector<double> data = GetValue(id);
	return data[dimension];
}

double TStream::GetVirtualDataCoordinates(int id, int dimension)
{
	vector<float> data = virtualDataStream[id];
	return data[dimension];
}

void TStream::ChooseVirtualDim(Test& t)
{
	vector<double> diffDimension(t.GetDim());
	vector<int> virtualDimNumber;
	double maxDiff = 0;
	for (int i = 0; i < t.GetDim(); ++i) {
		diffDimension[i] = everyDimensionMinAndMax[i * 2 + 1] - everyDimensionMinAndMax[i * 2];
		if (diffDimension[i] > maxDiff) {
			maxDiff = diffDimension[i];
		}
	}

	double  thresholdRatio = t.GetVirtualDimThreshold();

	double relativeDiff = 0;
	for (int i = 0; i < t.GetDim(); ++i) {
		if (maxDiff == 0) {
			break;
		}
		relativeDiff = diffDimension[i] / maxDiff;
		if (relativeDiff > thresholdRatio) {
			virtualDimNumber.push_back(i);
		}
	}
	t.SetVirtualDim(virtualDimNumber.size());
	vector<float> temValue;
	for (int i = 0; i < dataStream.size(); ++i) {
		for (int j = 0; j < virtualDimNumber.size(); ++j) {
			temValue.push_back(GetDataCoordinates(i, virtualDimNumber[j]));
		}
		virtualDataStream.push_back(temValue);
		temValue.clear();
	}
	vector<double> temEveryDimensionMinAndMax = this->everyDimensionMinAndMax;
	this->everyDimensionMinAndMax.clear();
	for (int i = 0; i < virtualDimNumber.size(); ++i) {
		this->everyDimensionMinAndMax.push_back(temEveryDimensionMinAndMax[virtualDimNumber[i] * 2]);
		this->everyDimensionMinAndMax.push_back(temEveryDimensionMinAndMax[virtualDimNumber[i] * 2 + 1]);
	}
}

int TStream::GetObjectSlideId(int objId)
{
	return pointSet[objId];
}

double TStream::CalTwoObjectRealDistance(int id1, int id2, int dimension)
{
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(dataStream[id1][i] - dataStream[id2][i], 2);
	}
	return sqrt(dis);
}

