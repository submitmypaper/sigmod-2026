#include "CNodePool.h"
CNodePool::CNodePool(): count(0) {

}

CNodePool::~CNodePool()
{
    for (auto it = globalNodeTable.begin(); it != globalNodeTable.end(); ++it)
        delete it->second;
    while (!pool.empty()) {
        delete pool.front();
        pool.pop();
    }
    unordered_map<int, CNode*>().swap(globalNodeTable);
    count = 0;
}

void CNodePool::Initialize(int initializeSize)
{
    for (int i = 0; i < initializeSize; ++i) {
        CNode* node = new CNode(count++);
        pool.push(node);
    }
}

CNode* CNodePool::AcquireNode()
{
    if (pool.empty()) {
        const int m = 100;
        for (int i = 0; i < m; ++i) {
            CNode* node = new CNode(count++);
            pool.push(node);
        }
    }
    CNode* node = pool.front();
    pool.pop();
    globalNodeTable[node->GetNodeId()] = node;
    return node;
}

void CNodePool::ReleaseNode(CNode* needReleaseNode)
{
    globalNodeTable.erase(needReleaseNode->GetNodeId());
    needReleaseNode->Reset(count++);
    pool.push(needReleaseNode);
}

CNode* CNodePool::GetNodeByNodeId(int id)
{
    auto it = globalNodeTable.find(id);
    return (it != globalNodeTable.end()) ? it->second : nullptr;
}

void CNodePool::DestroyNodePool()
{
    unordered_map<int, CNode*>().swap(globalNodeTable);
    while (!pool.empty())
    {
        CNode* node = pool.front();
        pool.pop();
        if (node != nullptr)
        {
            delete node;
        }
    }
    count = 0;
}


void CNodePool::CheckLeafAndInterMediateNodeNum()
{
    int intermediateNum = 0;
    int leafNum = 0;
    for (auto node : globalNodeTable) {
        if (node.second->GetChildNodeNum() != 0) {
            intermediateNum++;
        }
        else {
            leafNum++;
        }
    }
    cout << "Leaf Node Number = " << leafNum << "      Intermediate Node Number = " << intermediateNum << endl;
}

void CNodePool::ReleaseNodePool()
{
    CNode* temNode = nullptr;
    while (!pool.empty()) {
        temNode = pool.front();
        pool.pop();
        delete temNode;
        temNode = nullptr;
    }
}
