#ifndef TStream_h
#define TStream_h
#include"head.h"
#include"Test.h"
#include"Count.h"
class TStream
{
private:
	vector<vector<double>>dataStream;
	vector<vector<float>>virtualDataStream;
	int streamFront;		
	vector<int>s_change;	
	int idx;				
	double maxSideLength;
	vector<double> everyDimensionMinAndMax;
	int dataStreamBegin;
	int dataStreamTag;
	int slideBegin;
	int slideTag;
	short totalSlideNum;
	vector<int> pointSet;
public:
	TStream();
	~TStream();

	vector<double>& GetValue(int id);
	vector<float>& GetVirtualValue(int id);

	void ReadFile(Test& t, int j);

	int GetS_Change(int time);
	void ExpendS_Change();
	int GetDataStreamSize();
	void SetDataStreamBegin(int beginId);
	void SetDataStreamTag(int endId);
	void SetSlideBegin(int beginSlideId);
	void SetSlideTag(int endSlideId);
	void AddDataStreamBegin(int addNum);
	void AddDataStreamTag(int addNum);
	void AddSlideBegin(int addNum);
	void AddSlideTag(int addNum);
	int GetDataStreamBegin();
	int GetDataStreamTag();
	int GetSlideBegin();
	int GetSlideTag();
	double GetEveryDimensionMinAndMax(int dimension, int index);
	double GetMaxSideLength();
	short GetTotalSlideNum();
	double GetDataCoordinates(int id, int dimension);
	double GetVirtualDataCoordinates(int id, int dimension);
	void ChooseVirtualDim(Test& t);
	int GetObjectSlideId(int objId);
	double CalTwoObjectRealDistance(int id1, int id2, int dimension);
};

#endif