#ifndef CNodePool_h
#define CNodePool_h
#include"head.h"
#include"CNode.h";


class CNodePool
{
private:
	queue<CNode*> pool;
	unordered_map<int, CNode*> globalNodeTable;
	int count;
public:
	CNodePool();
	~CNodePool();
	void Initialize(int initializeSize);
	CNode* AcquireNode();
	void ReleaseNode(CNode* needReleaseNode);
	CNode* GetNodeByNodeId(int id);
	void DestroyNodePool();

	void CheckLeafAndInterMediateNodeNum();
	void ReleaseNodePool();
};

#endif