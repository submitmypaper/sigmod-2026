#include "Tstream.h"
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "CPOD.h"
#include<stack>
#include<unordered_map>
#include <numeric> 
#include <string>
#include<float.h>
Tstream::Tstream()
{
}

Tstream::~Tstream()
{
}
void Tstream::readDataFile(Test& test, int j)
{
	FILE* fp1;
	double dlNumber;
	int dimension = test.getDimension();
	vector<double> minDimension(dimension, DBL_MAX);
	vector<double> maxDimension(dimension, 0.0);
	int i = 0;
	string a = to_string(j);
	string s = "SourceFile" + a + ".txt";
	if ((fp1 = fopen(s.data(), "r")) != NULL)
	{
		while (fscanf(fp1, "%lf", &dlNumber) != EOF)
		{
			if (dlNumber < minDimension[i % dimension]) {
				minDimension[i % dimension] = dlNumber;
			}
			if (dlNumber > maxDimension[i % dimension]) {
				maxDimension[i % dimension] = dlNumber;
			}
			i++;
			vecDataStream.push_back(dlNumber);
		}
	}
	for (i = 0; i < dimension; ++i) {
		centralCoordinate.push_back((maxDimension[i] + minDimension[i]) / 2);
	}
	vector<double> dis;
	for (i = 0; i < dimension; ++i) {
		dis.push_back((maxDimension[i] - minDimension[i]) * sqrt(test.getDimension()) / 2);
	}
	double max;
	max = *max_element(dis.begin(), dis.end());
	firstRadius = max;
	updateNeighborNum.resize(7340032, 0);
}


double Tstream::getDataStream(int intObjectNumber)
{
	return vecDataStream[intObjectNumber];
}

vector<double> Tstream::getData(int dataId, int dimension) {
	vector<double> ans;
	for (int i = 0; i < dimension; ++i) {
		ans.push_back(vecDataStream[dimension * dataId + i]);
	}
	return ans;
}

int Tstream::getDataStreamLength()
{
	return vecDataStream.size();
}


int Tstream::getDataStreamBegin()
{
	return dataStreamBegin;
}

int Tstream::getDataStreamTag()
{
	return dataStreamTag;
}

vector<double> Tstream::getCentralCoordinate() {
	return centralCoordinate;
}

void Tstream::setDataStreamBegin(int begin)
{
	dataStreamBegin = begin;
}

void Tstream::setDataStreamTag(int tag)
{
	dataStreamTag = tag;
}

void Tstream::Init(Test& test, int j)
{
	readDataFile(test, j);
	setS_change(test);
}

void Tstream::addDataStreamBegin(int outFlow)
{
	dataStreamBegin += outFlow;
}

void Tstream::addDataStreamTag(int inFlow)
{
	dataStreamTag += inFlow;
}

double Tstream::getFirstRadius() {
	return firstRadius;
}

void Tstream::addUpdateNeighborNumById(Test& test, int id)
{
	if (updateNeighborNum[id] < (test.getK() + 1)) {
		updateNeighborNum[id]++;
	}
}

void Tstream::setUpdateNeighborNumById(int id, int num)
{
	updateNeighborNum[id] = num;
}

unsigned short Tstream::getUpdateNeighborNumById(int id)
{
	return updateNeighborNum[id];
}

void Tstream::resetupdateNeighborNum()
{
	for (int i = 0; i < updateNeighborNum.size();++i) {
		updateNeighborNum[i] = 0;
	}
}

int Tstream::getvecDataStreamNum(int dimension)
{
	return vecDataStream.size() / dimension;
}

void Tstream::setS_change(Test& test)
{
	string s = "change_s.txt";
	FILE* fp;
	int tempS;
	if ((fp = fopen(s.data(), "r")) != NULL) {
		while (fscanf(fp, "%d", &tempS) != EOF) {
			if (test.getDimension() == 3) {
				S_change.push_back(tempS / 10);
			}
			else {
				S_change.push_back(tempS);
			}
		}
	}
	int dataObjTotalNum = getvecDataStreamNum(test.getDimension());
	int tag = 0;
	for (int i = 0; i < S_change.size(); ++i) {
		dataObjTotalNum -= S_change[i];
		if (dataObjTotalNum <= 0) {
			totalSlideNum = i + 1;
			break;
		}
	}
}

int Tstream::getS_change(int idx)
{
	return S_change[idx];
}

void Tstream::addChangeTimes()
{
	ChangeTimes++;
}

int Tstream::getChangeTimes()
{
	return ChangeTimes;
}

short Tstream::getTotalSlideNum()
{
	return this->totalSlideNum;
}
