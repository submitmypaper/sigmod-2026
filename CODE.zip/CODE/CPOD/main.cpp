#include<stdio.h>
#include<iostream>
#include<fstream>
#include"CPOD.h"
#include"Test.h"
#include"Tstream.h"
#include <ctime>
#include <iomanip>
#include "string"
#include<float.h>
void printlogmain(Tstream& Tstream, Test& test, double time2, double time3) {
	ofstream data;
	data.open("CPODLogFlie.txt", ofstream::app);
	data << "Dimension= " << test.getDimension() << " N= " << test.getWindowSize() << " K= " << test.getK() << endl;
	data << "InitTime��" << time2 << "s" << endl;
	data << "RunningTime��" << time3 << "s" << endl;
	data.close();
}

int main()
{
	clock_t startTime, endTime;
	double initTime;
	for (int j = 0; j < 5; j++) {
		Test t;
		Tstream Tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile, j);
		Tstream.Init(vecTestFile[0], j);
		for (int i = 0; i < vecTestFile.size(); i++) {
			if (i != 0) {
				Tstream.resetupdateNeighborNum();
			}
			mTreeOfCorePoint mtreeOfCP;
			mtreeOfCP.setChildNodeSplitNum(16);
			mtreeOfCP.setDataObjSplitNum(8);
			startTime = clock();
			mtreeOfCP.Init(Tstream, vecTestFile[i]);
			endTime = clock();
			std::cout << std::fixed << std::setprecision(3);
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << 's' << endl;
			startTime = clock();
			mtreeOfCP.Update(Tstream, vecTestFile[i]);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			printlogmain(Tstream, vecTestFile[i], initTime, (double)(endTime - startTime) / CLOCKS_PER_SEC);
		}
	}
	return 0;
}