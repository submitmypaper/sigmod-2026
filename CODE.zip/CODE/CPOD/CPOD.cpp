﻿#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "Tstream.h"
#include"Test.h"
#include "CPOD.h"
#include<stack>
#include<unordered_map>
#include<unordered_set>
#include <numeric> 
#include<fstream>
#include <math.h>
#include <windows.h>
#include <psapi.h>
#include<float.h>
#pragma comment(lib, "psapi.lib")
#define maxRThreshold 0.5
double getProcessMemoryMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	GetProcessMemoryInfo(GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc));

	return pmc.WorkingSetSize / (1024.0 * 1024.0);
}

double getPeakProcessMemoryMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	if (!GetProcessMemoryInfo(
		GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc)))
	{
		return 0.0;
	}

	return pmc.PeakWorkingSetSize / (1024.0 * 1024.0);
}

double getPrivateUsageMB()
{
	PROCESS_MEMORY_COUNTERS_EX pmc;
	GetProcessMemoryInfo(
		GetCurrentProcess(),
		(PROCESS_MEMORY_COUNTERS*)&pmc,
		sizeof(pmc)
	);
	return pmc.PrivateUsage / (1024.0 * 1024.0);
}

mTreeOfCorePoint::mTreeOfCorePoint()
{
}

mTreeOfCorePoint::~mTreeOfCorePoint()
{
	clearSlideVec();
	clearAll();
	delete root;
	clearPointSet();
	outlier.clear();
	set<int>().swap(outlier);
	averageMemory.clear();
	vector<double>().swap(averageMemory);
}

void mTreeOfCorePoint::setChildNodeSplitNum(int num)
{
	childNodeSplitNum = num;
}

void mTreeOfCorePoint::setDataObjSplitNum(int num)
{
	dataObjSplitNum = num;
}

double mTreeOfCorePoint::calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id1 * dimension + i) - tstream.getDataStream(id2 * dimension + i), 2);
	}
	return sqrt(dis);
}

double mTreeOfCorePoint::calculateDistanceBycoordinate(Tstream& tstream, Test& test, int id, Data data)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id * dimension + i) - data[i], 2);
	}
	return sqrt(dis);
}

double mTreeOfCorePoint::calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(data1[i] - data2[i], 2);
	}
	return sqrt(dis);
}

void mTreeOfCorePoint::Init(Tstream& tstream, Test& test)
{
	tstream.setDataStreamBegin(0);
	initDataSetMemory = getProcessMemoryMB();
	int dimension = test.getDimension();
	double r = test.getR();
	int dataNum = 0;
	double dis = 0;
	int dataFront = 0;
	int dataBack = 0;
	slideSize = test.getWindowSize();
	root = new Node;
	root->id = nodeIdCount++;
	root->radius = tstream.getFirstRadius();
	root->disToParent = 0;
	root->coordinate = tstream.getCentralCoordinate();
	root->parentNode = nullptr;
	for (int i = 0; i < slideSize; i++) {
		dataNum += tstream.getS_change(i);
	}
	tstream.setDataStreamTag(dataNum);
	for (int i = 0; i < dataNum; ++i) {
		bool flag = false;
		for (auto coreP : root->corePointList) {
			dis = calculateDistanceBycoordinate(tstream, test, i, (*coreP).corePointCoordinate);
			if (dis <= r) {
				flag = true;
				break;
			}
		}
		if (!flag) {
			CorePoint* newCorePoint = new CorePoint;
			newCorePoint->corePointCoordinate = tstream.getData(i, dimension);
			root->corePointList.push_back(newCorePoint);
		}
	}
	splitMTree(tstream, test);
	for (int i = 0; i < slideSize; i++) {
		int temp = dataBack;
		dataBack += tstream.getS_change(i);
		for (int j = temp; j < dataBack; j++) {
			dataObj* data = new dataObj;
			data->id = j;
			data->slideID = i;
			addDataObjToMTree(tstream, test, data, root);
			PointSet[j] = data;
		}
	}
	findOutlier(tstream, test);
	int windowObjNum = calWindowMaintainObjNum(tstream, test);
	int lowerBound = 0.005 * windowObjNum;
	int upperBound = 0.02 * windowObjNum;
	if (outlier.size() < lowerBound || outlier.size() > upperBound) {
		checkChangeR(tstream, test);
	}
	averageMemory.push_back(getProcessMemoryMB());
}

void mTreeOfCorePoint::splitMTree(Tstream& tstream, Test& test)
{
	queue<Node*> needSplitNode;
	double r = test.getR();
	vector<double> subTreeCoordinate;
	int dimension = test.getDimension();
	needSplitNode.push(root);
	Node* splitNode = nullptr;
	double dis;
	double disMin;
	Node* chooseNode = nullptr;
	Node* temNode = nullptr;
	while (!needSplitNode.empty()) {
		subTreeCoordinate.clear();
		splitNode = needSplitNode.front();
		while (splitNode->corePointList.size() != 0) {
			if (splitNode->childNodeList.size() == childNodeSplitNum) {
				break;
			}
			chooseSubInSurplusEntry(tstream, test, subTreeCoordinate, splitNode);
			for (int i = 0; i < subTreeCoordinate.size() / dimension; ++i) {
				createNode(tstream, test, subTreeCoordinate, splitNode, i);
			}
			subTreeCoordinate.clear();
			addCorePointToSubTree(tstream, test, splitNode);
		}
		if (splitNode->corePointList.size() != 0) {
			for (auto cp = splitNode->corePointList.begin(); cp != splitNode->corePointList.end();) {
				chooseNode = nullptr;
				disMin = DBL_MAX;
				for (auto child : splitNode->childNodeList) {
					dis = calculateDistanceBetweenTwoData(tstream, test, (*cp)->corePointCoordinate, child->coordinate);
					if (dis < disMin) {
						disMin = dis;
						chooseNode = child;
					}
				}
				chooseNode->corePointList.push_back(*cp);
				chooseNode->radius = max(chooseNode->radius, disMin);
				splitNode->corePointList.erase(cp++);
			}
		}
		for (auto child = splitNode->childNodeList.begin(); child != splitNode->childNodeList.end();) {
			if ((*child)->childNodeList.size() == 0 && (*child)->corePointList.size() == 0) {
				temNode = *child;
				splitNode->childNodeList.erase(child++);
				delete temNode;
				temNode = nullptr;
				continue;
			}
			else if ((*child)->childNodeList.size() == 0 && (*child)->corePointList.size() > dataObjSplitNum) {
				needSplitNode.push(*child);
			}
			child++;
		}
		needSplitNode.pop();
	}
}

void mTreeOfCorePoint::Init(Tstream& tstream, Test& test, int tstreamBegin, int tstreamTag)
{
	int dimension = test.getDimension();
	double r = test.getR();
	int dataNum = 0;
	double dis = 0;
	clearAll();
	Node* newroot = new Node;
	newroot = new Node;
	newroot->id = nodeIdCount++;
	newroot->radius = tstream.getFirstRadius();
	newroot->disToParent = 0;
	newroot->coordinate = tstream.getCentralCoordinate();
	newroot->parentNode = nullptr;
	for (int i = tstreamBegin; i < tstreamTag; ++i) {
		bool flag = false;
		for (auto coreP : newroot->corePointList) {
			dis = calculateDistanceBycoordinate(tstream, test, i, (*coreP).corePointCoordinate);
			if (dis <= r) {
				flag = true;
				break;
			}
		}
		if (!flag) {
			CorePoint* newCorePoint = new CorePoint;
			newCorePoint->corePointCoordinate = tstream.getData(i, dimension);
			newroot->corePointList.push_back(newCorePoint);
		}
	}
	root = newroot;
	splitMTree(tstream, test);
	for (int i = tstreamBegin; i < tstreamTag; ++i) {
		PointSet[i]->AllNeighborNum = 0;
		PointSet[i]->closeCore = nullptr;
		PointSet[i]->CPInHalfRToR.clear();
		PointSet[i]->dataState = false;
		PointSet[i]->vecNeighborNum = 0;
		PointSet[i]->vecNeighborSlide.clear();
		PointSet[i]->vecNeighborSlide.resize(slideSize);
		addDataObjToMTree(tstream, test, PointSet[i], root);
	}
	for (int i = 0; i < slideSize;++i) {
		slideVec[i].needDealCP.clear();
		slideVec[i].needDealDataObj.clear();
	}
	outlierNum = 0;
	outlier.clear();
	changeRFindOutlier(tstream, test);
}

void mTreeOfCorePoint::chooseSubInSurplusEntry(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node)
{
	int dimension = test.getDimension();
	double maxNum;
	double minNum;
	double tem;
	vector<double> v1;
	vector<double> v2;
	map<double, pair<vector<double>, vector<double>>> Map;
	for (int i = 0; i < dimension; ++i) {
		maxNum = -10;
		minNum = DBL_MAX;
		for (auto cpoint : node->corePointList) {
			tem = (*cpoint).corePointCoordinate[i];
			if (tem > maxNum) {
				maxNum = tem;
				v1 = (*cpoint).corePointCoordinate;
			}
			if (tem < minNum) {
				minNum = tem;
				v2 = (*cpoint).corePointCoordinate;
			}
		}
		Map.emplace(maxNum - minNum, make_pair(v1, v2));
	}
	for (int i = 0; i < dimension; ++i) {
		subTreecoordinate.push_back(((*Map.rbegin()).second.first[i] * 3 + (*Map.rbegin()).second.second[i]) / 4);
	}
	for (int i = 0; i < dimension; ++i) {
		subTreecoordinate.push_back(((*Map.rbegin()).second.first[i] + (*Map.rbegin()).second.second[i] * 3) / 4);
	}
}

void mTreeOfCorePoint::createNode(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node, int id)
{
	int dimension = test.getDimension();
	Node* childNode = new Node();
	childNode->parentNode = node;
	childNode->id = nodeIdCount++;
	for (int i = 0; i < dimension; ++i) {
		childNode->coordinate.push_back(subTreecoordinate[id * dimension + i]);
	}
	childNode->disToParent = calculateDistanceBetweenTwoData(tstream, test, childNode->coordinate, node->coordinate);
	node->childNodeList.push_back(childNode);
}

void mTreeOfCorePoint::addCorePointToSubTree(Tstream& tstream, Test& test, Node* node)
{
	Node* chooseNode = nullptr;
	double dis;
	double minDis;
	double r = test.getR();
	for (auto cp = node->corePointList.begin(); cp != node->corePointList.end();) {
		minDis = DBL_MAX;
		chooseNode = nullptr;
		for (auto child : node->childNodeList) {
			dis = calculateDistanceBetweenTwoData(tstream, test, (*cp)->corePointCoordinate, child->coordinate);
			if (dis < minDis && dis <= (child->parentNode->radius * maxRThreshold)) {
				minDis = dis;
				chooseNode = child;
			}
		}
		if (chooseNode != nullptr) {
			chooseNode->corePointList.push_back(*cp);
			chooseNode->radius = max(chooseNode->radius, minDis);
			node->corePointList.erase(cp++);
			continue;
		}
		cp++;
	}
}

void mTreeOfCorePoint::addDataObjToMTree(Tstream& tstream, Test& test, dataObj* data, Node* node)
{
	queue<Node*> checkNodeQueue;
	double dis;
	double r = test.getR();
	checkNodeQueue.push(node);
	Node* temNode = nullptr;
	while (!checkNodeQueue.empty()) {
		temNode = checkNodeQueue.front();
		if (temNode->childNodeList.size() == 0) {
			for (auto cp : temNode->corePointList) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, cp->corePointCoordinate);
				if (dis <= r / 2) {
					data->closeCore = cp;
					cp->dequeE0.push_front(data->id);
				}
				else if (dis <= r) {
					data->CPInHalfRToR.push_back(cp);
					cp->dequeE1.push_front(data->id);
				}
				else if (dis <= 2 * r) {
					if (dis <= 3 * r / 2) {
						cp->dequeE2.push_front(data->id);
					}
					else {
						cp->dequeE3.push_front(data->id);
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, child->coordinate) - child->radius;
				if (dis <= (2 * test.getR())) {
					checkNodeQueue.push(child);
				}
			}
		}
		checkNodeQueue.pop();
	}
}

void mTreeOfCorePoint::findOutlier(Tstream& tstream, Test& test)
{
	int slideNum = test.getWindowSize();
	slideVec.resize(slideNum);
	for (int i = 0; i < slideNum; ++i) {
		Slide slide;
		slide.slideId = slideIdCount++;
		slideVec[i] = slide;
	}
	createNeedDealCorePoint(tstream, test);
	for (auto& data : PointSet) {
		data.second->dataSlideId = data.second->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
		data.second->vecNeighborSlide.resize(slideNum);
		if (data.second->closeCore != nullptr) {
			if (data.second->closeCore->dequeE0.size() <= test.getK()) {
				findNeighborInCloseCoreE0E1E2(tstream, test, data.second->closeCore, data.second);
				data.second->closeCore->lastDealNum = tstream.getDataStreamTag();
			}
		}
		else if (data.second->CPInHalfRToR.size() != 0) {
			findNeighborInTemCoreE0E1E2E3(tstream, test, *(data.second->CPInHalfRToR.begin()), data.second);
		}
	}
	
}

void mTreeOfCorePoint::createNeedDealCorePoint(Tstream& tstream, Test& test)
{
	queue<Node*> checkNode;
	checkNode.push(root);
	Node* temNode = nullptr;
	int k = test.getK();
	while (!checkNode.empty()) {
		temNode = checkNode.front();
		if (temNode->corePointList.size() != 0) {
			for (auto cp : temNode->corePointList) {
				if (cp->dequeE0.size() > k) {
					addCorePointToSlideVec(tstream, test, cp);
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				checkNode.push(child);
			}
		}
		checkNode.pop();
	}
}

void mTreeOfCorePoint::addCorePointToSlideVec(Tstream& tstream, Test& test, CorePoint* cp)
{
	int k = test.getK();
	int size = cp->dequeE0.size();
	int tem = 0;
	int target = 0;
	if (size < 2 * k) {
		int num = 0;
		target = size - k;
		for (auto it = cp->dequeE0.rbegin(); it != cp->dequeE0.rend(); ++it) {
			num++;
			if (num == target) {
				tem = PointSet[*it]->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
				break;
			}
		}
	}
	else {
		int num = 0;
		target = k + 1;
		for (auto it = cp->dequeE0.begin(); it != cp->dequeE0.end(); ++it) {
			num++;
			if (num == target) {
				tem = PointSet[*it]->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
				break;
			}
		}
	}
	
	slideVec[tem].needDealCP.push_back(cp);
	cp->maintainBins = true;
}

void mTreeOfCorePoint::findNeighborInCloseCoreE0E1E2(Tstream& tstream, Test& test, CorePoint* closeCore, dataObj* data)
{
	int databegin = tstream.getDataStreamBegin();
	int k = test.getK();
	deque<int>::iterator p0 = closeCore->dequeE0.begin();
	deque<int>::iterator p1 = closeCore->dequeE1.begin();
	deque<int>::iterator p2 = closeCore->dequeE2.begin();
	vector<deque<int>*> ss;
	vector<deque<int>::iterator> sit;
	ss.reserve(3);
	sit.reserve(3);
	int temNum = 0;
	int tem;
	if (closeCore->dequeE0.size() != 0) {
		ss.push_back(&closeCore->dequeE0);
		sit.push_back(p0);
		temNum++;
	}
	if (closeCore->dequeE1.size() != 0) {
		ss.push_back(&closeCore->dequeE1);
		sit.push_back(p1);
		temNum++;
	}
	if (closeCore->dequeE2.size() != 0) {
		ss.push_back(&closeCore->dequeE2);
		sit.push_back(p2);
		temNum++;
	}
	int max = -1;
	int id = -1;
	double dis;
	double r = test.getR();
	while (true) {
		max = -1;
		id = -1;
		for (int i = 0; i < temNum; ++i) {
			if (sit[i] != (*ss[i]).end()) {
				if (*sit[i] == data->id) {
					sit[i]++;
				}
				if (sit[i] != (*ss[i]).end() && *sit[i] >= databegin) {
					if (max < *sit[i]) {
						max = *sit[i];
						id = i;
					}
				}
			}
		}
		if (max == -1) {
			break;
		}
		dis = calculateDistanceById(tstream, test, data->id, max);
		if (dis <= r) {
			tem = PointSet[max]->slideID - PointSet[databegin]->slideID;
			data->AllNeighborNum++;
			if (tem < data->dataSlideId) {
				data->vecNeighborSlide[tem]++;
			}
			else {
				data->vecNeighborNum++;
			}
			if (data->AllNeighborNum == k) {
				if (data->vecNeighborNum != k) {
					data->dataState = true;
					addDataObjToNeedDealDataObj(tstream, test, data);
				}
				return;
			}
		}
		sit[id]++;
	}
	outlierNum++;
	outlier.insert(data->id);
	if (data->slideID > slideIdCount - slideSize) {
		slideVec[0].needDealDataObj.push_back(data);
	}
}

void mTreeOfCorePoint::findNeighborInTemCoreE0E1E2E3(Tstream& tstream, Test& test, CorePoint* temCore, dataObj* data)
{
	int k = test.getK();
	int databegin = tstream.getDataStreamBegin();
	deque<int>::iterator p0 = temCore->dequeE0.begin();
	deque<int>::iterator p1 = temCore->dequeE1.begin();
	deque<int>::iterator p2 = temCore->dequeE2.begin();
	deque<int>::iterator p3 = temCore->dequeE3.begin();
	vector<deque<int>*> ss;
	vector<deque<int>::iterator> sit;
	ss.reserve(4);
	sit.reserve(4);
	int temNum = 0;
	if (temCore->dequeE0.size() != 0) {
		ss.push_back(&temCore->dequeE0);
		sit.push_back(p0);
		temNum++;
	}
	if (temCore->dequeE1.size() != 0) {
		ss.push_back(&temCore->dequeE1);
		sit.push_back(p1);
		temNum++;
	}
	if (temCore->dequeE2.size() != 0) {
		ss.push_back(&temCore->dequeE2);
		sit.push_back(p2);
		temNum++;
	}
	if (temCore->dequeE3.size() != 0) {
		ss.push_back(&temCore->dequeE3);
		sit.push_back(p3);
		temNum++;
	}
	int max = -1;
	int id = -1;
	double dis;
	double r = test.getR();
	while (true) {
		max = -1;
		id = -1;
		for (int i = 0; i < temNum; ++i) {
			if (sit[i] != (*ss[i]).end()) {
				if (*sit[i] == data->id) {
					sit[i]++;
				}
				if (sit[i] != (*ss[i]).end() && *sit[i] >= databegin) {
					if (max < *sit[i]) {
						max = *sit[i];
						id = i;
					}
				}
			}
		}
		if (max == -1) {
			break;
		}
		dis = calculateDistanceById(tstream, test, data->id, max);
		if (dis <= r) {
			int tem = PointSet[max]->slideID - PointSet[databegin]->slideID;
			data->AllNeighborNum++;
			if (tem < data->dataSlideId) {
				data->vecNeighborSlide[tem]++;
			}
			else {
				data->vecNeighborNum++;
			}
			if (data->AllNeighborNum == k) {
				if (data->vecNeighborNum != k) {
					data->dataState = true;
					addDataObjToNeedDealDataObj(tstream, test, data);
				}
				return;
			}
		}
		sit[id]++;
		
	}
	outlierNum++;
	outlier.insert(data->id);
	if (data->slideID > slideIdCount - slideSize) {
		slideVec[0].needDealDataObj.push_back(data);
	}
	return;
}

void mTreeOfCorePoint::addDataObjToNeedDealDataObj(Tstream& tstream, Test& test, dataObj* data)
{
	for (int i = 0; i < data->dataSlideId; ++i) {
		if (data->vecNeighborSlide[i] != 0) {
			slideVec[i].needDealDataObj.emplace_back(data);
			break;
		}
	}
}

void mTreeOfCorePoint::Update(Tstream& tstream, Test& test)
{
	int dimension = test.getDimension();
	int newEntryId = tstream.getDataStreamTag();
	clock_t startTime1, endTime1;
	startTime1 = clock();
	countSlideNum = tstream.getTotalSlideNum() - test.getWindowSize() - 1;
	int countSize = slideSize;
	list<dataObj*> newDataObjList;
	bool flag = false;
	for (int iii = 0; iii < countSlideNum; ++iii) {
		flag = false;
		countTemp = tstream.getS_change(iii);
		if (iii % countSize == 0 && iii != 0)
		{
			endTime1 = clock();
			double ttttttttt = (double)(endTime1 - startTime1) / CLOCKS_PER_SEC;
			cout << "Current cursor" << tstream.getDataStreamBegin() << "     Time = " << ttttttttt << "s" << endl;
			startTime1 = endTime1;
			dealSlideVec(tstream, test);
			cleanUpPointSet(tstream, test);
		}
		if (iii % 2 == 0 && iii != 0) {
			updateAll(tstream, test);
			flag = true;
		}
		if (iii % 4 == 0 && iii != 0) {
			reCreateMTree(tstream, test);
		}
		tstream.addDataStreamBegin(tstream.getS_change(iii));
		tstream.addDataStreamTag(tstream.getS_change(slideIdCount));
		if (tstream.getDataStreamTag() >= tstream.getvecDataStreamNum(dimension)) {
			break;
		}
		Slide oldSlide = slideVec[0];
		int slideNum = test.getWindowSize();
		for (int i = 0; i < (slideNum - 1); ++i) {
			slideVec[i] = slideVec[i + 1];
		}
		Slide newSlide;
		newSlide.slideId = slideIdCount++;
		slideVec[slideNum - 1] = newSlide;
		outlierNum = 0;
		outlier.clear();
		for (int i = newEntryId; i < tstream.getDataStreamTag(); ++i)
		{
			dataObj* newData = new dataObj;
			newData->id = i;
			newData->slideID = slideIdCount - 1;
			PointSet[i] = newData;
			UpdateaddDataObjToMTree(tstream, test, newData, root);
			newDataObjList.push_back(newData);
			
		}
		dealNewDataObj(tstream, test, newDataObjList);
		newDataObjList.clear();
		dealOldSlide(tstream, test, oldSlide);
		newEntryId = tstream.getDataStreamTag();
		int windowObjNum = calWindowMaintainObjNum(tstream, test);
		int lowerBound = 0.005 * windowObjNum;
		int upperBound = 0.02 * windowObjNum;
		if (outlier.size() < lowerBound || outlier.size() > upperBound) {
			if (!flag) {
				updateAll(tstream, test);
			}
			checkChangeR(tstream, test);
		}
		averageMemory.push_back(getProcessMemoryMB());
	}
	peakMemory = getPeakProcessMemoryMB();
}

void mTreeOfCorePoint::dealNewDataObj(Tstream& tstream, Test& test, list<dataObj*>& newDataObjList)
{

	int slideNum = test.getWindowSize();
	for (auto data : newDataObjList) {
		data->dataSlideId = data->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
		data->vecNeighborSlide.resize(slideNum);
		if (data->closeCore != nullptr) {
			if (!data->closeCore->maintainBins) {
				cutExpireE0Data(tstream, test, data->closeCore);
				if (data->closeCore->dequeE0.size() <= test.getK()) {
					updateFindNeighborInCloseCoreE0E1E2(tstream, test, data->closeCore, data);
					data->closeCore->lastDealNum = tstream.getDataStreamTag();
				}
				else {
					addCorePointToSlideVec(tstream, test, data->closeCore);
				}
			}
		}
		else if (data->CPInHalfRToR.size() != 0) {
			updateFindNeighborInTemCoreE0E1E2E3(tstream, test, *(data->CPInHalfRToR.begin()), data);
		}
	}
}

void mTreeOfCorePoint::dealOldSlide(Tstream& tstream, Test& test, Slide& oldSlide) {
	int temNewNeighborNum = 0;
	int k = test.getK();
	int slideNum = test.getWindowSize();
	for (auto cp : oldSlide.needDealCP) {
		if (cp->corePointCoordinate.size() != test.getDimension()) {
			continue;
		}
		cutExpireE0Data(tstream, test, cp);
		if (cp->dequeE0.size() > k) {
			addCorePointToSlideVec(tstream, test, cp);
		}
		else {
			cp->maintainBins = false;
			for (auto id : cp->dequeE0) {
				if (id >= cp->lastDealNum) {
					dataObj* newData = new dataObj;
					newData->id = id;
					newData->slideID = PointSet[id]->slideID;
					newData->dataSlideId = newData->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
					newData->vecNeighborSlide.resize(slideNum);
					newData->closeCore = cp;
					findNeighborInCloseCoreE0E1E2(tstream, test, newData->closeCore, newData);
				}
				else {
					break;
				}
			}
			cp->lastDealNum = tstream.getDataStreamTag();
		}
	}
	for (auto data : oldSlide.needDealDataObj) {
		if (data == nullptr) {
			continue;
		}
		if (data->id < tstream.getDataStreamBegin()) {
			continue;
		}
		temNewNeighborNum = tstream.getUpdateNeighborNumById(data->id);
		if (data->dataState) {
			if (data->vecNeighborNum + temNewNeighborNum < k) {
				if (data->closeCore != nullptr) {
					if (!data->closeCore->maintainBins) {
						if (calExpireSlideNum(tstream, test, data) <= temNewNeighborNum) {
							updateDataObjVecSlideNeighbor(tstream, test, data, temNewNeighborNum);
						}
						else {
							data->dataState = false;
							data->dataSlideId = data->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
							data->AllNeighborNum = 0;
							data->vecNeighborNum = 0;
							data->vecNeighborSlide.clear();
							data->vecNeighborSlide.resize(slideNum);
							findNeighborInCloseCoreE0E1E2(tstream, test, data->closeCore, data);
						}
					}
					else {
						if (data->id >= tstream.getDataStreamBegin()) {
							slideVec[0].needDealDataObj.push_back(data);
						}
					}
				}
				else {
					if (calExpireSlideNum(tstream, test, data) <= temNewNeighborNum) {
						updateDataObjVecSlideNeighbor(tstream, test, data, temNewNeighborNum);
					}
					else {
						data->dataState = false;
						data->dataSlideId = data->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
						data->AllNeighborNum = 0;
						data->vecNeighborNum = 0;
						data->vecNeighborSlide.clear();
						data->vecNeighborSlide.resize(slideNum);
						findNeighborInTemCoreE0E1E2E3(tstream, test, *(data->CPInHalfRToR.begin()), data);
					}
				}
			}
		}
		else {
			data->dataSlideId = data->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
			data->AllNeighborNum = 0;
			data->vecNeighborNum = 0;
			data->vecNeighborSlide.clear();
			data->vecNeighborSlide.resize(slideNum);
			if (data->closeCore != nullptr) {
				findNeighborInCloseCoreE0E1E2(tstream, test, data->closeCore, data);
			}
			else {
				findNeighborInTemCoreE0E1E2E3(tstream, test, *(data->CPInHalfRToR.begin()), data);
			}
		}
	}
}

void mTreeOfCorePoint::cutExpireE0Data(Tstream& tstream, Test& test, CorePoint* cp)
{
	int windowbegin = tstream.getDataStreamBegin();
	auto it0 = lower_bound(cp->dequeE0.begin(), cp->dequeE0.end(), windowbegin, std::greater<int>());
	cp->dequeE0.erase(it0, cp->dequeE0.end());
}

int mTreeOfCorePoint::calExpireSlideNum(Tstream& tstream, Test& test, dataObj* data)
{
	for (int i = 0; i < data->dataSlideId; ++i) {
		if (data->vecNeighborSlide[i] != 0) {
			return data->vecNeighborSlide[i];
		}
	}
	return data->vecNeighborSlide[data->dataSlideId];
}

void mTreeOfCorePoint::updateDataObjVecSlideNeighbor(Tstream& tstream, Test& test, dataObj* data, int temNewNeighborNum)
{
	int temNum = temNewNeighborNum;
	data->vecNeighborNum += temNum;
	for (int i = 0; i < data->dataSlideId; ++i) {
		if (data->vecNeighborSlide[i] <= temNum) {
			temNum -= data->vecNeighborSlide[i];
			data->vecNeighborSlide[i] = 0;
		}
		else {
			data->vecNeighborSlide[i] -= temNum;
			temNum = 0;
			break;
		}
	}
	tstream.setUpdateNeighborNumById(data->id, 0);
	int step = data->dataSlideId - (data->slideID - PointSet[tstream.getDataStreamBegin()]->slideID);
	for (int i = step; i < data->dataSlideId; ++i) {
		data->vecNeighborSlide[i - step] = data->vecNeighborSlide[i];
	}
	data->dataSlideId - data->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
	int slideNum = test.getWindowSize();
	for (int i = data->dataSlideId; i < slideNum; ++i) {
		data->vecNeighborSlide[i] = 0;
	}
	addDataObjToNeedDealDataObj(tstream, test, data);
}

void mTreeOfCorePoint::updateAll(Tstream& tstream, Test& test)
{
	Node* temNode = nullptr;
	queue<Node*> Nodequeue;
	Nodequeue.push(root);
	bool flag = false;
	if (countNum >=2) {
		flag = true;
		countNum = 0;
	}
	int windowbegin = tstream.getDataStreamBegin() + countTemp;
	while (!Nodequeue.empty()) {
		temNode = Nodequeue.front();
		if (temNode->corePointList.size() != 0) {
			for (auto TemCp = temNode->corePointList.begin(); TemCp != temNode->corePointList.end(); ++TemCp) {
				auto it0 = lower_bound((*TemCp)->dequeE0.begin(), (*TemCp)->dequeE0.end(), windowbegin, std::greater<int>());
				(*TemCp)->dequeE0.erase(it0, (*TemCp)->dequeE0.end());
				auto it1 = lower_bound((*TemCp)->dequeE1.begin(), (*TemCp)->dequeE1.end(), windowbegin, std::greater<int>());
				(*TemCp)->dequeE1.erase(it1, (*TemCp)->dequeE1.end());
				auto it2 = lower_bound((*TemCp)->dequeE2.begin(), (*TemCp)->dequeE2.end(), windowbegin, std::greater<int>());
				(*TemCp)->dequeE2.erase(it2, (*TemCp)->dequeE2.end());
				auto it3 = lower_bound((*TemCp)->dequeE3.begin(), (*TemCp)->dequeE3.end(), windowbegin, std::greater<int>());
				(*TemCp)->dequeE3.erase(it3, (*TemCp)->dequeE3.end());
				if (flag) {
					if ((*TemCp)->dequeE0.size() == 0 && (*TemCp)->dequeE1.size() == 0) {
						CorePoint* deleteCore = *TemCp;
						temNode->corePointList.erase(TemCp);
						delete deleteCore;
						deleteCore = nullptr;
						continue;
					}
				}
			}
			if (temNode->corePointList.size() == 0) {
				for (auto x = temNode->parentNode->childNodeList.begin(); x != temNode->parentNode->childNodeList.end(); ++x) {
					if ((*x)->id == temNode->id) {
						auto y = temNode->parentNode->childNodeList.erase(x);
						break;
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				Nodequeue.push(child);
			}
		}
		Nodequeue.pop();
	}
}

void mTreeOfCorePoint::addNewCoreToMTree(Tstream& tstream, Test& test, CorePoint* newCore)
{
	Node* temNode = root;
	double minDis = DBL_MAX;
	double disTochildrenNode;
	Node* nodeTemInRadius = nullptr;
	Node* targetNode = nullptr;
	double r = test.getR();
	bool flag = false;
	while (true) {
		minDis = DBL_MAX;
		nodeTemInRadius = nullptr;
		flag = false;
		if (temNode->childNodeList.size() == 0) {
			temNode->corePointList.push_back(newCore);
			targetNode = temNode;
			break;
		}
		else {
			for (auto child : temNode->childNodeList) {
				disTochildrenNode = calculateDistanceBetweenTwoData(tstream, test, child->coordinate, newCore->corePointCoordinate);
				if (disTochildrenNode <= child->radius && disTochildrenNode <= minDis) {
					nodeTemInRadius = child;
					minDis = disTochildrenNode;
					flag = true;
				}
			}
			if (flag) {
				temNode = nodeTemInRadius;
			}
			else {
				targetNode = createNewMiddleNode(tstream, test, temNode, newCore);
				break;
			}
		}
	}
	updateRadius(tstream, test, targetNode);
	checkSplit(tstream, test, targetNode, newCore);
	updateNewCoreE(tstream, test, targetNode, newCore);

}

mTreeOfCorePoint::Node* mTreeOfCorePoint::createNewMiddleNode(Tstream& tstream, Test& test, Node* node, CorePoint* newCore)
{
	Node* newMiddleNode = new Node;
	newMiddleNode->coordinate = newCore->corePointCoordinate;
	newMiddleNode->corePointList.push_back(newCore);
	newMiddleNode->disToParent = calculateDistanceBetweenTwoData(tstream, test, newMiddleNode->coordinate, node->coordinate);
	newMiddleNode->id = nodeIdCount++;
	newMiddleNode->parentNode = node;
	newMiddleNode->radius = min(3 * test.getR(), node->radius * 0.6);
	node->childNodeList.push_back(newMiddleNode);
	node->radius = max(node->radius, newMiddleNode->disToParent + newMiddleNode->radius);
	return newMiddleNode;
}

void removeDuplicates(deque<int>& dq) {
	unordered_set<int> seen;
	dq.erase(remove_if(dq.begin(), dq.end(), [&](int num) {
		return !seen.insert(num).second;
		}), dq.end());
}

void mTreeOfCorePoint::updateNewCoreE(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore)
{
	list<CorePoint*> temCoreList;
	findEInCurLeaf(tstream, test, targetNode, newCore, temCoreList);
	findEInOtherLeaf(tstream, test, targetNode, newCore, temCoreList);
	for (auto cp : temCoreList) {
		newDealDataInCPE0E1(tstream, test, cp->dequeE0, newCore);
		newDealDataInCPE0E1(tstream, test, cp->dequeE1, newCore);
	}
	removeDuplicates(newCore->dequeE0);
	sort(newCore->dequeE0.begin(), newCore->dequeE0.end(), greater<int>());
	removeDuplicates(newCore->dequeE1);
	sort(newCore->dequeE1.begin(), newCore->dequeE1.end(), greater<int>());
	removeDuplicates(newCore->dequeE2);
	sort(newCore->dequeE2.begin(), newCore->dequeE2.end(), greater<int>());
	removeDuplicates(newCore->dequeE3);
	sort(newCore->dequeE3.begin(), newCore->dequeE3.end(), greater<int>());

}

void mTreeOfCorePoint::findEInCurLeaf(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore, list<CorePoint*>& temCoreList)
{
	double dis;
	double r = test.getR();
	for (auto cp : targetNode->corePointList) {
		if (cp->corePointCoordinate != newCore->corePointCoordinate) {
			dis = calculateDistanceBetweenTwoData(tstream, test, cp->corePointCoordinate, newCore->corePointCoordinate);
			if (dis < 3 * r) {
				temCoreList.push_back(cp);
			}
		}
	}
}

void mTreeOfCorePoint::findEInOtherLeaf(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore, list<CorePoint*>& temCoreList)
{
	if (targetNode->parentNode == nullptr) {
		return;
	}
	Node* temNode = targetNode;
	queue<Node*> parentNodeQueue;
	queue<Node*> findNeighborQueue;
	parentNodeQueue.push(temNode);
	Node* curParentNode = nullptr;
	Node* curFindNode = nullptr;
	double DisP;
	double R = test.getR();
	double discp;
	while (temNode->parentNode != nullptr) {
		temNode = temNode->parentNode;
		parentNodeQueue.push(temNode);
	}
	while (!parentNodeQueue.empty()) {
		if (parentNodeQueue.front()->parentNode != nullptr) {
			curParentNode = parentNodeQueue.front()->parentNode;
			for (auto child : curParentNode->childNodeList) {
				DisP = calculateDistanceBetweenTwoData(tstream, test, newCore->corePointCoordinate, child->coordinate) - child->radius;
				if (DisP <= 3 * R && child->id != parentNodeQueue.front()->id) {
					findNeighborQueue.push(child);
				}
			}
		}
		parentNodeQueue.pop();
		while (!findNeighborQueue.empty()) {
			curFindNode = findNeighborQueue.front();
			if (curFindNode->corePointList.size() != 0) {
				for (auto cp : curFindNode->corePointList) {
					discp = calculateDistanceBetweenTwoData(tstream, test, cp->corePointCoordinate, newCore->corePointCoordinate);
					if (discp <= 3 * R) {
						temCoreList.push_back(cp);
					}
				}
			}
			else {
				addNodeToQueue(tstream, test, curFindNode, newCore, findNeighborQueue);
			}
			findNeighborQueue.pop();
		}
	}
}

void mTreeOfCorePoint::addNodeToQueue(Tstream& tstream, Test& test, Node* node, CorePoint* newCore, queue<Node*>& findNeighborQueue)
{
	double dis;
	double r = test.getR();
	for (auto child : node->childNodeList) {
		dis = calculateDistanceBetweenTwoData(tstream, test, child->coordinate, newCore->corePointCoordinate) - child->radius;
		if (dis <= 3 * r) {
			findNeighborQueue.push(child);
		}
	}
}

void mTreeOfCorePoint::newDealDataInCPE0E1(Tstream& tstream, Test& test, deque<int>& E, CorePoint* newCore)
{
	double dis;
	double r = test.getR();
	for (auto id : E) {
		dis = calculateDistanceBycoordinate(tstream, test, id, newCore->corePointCoordinate);
		if (dis <= r / 2) {
			newCore->dequeE0.push_back(id);
		}
		else if (dis <= r) {
			newCore->dequeE1.push_back(id);
		}
		else if (dis <= 3 * r / 2) {
			newCore->dequeE2.push_back(id);
		}
		else if (dis <= 2 * r) {
			newCore->dequeE3.push_back(id);
		}
	}
}

void mTreeOfCorePoint::checkSplit(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore)
{
	Node* temNode = nullptr;
	list<Node*> temChildList;
	if (targetNode->parentNode != nullptr) {
		temNode = targetNode->parentNode;
	}
	else {
		return;
	}
	if (temNode->childNodeList.size() > childNodeSplitNum) {
		temChildList = temNode->childNodeList;
		temNode->childNodeList.clear();
		splitTemChildList(tstream, test, targetNode, temChildList, temNode);
	}
}

void mTreeOfCorePoint::splitTemChildList(Tstream& tstream, Test& test, Node* targetNode, list<Node*>& temChildList, Node* splitNode)
{
	vector<double> subTreeCoordinate;
	int tarId = targetNode->id;
	while (temChildList.size() != 0) {
		if (splitNode->childNodeList.size() >= childNodeSplitNum * 0.75) {
			break;
		}
		UpdateChooseSubInSurplusEntry(tstream, test, subTreeCoordinate, splitNode, temChildList);
		for (int i = 0; i < subTreeCoordinate.size() / test.getDimension(); ++i) {
			UpdateCreateNode(tstream, test, subTreeCoordinate, splitNode, i);
		}
		subTreeCoordinate.clear();
		UpdateAddChildToMidNode(tstream, test, splitNode, temChildList, targetNode, tarId);
	}
	Node* chooseNode = nullptr;
	double dis;
	double minDis;
	if (temChildList.size() != 0) {
		for (auto it = temChildList.begin(); it != temChildList.end();) {
			chooseNode = nullptr;
			minDis = DBL_MAX;
			for (auto child : splitNode->childNodeList) {
				dis = calculateDistanceBetweenTwoData(tstream, test, (*it)->coordinate, child->coordinate);
				if (dis < minDis) {
					minDis = dis;
					chooseNode = child;
				}
			}
			chooseNode->childNodeList.push_back(*it);
			(*it)->parentNode = chooseNode;
			(*it)->disToParent = calculateDistanceBetweenTwoData(tstream, test, (*it)->coordinate, chooseNode->coordinate);
			chooseNode->radius = max(chooseNode->radius, minDis);
			if ((*it)->id == tarId) {
				targetNode = chooseNode;
			}
			it = temChildList.erase(it);
		}
	}
	Node* tem = nullptr;
	for (auto child = splitNode->childNodeList.begin(); child != splitNode->childNodeList.end();) {
		if ((*child)->childNodeList.size() == 0 && (*child)->corePointList.size() == 0) {
			tem = *child;
			splitNode->childNodeList.erase(child++);
			delete tem;
			tem = nullptr;
			continue;
		}
		child++;
	}
}

void mTreeOfCorePoint::UpdateChooseSubInSurplusEntry(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* splitNode, list<Node*>& temChildList)
{
	int dimension = test.getDimension();
	double maxNum;
	double minNum;
	double tem;
	vector<double> v1;
	vector<double> v2;
	map<double, pair<vector<double>, vector<double>>> Map;
	for (int i = 0; i < dimension; ++i) {
		maxNum = -10;
		minNum = DBL_MAX;
		for (auto child : temChildList) {
			tem = child->coordinate[i];
			if (tem > maxNum) {
				maxNum = tem;
				v1 = child->coordinate;
			}
			if (tem < minNum) {
				minNum = tem;
				v2 = child->coordinate;
			}
		}
		Map.emplace(maxNum - minNum, make_pair(v1, v2));
	}
	for (int i = 0; i < dimension; ++i) {
		subTreecoordinate.push_back(((*Map.rbegin()).second.first[i] * 3 + (*Map.rbegin()).second.second[i]) / 4);
	}
	for (int i = 0; i < dimension; ++i) {
		subTreecoordinate.push_back(((*Map.rbegin()).second.first[i] + (*Map.rbegin()).second.second[i] * 3) / 4);
	}
}

void mTreeOfCorePoint::UpdateCreateNode(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node, int id)
{
	int dimension = test.getDimension();
	Node* childNode = new Node();
	childNode->parentNode = node;
	childNode->id = nodeIdCount++;
	for (int i = 0; i < dimension; ++i) {
		childNode->coordinate.push_back(subTreecoordinate[id * dimension + i]);
	}
	childNode->disToParent = calculateDistanceBetweenTwoData(tstream, test, childNode->coordinate, node->coordinate);
	childNode->radius = node->radius * 0.5;
	node->childNodeList.push_back(childNode);
}

void mTreeOfCorePoint::UpdateAddChildToMidNode(Tstream& tstream, Test& test, Node* node, list<Node*>& temChildList, Node* targetNode, int targetNodeId)
{
	Node* chooseNode = nullptr;
	double dis;
	double minDis;
	double r = test.getR();
	for (auto it = temChildList.begin(); it != temChildList.end();) {
		minDis = DBL_MAX;
		chooseNode = nullptr;
		for (auto child : node->childNodeList) {
			dis = calculateDistanceBetweenTwoData(tstream, test, (*it)->coordinate, child->coordinate);
			if (dis < minDis && dis <= (child->parentNode->radius * maxRThreshold)) {
				minDis = dis;
				chooseNode = child;
			}
		}
		if (chooseNode != nullptr) {
			chooseNode->childNodeList.push_back(*it);
			chooseNode->radius = max(chooseNode->radius, minDis);
			(*it)->parentNode = chooseNode;
			(*it)->disToParent = calculateDistanceBetweenTwoData(tstream, test, (*it)->coordinate, chooseNode->coordinate);
			if ((*it)->id == targetNodeId) {
				targetNode = chooseNode;
			}
			it = temChildList.erase(it);
			continue;
		}
		it++;
	}
}

void mTreeOfCorePoint::UpdateaddDataObjToMTree(Tstream& tstream, Test& test, dataObj* data, Node* node)
{
	queue<Node*> checkNodeQueue;
	double minDis = DBL_MAX;
	double dis;
	double r = test.getR();
	checkNodeQueue.push(node);
	Node* temNode = nullptr;
	bool flag = false;
	while (!checkNodeQueue.empty()) {
		temNode = checkNodeQueue.front();
		if (temNode->childNodeList.size() == 0) {
			for (auto cp : temNode->corePointList) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, cp->corePointCoordinate);
				if (dis <= r / 2) {
					data->closeCore = cp;
					cp->dequeE0.push_front(data->id);
					flag = true;
				}
				if (dis > r / 2 && dis <= r) {
					data->CPInHalfRToR.push_back(cp);
					cp->dequeE1.push_front(data->id);
					flag = true;
				}
				if (dis > r && dis <= 3 * r / 2) {
					cp->dequeE2.push_front(data->id);
				}
				if (dis > 3 * r / 2 && dis <= 2 * r) {
					cp->dequeE3.push_front(data->id);
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, data->id, child->coordinate) - child->radius;
				if (dis <= (2 * test.getR())) {
					checkNodeQueue.push(child);
				}
			}
		}
		checkNodeQueue.pop();
	}
	if (!flag) {
		CorePoint* newCore = new CorePoint;
		newCore->corePointCoordinate = tstream.getData(data->id, test.getDimension());
		newCore->dequeE0.push_front(data->id);
		data->closeCore = newCore;
		addNewCoreToMTree(tstream, test, newCore);
		return;

	}
}

void mTreeOfCorePoint::updateFindNeighborInCloseCoreE0E1E2(Tstream& tstream, Test& test, CorePoint* temCore, dataObj* data)
{
	int databegin = tstream.getDataStreamBegin();
	int k = test.getK();
	deque<int>::iterator p0 = temCore->dequeE0.begin();
	deque<int>::iterator p1 = temCore->dequeE1.begin();
	deque<int>::iterator p2 = temCore->dequeE2.begin();
	vector<deque<int>*> ss;
	vector<deque<int>::iterator> sit;
	ss.reserve(3);
	sit.reserve(3);
	int temNum = 0;
	int tem;
	if (temCore->dequeE0.size() != 0) {
		ss.push_back(&temCore->dequeE0);
		sit.push_back(p0);
		temNum++;
	}
	if (temCore->dequeE1.size() != 0) {
		ss.push_back(&temCore->dequeE1);
		sit.push_back(p1);
		temNum++;
	}
	if (temCore->dequeE2.size() != 0) {
		ss.push_back(&temCore->dequeE2);
		sit.push_back(p2);
		temNum++;
	}
	int max = -1;
	int id = -1;
	double dis;
	double r = test.getR();
	while (true) {
		max = -1;
		id = -1;
		for (int i = 0; i < temNum; ++i) {
			if (sit[i] != (*ss[i]).end()) {
				if (*sit[i] == data->id) {
					sit[i]++;
				}
				if (sit[i] != (*ss[i]).end() && *sit[i] >= databegin) {
					if (max < *sit[i]) {
						max = *sit[i];
						id = i;
					}
				}
			}
		}
		if (max == -1) {
			break;
		}
		dis = calculateDistanceById(tstream, test, data->id, max);
		if (dis <=r) {
			tem = PointSet[max]->slideID - PointSet[databegin]->slideID;
			data->AllNeighborNum++;
			tstream.addUpdateNeighborNumById(test, max);
			if (tem < data->dataSlideId) {
				data->vecNeighborSlide[tem]++;
			}
			else {
				data->vecNeighborNum++;
			}
			if (data->AllNeighborNum == k) {
				if (data->vecNeighborNum != k) {
					data->dataState = true;
					addDataObjToNeedDealDataObj(tstream, test, data);
				}
				return;
			}
		}
		sit[id]++;
	}
	outlierNum++;
	outlier.insert(data->id);
	if (data->slideID > slideIdCount - slideSize) {
		slideVec[0].needDealDataObj.push_back(data);
	}
}

void mTreeOfCorePoint::updateFindNeighborInTemCoreE0E1E2E3(Tstream& tstream, Test& test, CorePoint* temCore, dataObj* data)
{
	int k = test.getK();
	int databegin = tstream.getDataStreamBegin();
	deque<int>::iterator p0 = temCore->dequeE0.begin();
	deque<int>::iterator p1 = temCore->dequeE1.begin();
	deque<int>::iterator p2 = temCore->dequeE2.begin();
	deque<int>::iterator p3 = temCore->dequeE3.begin();
	vector<deque<int>*> ss;
	vector<deque<int>::iterator> sit;
	ss.reserve(4);
	sit.reserve(4);
	int temNum = 0;
	if (temCore->dequeE0.size() != 0) {
		ss.push_back(&temCore->dequeE0);
		sit.push_back(p0);
		temNum++;
	}
	if (temCore->dequeE1.size() != 0) {
		ss.push_back(&temCore->dequeE1);
		sit.push_back(p1);
		temNum++;
	}
	if (temCore->dequeE2.size() != 0) {
		ss.push_back(&temCore->dequeE2);
		sit.push_back(p2);
		temNum++;
	}
	if (temCore->dequeE3.size() != 0) {
		ss.push_back(&temCore->dequeE3);
		sit.push_back(p3);
		temNum++;
	}
	int max = -1;
	int id = -1;
	double dis;
	double r = test.getR();
	while (true) {
		max = -1;
		id = -1;
		for (int i = 0; i < temNum; ++i) {
			if (sit[i] != (*ss[i]).end()) {
				if (*sit[i] == data->id) {
					sit[i]++;
				}
				if (sit[i] != (*ss[i]).end() && *sit[i] >= databegin) {
					if (max < *sit[i]) {
						max = *sit[i];
						id = i;
					}
				}
			}
		}
		if (max == -1) {
			break;
		}
		dis = calculateDistanceById(tstream, test, data->id, max);
		if (dis <=r) {
			int tem = PointSet[max]->slideID - PointSet[databegin]->slideID;
			data->AllNeighborNum++;
			tstream.addUpdateNeighborNumById(test, max);
			if (tem < data->dataSlideId) {
				data->vecNeighborSlide[tem]++;
			}
			else {
				data->vecNeighborNum++;
			}
			if (data->AllNeighborNum == k) {
				if (data->vecNeighborNum != k) {
					data->dataState = true;
					addDataObjToNeedDealDataObj(tstream, test, data);
				}
				return;
			}
		}
		sit[id]++;
	}
	outlierNum++;
	outlier.insert(data->id);
	if (data->slideID > slideIdCount - slideSize) {
		slideVec[0].needDealDataObj.push_back(data);
	}
	return;
}

void mTreeOfCorePoint::updateRadius(Tstream& tstream, Test& test, Node* node)
{
	Node* temNode = node;
	double dis = 0;
	while (temNode->id!=root->id) {
		if (temNode->childNodeList.size() != 0) {
			dis = 0;
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBetweenTwoData(tstream, test, temNode->coordinate, child->coordinate) + child->radius;
				temNode->radius = max(temNode->radius, dis);
			}
			temNode = temNode->parentNode;
		}
		else {
			dis = 0;
			for (auto cp : temNode->corePointList) {
				dis = calculateDistanceBetweenTwoData(tstream, test, temNode->coordinate, cp->corePointCoordinate);
				temNode->radius = max(temNode->radius, dis);
			}
			temNode = temNode->parentNode;
		}
	}
}

mTreeOfCorePoint::Node* compressTree(mTreeOfCorePoint::Node* root) {
	if (root == nullptr) return nullptr;
	for (auto it = root->childNodeList.begin(); it != root->childNodeList.end();) {
		mTreeOfCorePoint::Node* child = *it;
		child = compressTree(child);
		if (child == nullptr) {
			it = root->childNodeList.erase(it);
		}
		else {
			++it;
		}
	}
	if (root->childNodeList.empty() && root->corePointList.empty()) {
		delete root;
		return nullptr;
	}

	while (root->childNodeList.size() == 1 && root->childNodeList.front()->childNodeList.size() == 1) {
		mTreeOfCorePoint::Node* onlyChild = root->childNodeList.front();
		mTreeOfCorePoint::Node* onlyGrandchild = onlyChild->childNodeList.front();
		root->corePointList.insert(root->corePointList.end(), onlyChild->corePointList.begin(), onlyChild->corePointList.end());
		delete onlyChild;
		root->childNodeList.front() = onlyGrandchild;
	}
	return root;
}

void mTreeOfCorePoint::checkMTreeStruct(Tstream& tstream, Test& test)
{
	compressTree(root);
}

void mTreeOfCorePoint::reCreateMTree(Tstream& tstream, Test& test)
{
	Node* newRoot = new Node;
	newRoot->coordinate = root->coordinate;
	newRoot->disToParent = 0;
	newRoot->id= nodeIdCount++;
	newRoot->parentNode = nullptr;
	newRoot->radius = root->radius;
	Node* temNode = nullptr;
	queue<Node*> Nodequeue;
	Nodequeue.push(root);
	int windowbegin = tstream.getDataStreamBegin() + countTemp;
	while (!Nodequeue.empty()) {
		temNode = Nodequeue.front();
		if (temNode->corePointList.size() != 0) {
			for (auto cp : temNode->corePointList) {
				if (cp->dequeE0.size() != 0 || cp->dequeE1.size() != 0) {
					newRoot->corePointList.push_back(cp);
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				Nodequeue.push(child);
			}
		}
		Nodequeue.pop();
	}
	root = newRoot;
	splitMTree(tstream, test);
}

int mTreeOfCorePoint::calWindowMaintainObjNum(Tstream& tstream, Test& test)
{
	int count = 0;
	for (int i = 0; i < slideSize; ++i) {
		count += tstream.getS_change(slideVec[i].slideId);
	}
	return count;
}

void mTreeOfCorePoint::checkChangeR(Tstream& tstream, Test& test)
{
	int dataNum = calWindowMaintainObjNum(tstream, test);
	int lowerBound = 0.005 * dataNum;
	int upperBound = 0.02 * dataNum;
	int count = 0.01 * dataNum + 1;
	int count2 = 0.02 * dataNum + 1;
	double oldR = test.getR();
	int outlierNum = outlier.size();
	while (true) {
		if (outlier.size() < lowerBound) {
			unordered_map<int, CorePoint*> candidateObj;
			findCanObj(tstream, test, count2, candidateObj);
			multimap<double, int, greater<double>> Map;
			for (auto outlierObj : candidateObj) {
				Map.emplace(newFindKNNForOutlier(tstream, test, outlierObj.first), outlierObj.first);
			}
			int num = 0;
			for (auto it : Map) {
				num++;
				if (num == count) {
					test.setR(it.first);
					break;
				}
			}
			Init(tstream, test, tstream.getDataStreamBegin(), tstream.getDataStreamTag());
			if (outlier.size() >= lowerBound && outlier.size() <= upperBound) {
				tstream.addChangeTimes();
				return;
			}
		}
		else if (outlier.size() > upperBound) {
			multimap<double, int, greater<double>> Map;
			for (auto outlierObj : outlier) {
				Map.emplace(newFindKNNForOutlier(tstream, test, outlierObj), outlierObj);
			}
			int num = 0;
			for (auto it : Map) {
				num++;
				if (num == count) {
					test.setR(it.first);
					break;
				}
			}
			tstream.addChangeTimes();
			Init(tstream, test, tstream.getDataStreamBegin(), tstream.getDataStreamTag());
			return;
		}
	}
}

void mTreeOfCorePoint::findCanObj(Tstream& tstream, Test& test, int count, unordered_map<int, CorePoint*>& candidateObj)
{
	queue<Node*> queNode;
	queNode.push(root);
	Node* temNode = nullptr;
	multimap<int, CorePoint*> corePointMap;
	while (!queNode.empty()) {
		temNode = queNode.front();
		if (temNode->childNodeList.size() != 0) {
			for (auto child : temNode->childNodeList) {
				queNode.push(child);
			}
		}
		else {
			for (auto core : temNode->corePointList) {
				corePointMap.emplace(core->dequeE0.size(), core);
			}
		}
		queNode.pop();
	}
	int num = 0;
	for (auto core : corePointMap) {
		num += core.first;
		for (auto id : core.second->dequeE0) {
			candidateObj.emplace(id, core.second);
		}
		if (num >= count) {
			break;
		}
	}
}

double mTreeOfCorePoint::findKNNForOutlier(Tstream& tstream, Test& test, int outlierId, CorePoint* core)
{
	double kR = DBL_MAX;
	multiset<double> neighborSet;
	double dis = 0;
	int k = test.getK();
	for (auto id : core->dequeE0) {
		if (id != outlierId) {
			dis = calculateDistanceById(tstream, test, id, outlierId);
			if (dis <= kR) {
				neighborSet.emplace(dis);
				if (neighborSet.size() > k) {
					neighborSet.erase(--neighborSet.end());
					kR = *(--neighborSet.end());
				}
			}
		}
	}
	for (auto id : core->dequeE1) {
		if (id != outlierId) {
			dis = calculateDistanceById(tstream, test, id, outlierId);
			if (dis <= kR) {
				neighborSet.emplace(dis);
				if (neighborSet.size() > k) {
					neighborSet.erase(--neighborSet.end());
					kR = *(--neighborSet.end());
				}
			}
		}
	}
	for (auto id : core->dequeE2) {
		if (id != outlierId) {
			dis = calculateDistanceById(tstream, test, id, outlierId);
			if (dis <= kR) {
				neighborSet.emplace(dis);
				if (neighborSet.size() > k) {
					neighborSet.erase(--neighborSet.end());
					kR = *(--neighborSet.end());
				}
			}
		}
	}
	return *(--neighborSet.end());
}

double mTreeOfCorePoint::findKNNForOutlier(Tstream& tstream, Test& test, int outlierId)
{
	CorePoint* temCore = nullptr;
	if (PointSet[outlierId]->closeCore != nullptr) {
		temCore = PointSet[outlierId]->closeCore;
		double kR = DBL_MAX;
		multiset<double> neighborSet;
		double dis = 0;
		int k = test.getK();
		for (auto id : temCore->dequeE0) {
			if (id != outlierId) {
				dis = calculateDistanceById(tstream, test, id, outlierId);
				if (dis <= kR) {
					neighborSet.emplace(dis);
					if (neighborSet.size() == k) {
						kR = *(--neighborSet.end());
					}
					if (neighborSet.size() > k) {
						neighborSet.erase(--neighborSet.end());
						kR = *(--neighborSet.end());
					}
				}
			}
		}
		for (auto id : temCore->dequeE1) {
			if (id != outlierId) {
				dis = calculateDistanceById(tstream, test, id, outlierId);
				if (dis <= kR) {
					neighborSet.emplace(dis);
					if (neighborSet.size() == k) {
						kR = *(--neighborSet.end());
					}
					if (neighborSet.size() > k) {
						neighborSet.erase(--neighborSet.end());
						kR = *(--neighborSet.end());
					}
				}
			}
		}
		for (auto id : temCore->dequeE2) {
			if (id != outlierId) {
				dis = calculateDistanceById(tstream, test, id, outlierId);
				if (dis <= kR) {
					neighborSet.emplace(dis);
					if (neighborSet.size() == k) {
						kR = *(--neighborSet.end());
					}
					if (neighborSet.size() > k) {
						neighborSet.erase(--neighborSet.end());
						kR = *(--neighborSet.end());
					}
				}
			}
		}
		for (auto id : temCore->dequeE3) {
			if (id != outlierId) {
				dis = calculateDistanceById(tstream, test, id, outlierId);
				if (dis <= kR) {
					neighborSet.emplace(dis);
					if (neighborSet.size() == k) {
						kR = *(--neighborSet.end());
					}
					if (neighborSet.size() > k) {
						neighborSet.erase(--neighborSet.end());
						kR = *(--neighborSet.end());
					}
				}
			}
		}
		return *(--neighborSet.end());
	}
	else {
		double kR = DBL_MAX;
		double dis = 0;
		int k = test.getK();
		multiset<double> neighborSet;
		for (auto halfRCore : PointSet[outlierId]->CPInHalfRToR) {
			temCore = halfRCore;
			for (auto id : temCore->dequeE0) {
				if (id != outlierId) {
					dis = calculateDistanceById(tstream, test, id, outlierId);
					if (dis <= kR) {
						neighborSet.emplace(dis);
						if (neighborSet.size() == k) {
							kR = *(--neighborSet.end());
						}
						if (neighborSet.size() > k) {
							neighborSet.erase(--neighborSet.end());
							kR = *(--neighborSet.end());
						}
					}
				}
			}
			for (auto id : temCore->dequeE1) {
				if (id != outlierId) {
					dis = calculateDistanceById(tstream, test, id, outlierId);
					if (dis <= kR) {
						neighborSet.emplace(dis);
						if (neighborSet.size() == k) {
							kR = *(--neighborSet.end());
						}
						if (neighborSet.size() > k) {
							neighborSet.erase(--neighborSet.end());
							kR = *(--neighborSet.end());
						}
					}
				}
			}
		}
		return *(--neighborSet.end());
	}
}

void mTreeOfCorePoint::reFindOutlier(Tstream& tstream, Test& test)
{
	outlierNum = 0;
	outlier.clear();
	CorePoint* temCore = nullptr;
	for (int i = tstream.getDataStreamBegin(); i < tstream.getDataStreamTag(); ++i) {
		if (PointSet[i]->closeCore != nullptr) {
			temCore = PointSet[i]->closeCore;
			changeRFindNeighborInE0_E2(tstream, test, i, temCore);
		}
		else {
			temCore = PointSet[i]->CPInHalfRToR.front();
			changeRFindNeighborInE0_E3(tstream, test, i, temCore);
		}
	}
}

void mTreeOfCorePoint::changeRFindNeighborInE0_E2(Tstream& tstream, Test& test, int targetId, CorePoint* core)
{
	bool flag = false;
	double dis = 0;
	double r = test.getR();
	int k = test.getK();
	int neighborNum = 0;
	for (auto id : core->dequeE0) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return;
				}
			}
		}
	}
	for (auto id : core->dequeE1) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return ;
				}
			}
		}
	}
	for (auto id : core->dequeE2) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return ;
				}
			}
		}
	}
	outlier.emplace(targetId);
	outlierNum++;
	return ;
}

double mTreeOfCorePoint::newFindKNNForOutlier(Tstream& tstream, Test& test, int outlierId)
{
	double kR = DBL_MAX;
	multiset<double> neighborSet;
	vector<bool> binsVec(tstream.getvecDataStreamNum(test.getDimension()), false);
	double dis = 0;
	int k = test.getK();
	queue<Node*> checkNodeQueue;
	checkNodeQueue.push(root);
	Node* temNode = nullptr;
	while (!checkNodeQueue.empty()) {
		temNode = checkNodeQueue.front();
		if (temNode->childNodeList.size() == 0) {
			for (auto cp : temNode->corePointList) {
				dis = calculateDistanceBycoordinate(tstream, test, outlierId, cp->corePointCoordinate) - 2 * test.getR();
				if (dis <= kR) {
					for (auto id : cp->dequeE0) {
						if (id != outlierId && !binsVec[id]) {
							dis = calculateDistanceById(tstream, test, id, outlierId);
							binsVec[id] = true;
							if (dis <= kR) {
								neighborSet.emplace(dis);
								if (neighborSet.size() > k) {
									neighborSet.erase(--neighborSet.end());
									kR = *(--neighborSet.end());
								}
							}
						}
					}
					for (auto id : cp->dequeE1) {
						if (id != outlierId && !binsVec[id]) {
							dis = calculateDistanceById(tstream, test, id, outlierId);
							binsVec[id] = true;
							if (dis <= kR) {
								neighborSet.emplace(dis);
								if (neighborSet.size() > k) {
									neighborSet.erase(--neighborSet.end());
									kR = *(--neighborSet.end());
								}
							}
						}
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, outlierId, child->coordinate) - child->radius;
				if (dis <= (2 * kR)) {
					checkNodeQueue.push(child);
				}
			}
		}
		checkNodeQueue.pop();
	}
	if (neighborSet.size() == 0) {
		return DBL_MAX;
	}
	return *(--neighborSet.end());
}

void mTreeOfCorePoint::changeRFindNeighborInE0_E3(Tstream& tstream, Test& test, int targetId, CorePoint* core)
{
	bool flag = false;
	double dis = 0;
	double r = test.getR();
	int k = test.getK();
	int neighborNum = 0;
	for (auto id : core->dequeE0) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return ;
				}
			}
		}
	}
	for (auto id : core->dequeE1) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return ;
				}
			}
		}
	}
	for (auto id : core->dequeE2) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return ;
				}
			}
		}
	}
	for (auto id : core->dequeE3) {
		if (id != targetId) {
			dis = calculateDistanceById(tstream, test, id, targetId);
			if (dis <= r) {
				neighborNum++;
				if (neighborNum >= k) {
					return ;
				}
			}
		}
	}
	outlier.emplace(targetId);
	outlierNum++;
	return ;
}

void mTreeOfCorePoint::changeRFindOutlier(Tstream& tstream, Test& test)
{
	createNeedDealCorePoint(tstream, test);
	for (int i = tstream.getDataStreamBegin(); i < tstream.getDataStreamTag(); ++i) {
		PointSet[i]->dataSlideId= PointSet[i]->slideID - PointSet[tstream.getDataStreamBegin()]->slideID;
		if (PointSet[i]->closeCore != nullptr) {
			if (PointSet[i]->closeCore->dequeE0.size() <= test.getK()) {
				findNeighborInCloseCoreE0E1E2(tstream, test, PointSet[i]->closeCore, PointSet[i]);
				PointSet[i]->closeCore->lastDealNum = tstream.getDataStreamTag();
			}
		}
		else if (PointSet[i]->CPInHalfRToR.size() != 0) {
			findNeighborInTemCoreE0E1E2E3(tstream, test, *(PointSet[i]->CPInHalfRToR.begin()), PointSet[i]);
		}
	}
}

void mTreeOfCorePoint::calCoreIndex(Tstream& tstream, Test& test)
{
	queue<Node*> queNode;
	queNode.push(root);
	Node* temNode = nullptr;
	while (!queNode.empty()) {
		temNode = queNode.front();
		addIndexSize(*temNode);
		if (temNode->childNodeList.size() != 0) {
			for (auto child : temNode->childNodeList) {
				queNode.push(child);
			}
		}
		else {
			for (auto core : temNode->corePointList) {
				addIndexSize(*core);
			}
		}
		queNode.pop();
	}
	for (int i = 0; i < slideSize; ++i) {
		addIndexSize(slideVec[i]);
	}
	for (int i = tstream.getDataStreamBegin(); i < tstream.getDataStreamTag(); ++i) {
		addIndexSize(*PointSet[i]);
	}
}

int mTreeOfCorePoint::getCountSlideNum()
{
	return this->countSlideNum;
}

double mTreeOfCorePoint::GetInitDataSetMemory()
{
	return this->initDataSetMemory;
}

double mTreeOfCorePoint::GetAverageMemory()
{
	double count = 0;
	for (int i = 0; i < averageMemory.size(); ++i) {
		count += (averageMemory[i] - GetInitDataSetMemory());
	}
	return count / averageMemory.size();
}

double mTreeOfCorePoint::GetPeakMemory()
{
	return this->peakMemory;
}

void mTreeOfCorePoint::cleanUpPointSet(Tstream& tstream, Test& test)
{
	int windowBegin = tstream.getDataStreamBegin();
	for (auto it = PointSet.begin(); it != PointSet.end(); )
	{
		if (it->second->id < windowBegin)
		{
			dataObj* obj = it->second;
			obj->closeCore = nullptr;
			obj->CPInHalfRToR.clear();
			delete obj;
			it = PointSet.erase(it);
		}
		else
		{
			++it;
		}
	}
}

void mTreeOfCorePoint::clearAll()
{
	if (root != nullptr)
	{
		std::queue<Node*> nodeQueue;
		std::vector<Node*> deleteOrder;
		nodeQueue.push(root);
		while (!nodeQueue.empty())
		{
			Node* cur = nodeQueue.front();
			nodeQueue.pop();
			deleteOrder.push_back(cur);
			if (!cur->corePointList.empty())
			{
				for (CorePoint* cp : cur->corePointList)
				{
					delete cp;
				}
				cur->corePointList.clear();
			}
			else
			{
				for (Node* child : cur->childNodeList)
				{
					if (child != nullptr) nodeQueue.push(child);
				}
			}
		}
		for (auto it = deleteOrder.rbegin(); it != deleteOrder.rend(); ++it)
		{
			Node* n = *it;
			n->childNodeList.clear();
			n->parentNode = nullptr;
			delete n;
		}
		root = nullptr;
	}
}

void mTreeOfCorePoint::dealSlideVec(Tstream& tstream, Test& test)
{
	int begin = tstream.getDataStreamBegin();
	for (int i = 0; i < slideVec.size(); ++i) {
		for (auto it = slideVec[i].needDealDataObj.begin(); it != slideVec[i].needDealDataObj.end();) {
			if ((*it)->id < begin) {
				it = slideVec[i].needDealDataObj.erase(it);
			}
			else {
				++it;
			}
		}
	}
}

void mTreeOfCorePoint::clearSlideVec()
{
	for (Slide& slide : slideVec)
	{
		slide.needDealCP.clear();
		slide.needDealDataObj.clear();
	}
	slideVec.clear();
	std::vector<Slide>().swap(slideVec);
}

void mTreeOfCorePoint::clearPointSet()
{
	for (auto it = PointSet.begin(); it != PointSet.end(); )
	{
		dataObj* obj = it->second;
		obj->closeCore = nullptr;
		obj->CPInHalfRToR.clear();
		delete obj;
		it = PointSet.erase(it);
	}
	unordered_map<int, dataObj*>().swap(PointSet);
}
