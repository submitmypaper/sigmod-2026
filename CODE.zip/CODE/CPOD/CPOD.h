#pragma once
#include <list>
#include <vector>
#include <stdlib.h>
#include <iostream>
#include"Test.h"
#include"Tstream.h"
#include <set>
#include <queue>
#include <map>
#include <unordered_map>
#include <stack>
typedef vector<double> Data;
struct CompareGreater {
	bool operator()(int a, int b) const {
		return a > b;
	}
};

class mTreeOfCorePoint {
public:
	struct CorePoint {
		vector<double> corePointCoordinate;
		deque<int> dequeE0;
		deque<int> dequeE1;
		deque<int> dequeE2;
		deque<int> dequeE3;
		bool operator==(const CorePoint& CorePoint) {
			return (corePointCoordinate == CorePoint.corePointCoordinate);
		}
		bool maintainBins = false;
		int lastDealNum = -1;			
	};
	struct dataObj {
		int id;
		int slideID;                   
		CorePoint* closeCore=nullptr;  
		list<CorePoint*> CPInHalfRToR;  
		vector<int> vecNeighborSlide;  
		int dataSlideId;				
		bool dataState = false;         
		int vecNeighborNum = 0;        
		int AllNeighborNum = 0;			
		bool operator==(const dataObj& other) const {
			return id == other.id;
		}
	};
	struct Slide {
		int slideId;
		list<CorePoint*> needDealCP;
		list<dataObj*> needDealDataObj;
	};
	struct Node {
		int id;
		double radius;
		double disToParent;
		vector<double> coordinate;
		Node* parentNode;
		list<Node*> childNodeList;
		list<CorePoint*> corePointList;
		bool operator==(const Node& Node) {
			return ((id == Node.id) && (radius == Node.radius) && (coordinate == Node.coordinate));
		}
	};
	mTreeOfCorePoint();
	~mTreeOfCorePoint();
	void setChildNodeSplitNum(int num);
	void setDataObjSplitNum(int num);
	double calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2);
	double calculateDistanceBycoordinate(Tstream& tstream, Test& test, int id, Data data);
	double calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2);
	void Init(Tstream& tstream, Test& test);
	void Init(Tstream& tstream, Test& test, int tstreamBegin, int tstreamTag);
	void splitMTree(Tstream& tstream, Test& test);
	void chooseSubInSurplusEntry(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node);
	void createNode(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node, int id);
	void addCorePointToSubTree(Tstream& tstream, Test& test, Node* node);
	void addDataObjToMTree(Tstream& tstream, Test& test, dataObj* data, Node* node);
	void findOutlier(Tstream& tstream, Test& test);
	void createNeedDealCorePoint(Tstream& tstream, Test& test);
	void addCorePointToSlideVec(Tstream& tstream, Test& test, CorePoint* cp);
	void findNeighborInCloseCoreE0E1E2(Tstream& tstream, Test& test, CorePoint* closeCore, dataObj* data);
	void findNeighborInTemCoreE0E1E2E3(Tstream& tstream, Test& test, CorePoint* temCore, dataObj* data);
	void addDataObjToNeedDealDataObj(Tstream& tstream, Test& test, dataObj* data);
	void Update(Tstream& tstream, Test& test);
	void dealNewDataObj(Tstream& tstream, Test& test, list<dataObj*>& newDataObjList);
	void dealOldSlide(Tstream& tstream, Test& test, Slide& oldSlide);
	void cutExpireE0Data(Tstream& tstream, Test& test, CorePoint* cp);
	int calExpireSlideNum(Tstream& tstream, Test& test, dataObj* data);
	void updateDataObjVecSlideNeighbor(Tstream& tstream, Test& test, dataObj* data, int temNewNeighborNum);
	void updateAll(Tstream& tstream, Test& test);
	void addNewCoreToMTree(Tstream& tstream, Test& test, CorePoint* newCore);
	Node* createNewMiddleNode(Tstream& tstream, Test& test, Node* node, CorePoint* newCore);
	void updateNewCoreE(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore);
	void findEInCurLeaf(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore, list<CorePoint*>& temCoreList);
	void findEInOtherLeaf(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore, list<CorePoint*>& temCoreList);
	void addNodeToQueue(Tstream& tstream, Test& test, Node* node, CorePoint* newCore, queue<Node*>& findNeighborQueue);
	void newDealDataInCPE0E1(Tstream& tstream, Test& test, deque<int>& E, CorePoint* newCore);
	void checkSplit(Tstream& tstream, Test& test, Node* targetNode, CorePoint* newCore);
	void splitTemChildList(Tstream& tstream, Test& test, Node* targetNode, list<Node*>& temChildList, Node* splitNode);
	void UpdateChooseSubInSurplusEntry(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* splitNode, list<Node*>& temChildList);
	void UpdateCreateNode(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node, int id);
	void UpdateAddChildToMidNode(Tstream& tstream, Test& test, Node* node, list<Node*>& temChildList, Node* targetNode, int targetNodeId);
	void UpdateaddDataObjToMTree(Tstream& tstream, Test& test, dataObj* data, Node* node);
	void updateFindNeighborInCloseCoreE0E1E2(Tstream& tstream, Test& test, CorePoint* temCore, dataObj* data);
	void updateFindNeighborInTemCoreE0E1E2E3(Tstream& tstream, Test& test, CorePoint* temCore, dataObj* data);
	void updateRadius(Tstream& tstream, Test& test, Node* node);
	void checkMTreeStruct(Tstream& tstream, Test& test);
	void reCreateMTree(Tstream& tstream, Test& test);
	int calWindowMaintainObjNum(Tstream& tstream, Test& test);

	void checkChangeR(Tstream& tstream, Test& test);
	void findCanObj(Tstream& tstream, Test& test, int count, unordered_map<int, CorePoint*>& candidateObj);
	double findKNNForOutlier(Tstream& tstream, Test& test, int outlierId, CorePoint* core);
	double findKNNForOutlier(Tstream& tstream, Test& test, int outlierId);
	double newFindKNNForOutlier(Tstream& tstream, Test& test, int outlierId);
	void reFindOutlier(Tstream& tstream, Test& test);
	void changeRFindNeighborInE0_E2(Tstream& tstream, Test& test, int targetId, CorePoint* core);
	void changeRFindNeighborInE0_E3(Tstream& tstream, Test& test, int targetId, CorePoint* core);
	void changeRFindOutlier(Tstream& tstream, Test& test);
	void calCoreIndex(Tstream& tstream, Test& test);
	template<typename T>
	void addIndexSize(const T& var);
	int getCountSlideNum();
	double GetInitDataSetMemory();
	double GetAverageMemory();
	double GetPeakMemory();
	void cleanUpPointSet(Tstream& tstream, Test& test);
	void clearAll();
	void dealSlideVec(Tstream& tstream, Test& test);
	void clearSlideVec();
	void clearPointSet();
private:
	Node* root;
	int nodeIdCount = 0;
	int slideIdCount = 0;
	int childNodeSplitNum = 0;
	int dataObjSplitNum = 0;
	vector<Slide> slideVec;
	int countNum = 0;
	int outlierNum = 0;
	unordered_map<int, dataObj*>PointSet;
	int slideSize = 0;
	set<int>outlier;

	size_t  indexSize = 0;
	int countTemp = 0;

	double initDataSetMemory;
	vector<double> averageMemory;
	double peakMemory;
	short countSlideNum = 0;
};
template<typename T>
inline void mTreeOfCorePoint::addIndexSize(const T& var)
{
	indexSize += sizeof(var);
}
