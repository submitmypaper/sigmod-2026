#pragma once
#include <vector>
#include <math.h>
#include"Test.h"
using namespace std;
class Tstream {
public:
	Tstream();
	~Tstream();

	void readDataFile(Test& test, int j);
	double getDataStream(int intObjectNumber);
	vector<double> getData(int dataId, int dimension);
	int getDataStreamLength();
	int getDataStreamBegin();
	int getDataStreamTag();
	void setDataStreamBegin(int begin);
	void setDataStreamTag(int tag);
	void Init(Test& test, int j);
	void addDataStreamBegin(int outFlow);
	void addDataStreamTag(int inFlow);
	void addUpdateNeighborNumById(Test& test, int id);
	void setUpdateNeighborNumById(int id, int num);
	unsigned short getUpdateNeighborNumById(int id);
	int getvecDataStreamNum(int dimension);
	void resetupdateNeighborNum();
	void setS_change(Test& test);
	int getS_change(int idx);
	short getTotalSlideNum();
private:
	vector<double> vecDataStream;
	vector<unsigned short>	updateNeighborNum;
	int dataStreamBegin = 0;
	int dataStreamTag = 0;
	vector<int>S_change;
	short totalSlideNum = 0;
};