#include "LEAP.h"
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <set>
#include <cassert>
#include <math.h>
#include <algorithm>
#include "Tstream.h"
#include<stack>
#include<unordered_map>
#include <numeric> 
#include<fstream>
#include<iterator>
#include <float.h>
using namespace std;
list<int> temList;
LEAP::LEAP()
{
}

LEAP::~LEAP()
{
}

void LEAP::setChildNodeSplitNum(int num)
{
	childNodeSplitNum = num;
}

void LEAP::setDataObjSplitNum(int num)
{
	dataObjSplitNum = num;
}

void LEAP::Init(Tstream& tstream, Test& test)
{
	slideNum = test.getWindowSize();
	slideVec.resize(slideNum);
	for (int i = 0; i < slideNum; ++i) {
		Slide slide;
		slide.slideId = slideIdCount++;
		Node* slideRoot = new Node;
		slideRoot->nodeId = nodeIdCount++;
		slide.mtreeRoot = slideRoot;
		addDataObjToSlide(tstream, test, slide);
		slideVec[i] = slide;
	}
	findOutlier(tstream, test);
}

double LEAP::calculateDistanceById(Tstream& tstream, Test& test, int id1, int id2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id1 * dimension + i) - tstream.getDataStream(id2 * dimension + i), 2);
	}
	return sqrt(dis);
}

double LEAP::calculateDistanceBycoordinate(Tstream& tstream, Test& test, int id, Data data)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(tstream.getDataStream(id * dimension + i) - data[i], 2);
	}
	return sqrt(dis);
}

double LEAP::calculateDistanceBetweenTwoData(Tstream& tstream, Test& test, Data data1, Data data2)
{
	int dimension = test.getDimension();
	double dis = 0;
	for (int i = 0; i < dimension; ++i) {
		dis += pow(data1[i] - data2[i], 2);
	}
	return sqrt(dis);
}

void LEAP::addDataObjToSlide(Tstream& tstream, Test& test, Slide& slide)
{
	if (slide.slideId < slideNum) {
		tstream.addDataStreamTag(tstream.getS_change(slide.slideId));
	}
	int dimension = test.getDimension();
	vector<double> minDimension(dimension, DBL_MAX);
	vector<double> maxDimension(dimension, 0.0);
	for (
		int i = tstream.getDataStreamTag() - tstream.getS_change(slide.slideId); i < tstream.getDataStreamTag(); ++i) {
		PointSet[i] = slide.slideId;
		slide.mtreeRoot->dataObjList.push_front(i);
		calculateMemoryUsage(tstream, test, i);
		vector<double> temDataObj = tstream.getData(i, dimension);
		for (int j = 0; j < dimension; ++j) {
			if (temDataObj[j] < minDimension[j]) {
				minDimension[j] = temDataObj[j];
			}
			if (temDataObj[j] > maxDimension[j]) {
				maxDimension[j] = temDataObj[j];
			}
		}
	}

	slide.mtreeRoot->radius = 0;
	for (int i = 0; i < dimension; ++i) {
		if (slide.mtreeRoot->radius < (maxDimension[i] - minDimension[i]) * sqrt(dimension) / 2) {
			slide.mtreeRoot->radius = (maxDimension[i] - minDimension[i]) * sqrt(dimension) / 2;
		}
	}
	slide.mtreeRoot->maxRadius = slide.mtreeRoot->radius;
	for (int i = 0; i < dimension; ++i) {
		slide.mtreeRoot->coordinate.push_back((maxDimension[i] + minDimension[i]) / 2);
	}
	splitmTree(tstream, test, slide, slide.mtreeRoot);
}

void LEAP::splitmTree(Tstream& tstream, Test& test, Slide& slide, Node* node)
{
	queue<Node*> needSplitNode;
	vector<double> subTreeCoordinate;
	needSplitNode.push(node);
	Node* temNode = nullptr;
	int dimension = test.getDimension();
	double dis;
	double disMin;
	Node* chooseNode;
	Node* deleteNode;
	while (!needSplitNode.empty()) {
		subTreeCoordinate.clear();
		temNode = needSplitNode.front();
		while (temNode->dataObjList.size() != 0) {
			if (temNode->childNodeList.size() == childNodeSplitNum * 0.75) {
				break;
			}
			chooseSubInSurplusEntry(tstream, test, subTreeCoordinate, childNodeSplitNum * 0.75 - temNode->childNodeList.size(), temNode);
			for (int i = 0; i < subTreeCoordinate.size() / dimension; ++i) {
				createNode(tstream, test, subTreeCoordinate, temNode, i);
			}
			subTreeCoordinate.clear();
			addDataObjToChildNode(tstream, test, temNode);
		}
		deleteNode = nullptr;
		if (temNode->dataObjList.size() != 0) {
			for (auto data = temNode->dataObjList.begin(); data != temNode->dataObjList.end();) {
				chooseNode = nullptr;
				disMin = DBL_MAX;
				for (auto child : temNode->childNodeList) {
					dis = calculateDistanceBycoordinate(tstream, test, *data, child->coordinate);
					if (dis < disMin) {
						disMin = dis;
						chooseNode = child;
					}
				}
				if (chooseNode != nullptr) {
					chooseNode->dataObjList.push_back(*data);
					chooseNode->radius = max(chooseNode->radius, disMin);
					chooseNode->maxRadius = chooseNode->radius;
					data = temNode->dataObjList.erase(data);
				}
			}
		}
		for (auto child = temNode->childNodeList.begin(); child != temNode->childNodeList.end();) {
			if ((*child)->childNodeList.size() == 0 && (*child)->dataObjList.size() == 0) {
				deleteNode = *child;
				child = temNode->childNodeList.erase(child);
				delete deleteNode;
				deleteNode = nullptr;
				continue;
			}
			child++;
		}
		for (auto child = temNode->childNodeList.begin(); child != temNode->childNodeList.end(); child++) {
			if ((*child)->dataObjList.size() > dataObjSplitNum && temNode->childNodeList.size() > 1) {
				needSplitNode.push(*child);
			}
			else {
				(*child)->dataObjList.sort(greater<int>());
			}
		}
		needSplitNode.pop();
	}
}

static bool cmp(const vector<double>& v1, const vector<double>& v2) {
	return v1[0] > v2[0];
}

void LEAP::chooseSubInSurplusEntry(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, int availableNodeNum, Node* node)
{
	bool cmp(const vector<double>&v1, const vector<double>&v2);
	int dimension = test.getDimension();
	double maxNum;
	double minNum;
	vector<vector<double>> dif(dimension, vector<double>(3, 0));
	for (int i = 0; i < dimension; ++i) {
		maxNum = -10;
		minNum = DBL_MAX;
		for (list<int>::iterator j = node->dataObjList.begin(); j != node->dataObjList.end(); ++j) {
			double data = tstream.getDataStream((*j) * dimension + i);
			if (data > maxNum) {
				maxNum = data;
				dif[i][1] = *j;
			}
			if (data < minNum) {
				minNum = data;
				dif[i][2] = *j;
			}
		}
		dif[i][0] = maxNum - minNum;
	}
	sort(dif.begin(), dif.end(), cmp);
	set<double> flagNodeSet;
	for (int i = 0; i < dimension; ++i) {
		if (!flagNodeSet.count(dif[i][1]) && !flagNodeSet.count(dif[i][2]) && availableNodeNum > 0) {
			flagNodeSet.insert(dif[i][1]);
			flagNodeSet.insert(dif[i][2]);
			addNodeToVec(tstream, test, subTreecoordinate, (int)dif[i][1], (int)dif[i][2], availableNodeNum, node->radius);
		}
	}
}

void LEAP::addNodeToVec(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, int id1, int id2, int& availableNodeNum, double radius)
{
	int dimension = test.getDimension();
	double c1 = 0;
	double c2 = 0;
	vector<double> temNode(dimension);
	if (subTreecoordinate.size() == 0) {
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.getDataStream(id1 * dimension + i);
			c2 = tstream.getDataStream(id2 * dimension + i);
			subTreecoordinate.push_back((3 * c1 + c2) / 4);
		}
		availableNodeNum--;
		if (availableNodeNum == 0) {
			return;
		}
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.getDataStream(id1 * dimension + i);
			c2 = tstream.getDataStream(id2 * dimension + i);
			subTreecoordinate.push_back((c1 + 3 * c2) / 4);
		}
		availableNodeNum--;
	}
	else {
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.getDataStream(id1 * dimension + i);
			c2 = tstream.getDataStream(id2 * dimension + i);
			temNode.push_back((3 * c1 + c2) / 4);
		}
		if (chooseBestCoordinate(tstream, test, subTreecoordinate, temNode, radius)) {
			for (int i = 0; i < dimension; ++i) {
				subTreecoordinate.push_back(temNode[i]);
			}
			availableNodeNum--;
		}
		temNode.clear();
		if (availableNodeNum == 0) {
			return;
		}
		for (int i = 0; i < dimension; ++i) {
			c1 = tstream.getDataStream(id1 * dimension + i);
			c2 = tstream.getDataStream(id2 * dimension + i);
			temNode.push_back((c1 + 3 * c2) / 4);
		}
		if (chooseBestCoordinate(tstream, test, subTreecoordinate, temNode, radius)) {
			for (int i = 0; i < dimension; ++i) {
				subTreecoordinate.push_back(temNode[i]);
			}
			availableNodeNum--;
		}
	}
}

bool LEAP::chooseBestCoordinate(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, vector<double>& temNode, double radius)
{
	double dis = 0;
	int dimension = test.getDimension();
	for (int i = 0; i < subTreecoordinate.size() / dimension; ++i) {
		dis = 0;
		for (int j = 0; j < dimension; ++j) {
			dis += pow((subTreecoordinate[i * dimension + j] - temNode[j]), 2);
		}
		if (sqrt(dis) <= radius / 2) {
			return false;
		}
	}
	return true;
}

void LEAP::createNode(Tstream& tstream, Test& test, vector<double>& subTreecoordinate, Node* node, int id1)
{
	int dimension = test.getDimension();
	Node* childnode = new Node();
	childnode->parentNode = node;
	childnode->nodeId = nodeIdCount++;
	childnode->maxRadius = node->maxRadius * 0.5;
	for (int i = 0; i < dimension; ++i) {
		childnode->coordinate.push_back(subTreecoordinate[id1 * dimension + i]);
	}
	childnode->disToParent = calculateDistanceBetweenTwoData(tstream, test, childnode->coordinate, node->coordinate);
	node->childNodeList.push_back(childnode);
}

void LEAP::addDataObjToChildNode(Tstream& tstream, Test& test, Node* node)
{
	Node* chooseNode;
	double dis;
	double minDis;
	for (auto id = node->dataObjList.begin(); id != node->dataObjList.end();) {
		minDis = DBL_MAX;
		chooseNode = nullptr;
		for (auto child : node->childNodeList) {
			dis = calculateDistanceBycoordinate(tstream, test, *id, child->coordinate);
			if (dis < minDis && dis <= child->maxRadius) {
				minDis = dis;
				chooseNode = child;
			}
		}
		if (chooseNode != nullptr) {
			chooseNode->dataObjList.push_back(*id);
			chooseNode->radius = max(chooseNode->radius, minDis);
			id = node->dataObjList.erase(id);
			continue;
		}
		id++;
	}
}

void LEAP::findOutlier(Tstream& tstream, Test& test)
{
	for (int i = 0; i < slideNum; ++i) {
		findNeighborBySlide(tstream, test, slideVec[i], i);
	}
}

void LEAP::findNeighborBySlide(Tstream& tstream, Test& test, Slide& slide, int curSlideId)
{
	queue<Node*> leafNodeQueue;
	Node* temNode = nullptr;
	leafNodeQueue.push(slide.mtreeRoot);
	int sucNeighborNum = 0;
	int k = test.getK();
	bool flag = false;
	while (!leafNodeQueue.empty()) {
		temNode = leafNodeQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto dataId : temNode->dataObjList) {
				temList.clear();
				sucNeighborNum = 0;
				flag = false;
				dataObj data;
				data.dataId = dataId;
				data.dataObjSlide = curSlideId;
				data.vecNeighborNum = sucNeighborNum;
				data.oldVecNeighborNum = sucNeighborNum;
				data.vecSlideNeighbor.resize(slideNum);
				data.dataidx = PointSet[data.dataId] - PointSet[tstream.getDataStreamBegin()];
				data.dataLastFindSlideNum = slideNum;
				findNeiInWholeWindow(tstream, test, data);
				if (!data.dataState) {
					outliers.push_back(data);
					slideVec[PointSet[data.dataId] - PointSet[tstream.getDataStreamBegin()]].outlierList.push_back(data);
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				leafNodeQueue.push(child);
			}
		}
		leafNodeQueue.pop();
	}
}

void LEAP::findInCurSlide(Tstream& tstream, Test& test, int dataId, int& sucNeighborNum, int slideId, bool& flag)
{
	Node* temNode = nullptr;
	queue<Node*> checkQueue;
	checkQueue.push(slideVec[slideId].mtreeRoot);
	double dis;
	double r = test.getR();
	int k = test.getK();
	while (!checkQueue.empty()) {
		temNode = checkQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto id : temNode->dataObjList) {
				if (id != dataId) {
					dis = calculateDistanceById(tstream, test, dataId, id);
					if (dis <= r) {
						sucNeighborNum++;
						temList.push_back(id);
						if (sucNeighborNum >= k) {
							flag = true;
							return;
						}
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, dataId, child->coordinate) - child->radius;
				if (dis <= r) {
					checkQueue.push(child);
				}
			}
		}
		checkQueue.pop();
	}
}

void LEAP::findInSucSlide(Tstream& tstream, Test& test, int dataId, int& sucNeighborNum, int slideId, bool& flag)
{
	Node* temNode = nullptr;
	queue<Node*> checkQueue;
	checkQueue.push(slideVec[slideId].mtreeRoot);
	double dis;
	double r = test.getR();
	int k = test.getK();
	while (!checkQueue.empty()) {
		temNode = checkQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto id : temNode->dataObjList) {
				dis = calculateDistanceById(tstream, test, dataId, id);
				if (dis <= r) {
					sucNeighborNum++;
					temList.push_back(id);
					if (sucNeighborNum >= k) {
						flag = true;
						return;
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, dataId, child->coordinate) - child->radius;
				if (dis <= r) {
					checkQueue.push(child);
				}
			}
		}
		checkQueue.pop();
	}
}

void LEAP::findInPreSlide(Tstream& tstream, Test& test, dataObj& data, int slideId, bool& flag)
{
	Node* temNode = nullptr;
	queue<Node*> checkQueue;
	checkQueue.push(slideVec[slideId].mtreeRoot);
	double dis;
	double r = test.getR();
	int k = test.getK();
	int slideCountNum = 0;
	int neighborNum = calNeighborNum(tstream, test, data);
	while (!checkQueue.empty()) {
		temNode = checkQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto id : temNode->dataObjList) {
				dis = calculateDistanceById(tstream, test, data.dataId, id);
				if (dis <= r) {
					slideCountNum++;
					temList.push_back(id);
					if ((slideCountNum + neighborNum) >= k) {
						data.vecSlideNeighbor[slideId] = slideCountNum;
						flag = true;
						return;
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, data.dataId, child->coordinate) - child->radius;
				if (dis <= r) {
					checkQueue.push(child);
				}
			}
		}
		checkQueue.pop();
	}
	data.vecSlideNeighbor[slideId] = slideCountNum;
}

void LEAP::dealDataObj(Tstream& tstream, Test& test, dataObj& data)
{
	for (int i = 0; i < data.dataObjSlide; ++i) {
		if (data.vecSlideNeighbor[i] != 0) {
			slideVec[i].needDealDataObj.push_back(data);
			break;
		}
	}
}

int LEAP::calNeighborNum(Tstream& tstream, Test& test, dataObj& data)
{
	int num = data.vecNeighborNum;
	for (int i = 0; i < data.dataObjSlide; ++i) {
		num += data.vecSlideNeighbor[i];
	}
	return num;
}

void LEAP::Update(Tstream& tstream, Test& test)
{
	int dimension = test.getDimension();
	clock_t startTime1, endTime1;
	startTime1 = clock();
	countSlideNum = tstream.getTotalSlideNum() - test.getWindowSize();
	int countSize = test.getWindowSize();
	for (int iii = 0; iii < countSlideNum; ++iii) {
		if (iii % countSize == 0 && iii != 0)
		{
			endTime1 = clock();
			cout << "Current cursor" << tstream.getDataStreamBegin() << "     Time = " << (double)(endTime1 - startTime1) / CLOCKS_PER_SEC << "s" << endl;
			startTime1 = endTime1;
		}
		tstream.addDataStreamBegin(tstream.getS_change(iii));
		tstream.addDataStreamTag(tstream.getS_change(slideIdCount));
		if (tstream.getDataStreamTag() > tstream.getvecDataStreamNum(test.getDimension())) {
			break;
		}
		dealNewSlide(tstream, test);
		outliers.clear();
		int sum = 0;
		for (int i = 0; i < slideNum; i++) {
			for (auto& it : slideVec[i].outlierList) {
				outliers.push_back(it);
			}
		}
		for (auto& it : outliers) {
			if (it.dataId < tstream.getDataStreamBegin())continue;
			findNeiInWholeWindow(tstream, test, it);
			if (!it.dataState)
			{
				sum++;
			}
		}
	}
}

void LEAP::dealNewSlide(Tstream& tstream, Test& test)
{
	Slide oldSlide = slideVec[0];
	for (int i = 0; i < (slideNum - 1); ++i) {
		slideVec[i] = slideVec[i + 1];
	}
	Slide newSlide;
	newSlide.slideId = slideIdCount++;
	Node* newSlideRoot = new Node;
	newSlideRoot->nodeId = nodeIdCount++;
	newSlide.mtreeRoot = newSlideRoot;
	addDataObjToSlide(tstream, test, newSlide);
	for (
		int i = tstream.getDataStreamTag() - tstream.getS_change(slideIdCount - 1); i < tstream.getDataStreamTag(); ++i) {
		for (int slideIndex = 0; slideIndex < slideNum - 2; ++slideIndex) {
			findNeighborForOutlier(tstream, test, slideVec[slideIndex], i);
		}
	}
	slideVec[slideNum - 1] = newSlide;
	updateFindNeighborForNewSlide(tstream, test, newSlide);
	reDealOldSlide(tstream, test, oldSlide);

	queue<Node*>q;
	q.push(oldSlide.mtreeRoot);
	Node* tempNode = nullptr;
	while (!q.empty()) {
		tempNode = q.front();
		if (!tempNode->childNodeList.empty()) {
			for (auto it : tempNode->childNodeList) {
				q.push(it);
			}
		}
		delete tempNode;
		q.pop();
	}
}

void LEAP::updateFindNeighborForNewSlide(Tstream& tstream, Test& test, Slide& slide)
{
	queue<Node*> leafNodeQueue;
	Node* temNode = nullptr;
	leafNodeQueue.push(slide.mtreeRoot);
	int sucNeighborNum = 0;
	int k = test.getK();
	bool flag = false;
	while (!leafNodeQueue.empty()) {
		temNode = leafNodeQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto dataId : temNode->dataObjList) {
				sucNeighborNum = 0;
				flag = false;
				dataObj data;
				data.dataId = dataId;
				data.vecNeighborNum = sucNeighborNum;
				data.oldVecNeighborNum = sucNeighborNum;
				data.vecSlideNeighbor.resize(slideNum);
				data.dataidx = PointSet[data.dataId] - PointSet[tstream.getDataStreamBegin()];
				data.dataLastFindSlideNum = slideNum;
				findNeiInWholeWindow(tstream, test, data);
				if (!data.dataState) {
					outliers.push_back(data);
					slideVec[PointSet[data.dataId] - PointSet[tstream.getDataStreamBegin()]].outlierList.push_back(data);
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				leafNodeQueue.push(child);
			}
		}
		leafNodeQueue.pop();
	}
}

void LEAP::updateFindInPreSlide(Tstream& tstream, Test& test, dataObj& data, int slideId, bool& flag)
{
	Node* temNode = nullptr;
	queue<Node*> checkQueue;
	checkQueue.push(slideVec[slideId].mtreeRoot);
	double dis;
	double r = test.getR();
	int k = test.getK();
	int slideCountNum = 0;
	int neighborNum = calNeighborNum(tstream, test, data);
	while (!checkQueue.empty()) {
		temNode = checkQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto id : temNode->dataObjList) {
				dis = calculateDistanceById(tstream, test, data.dataId, id);
				if (dis <= r) {
					slideCountNum++;
					tstream.addUpdateNeighborNumById(test, id);
					if ((slideCountNum + neighborNum) >= k) {
						data.vecSlideNeighbor[slideId] = slideCountNum;
						flag = true;
						return;
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, data.dataId, child->coordinate) - child->radius;
				if (dis <= r) {
					checkQueue.push(child);
				}
			}
		}
		checkQueue.pop();
	}
	data.vecSlideNeighbor[slideId] = slideCountNum;
}

void LEAP::reDealOldSlide(Tstream& tstream, Test& test, Slide& slide)
{
	int temNewNeighborNum = 0;
	for (auto& data : slide.needDealDataObj) {
		temNewNeighborNum = tstream.getUpdateNeighborNumById(data.dataId);
		if (data.dataState) {
			if (data.vecNeighborNum + temNewNeighborNum < test.getK()
				) {
				findNeiInWholeWindow(tstream, test, data);
				if (!data.dataState && data.dataId >= tstream.getDataStreamBegin()) {
					slideVec[0].outlierList.push_back(data);
					outliers.push_back(data);
				}
			}
		}
	}
	for (auto& data : slide.outlierList) {
		if (data.vecNeighborNum < test.getK()) {
			slideVec[0].outlierList.push_back(data);
			outliers.push_back(data);
		}

	}
}

int LEAP::calExpireSlideNum(Tstream& tstream, Test& test, dataObj& data)
{
	for (int i = 0; i < data.dataObjSlide; ++i) {
		if (data.vecSlideNeighbor[i] != 0) {
			return data.vecSlideNeighbor[i];
		}
	}
	return data.vecSlideNeighbor[data.dataObjSlide];
}

void LEAP::reFindNeighborForDataObj(Tstream& tstream, Test& test, dataObj& data)
{
	int beginSlideId = 0;
	int needFindNeighborNum = test.getK();
	int sucNeighborNum = 0;
	bool flag = false;
	for (int i = beginSlideId; i < slideNum; ++i) {
		updateFindInSucSlide(tstream, test, data.dataId, sucNeighborNum, i, flag, needFindNeighborNum);
		if (flag) {
			break;
		}
	}
	if (sucNeighborNum < needFindNeighborNum) {
	}
	else {
	}
}

int LEAP::findIndex(Tstream& tstream, Test& test, int targetSlideId)
{
	for (int i = 0; i < slideNum; ++i) {
		if (slideVec[i].slideId >= targetSlideId) {
			return i;
		}
	}
}

void LEAP::updateFindInSucSlide(Tstream& tstream, Test& test, int dataId, int& sucNeighborNum, int slideId, bool& flag, int targetNeighborNum)
{
	Node* temNode = nullptr;
	queue<Node*> checkQueue;
	checkQueue.push(slideVec[slideId].mtreeRoot);
	double dis;
	double r = test.getR();
	while (!checkQueue.empty()) {
		temNode = checkQueue.front();
		if (temNode->dataObjList.size() != 0) {
			for (auto id : temNode->dataObjList) {
				dis = calculateDistanceById(tstream, test, dataId, id);
				if (dis <= r) {
					sucNeighborNum++;
					if (sucNeighborNum >= targetNeighborNum) {
						flag = true;
						return;
					}
				}
			}
		}
		else {
			for (auto child : temNode->childNodeList) {
				dis = calculateDistanceBycoordinate(tstream, test, dataId, child->coordinate) - child->radius;
				if (dis <= r) {
					checkQueue.push(child);
				}
			}
		}
		checkQueue.pop();
	}
}

void LEAP::findNeighborForOutlier(Tstream& tstream, Test& test, Slide& slide, int newObjId)
{
	double dis = 0;
	double r = test.getR();
	for (auto& outlier : slide.outlierList) {
		dis = calculateDistanceById(tstream, test, outlier.dataId, newObjId);
		if (dis <= r) {
			outlier.vecNeighborNum++;
		}
	}
}

void LEAP::calculateMemoryUsage(Tstream& Tstream, Test& test, const int num)
{
	totalMemoryUsage += sizeof(num);
}

void LEAP::findNeiInWholeWindow(Tstream& tstream, Test& test, dataObj& data)
{
	list<int>nei;
	data.vecNeighborNum = 0;
	double dis = 0;
	double r = test.getR();
	int k = test.getK();
	Node* temNode;
	bool flag = false;
	data.dataState = false;

	for (int i = slideNum - 1; i >= 0; i--) {
		queue<Node*>checkQueue;
		checkQueue.push(slideVec[i].mtreeRoot);
		while (!checkQueue.empty()) {
			temNode = checkQueue.front();
			if (!temNode->dataObjList.empty()) {
				for (auto it : temNode->dataObjList) {
					if (it == data.dataId)continue;
					dis= calculateDistanceById(tstream, test, data.dataId, it);
					if (dis <= r) {
						nei.push_back(it);
						if (nei.size() >= k) {
							flag = true;
						}
					}
				}
				if (flag)break;
			}
			else {
				for (auto child : temNode->childNodeList) {
					dis = calculateDistanceBycoordinate(tstream, test, data.dataId, child->coordinate) - child->radius;
					if (dis <= r) {
						checkQueue.push(child);
					}
				}
			}
			checkQueue.pop();
		}
		if (flag) {
			if (*nei.rbegin() < data.dataId) {
				slideVec[PointSet[*nei.rbegin()] - PointSet[tstream.getDataStreamBegin()]].needDealDataObj.push_back(data);
				data.dataState = true;
				return;
			}
		}
	}
}

void LEAP::listUnique(list<dataObj>& L)
{
	for (auto it = L.begin(); it != L.end();it++) {
		for (auto it1 = next(it, 1); it1 != L.end();) {
			if (it1->dataId == it->dataId) {
				it1 = L.erase(it1);
			}
			else ++it1;
		}
	}
}

void LEAP::reInit(Tstream& ts, Test& t)
{
	slideVec.clear();
	slideVec.resize(slideNum);
	for (int i = 0; i < slideNum; i++) {
		Slide slide;
		slide.slideId = slideIdCount - slideNum + i;
		Node* slideRoot = new Node;
		slideRoot->nodeId = nodeIdCount - slideNum + i;
		slide.mtreeRoot = slideRoot;
		addDataObjToSlide(ts, t, slide);
		slideVec[i] = slide;
	}
	findOutlier(ts, t);
}

double LEAP::getNNR(Tstream& ts, Test& t, dataObj& data)
{
	double dist;
	priority_queue<double>distQ;
	for (int i = 0; i < slideNum; i++) {
		Node* temp = slideVec[i].mtreeRoot;
		queue<Node*>nodeQ;
		nodeQ.push(temp);
		while (!nodeQ.empty()) {
			temp = nodeQ.front();
			if (!temp->dataObjList.empty()) {
				for (auto it : temp->dataObjList) {
					if (it == data.dataId)continue;
					distQ.push(calculateDistanceById(ts, t, data.dataId, it));
					if (distQ.size() > t.getK()) {
						distQ.pop();
					}
				}
			}
			else {
				for (auto it : temp->childNodeList) {
					nodeQ.push(it);
				}
			}
			nodeQ.pop();
		}
	}
	return distQ.top();
}



