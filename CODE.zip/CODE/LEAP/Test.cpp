#include "Test.h"
#include<string>
#include <float.h>
#pragma warning(disable:4996)

Test::Test()
{
}

Test::~Test()
{
}

int Test::getDimension()
{
	return dimension;
}

double Test::getR()
{
	return R;
}
int Test::getK()
{
	return K;
}

int Test::getWindowSize()
{
	return windowSize;
}

void Test::setDimension(int d)
{
	dimension = d;
}

void Test::setR(double r)
{
	R = r;
}

void Test::setK(int k)
{
	K = k;
}

void Test::setWindowSize(int w)
{
	windowSize = w;
}


void Test::Init(vector<Test>& vecTestFile, int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	double n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%lf", &n) != EOF)
	{
		if (i % 4 == 0)
		{
			test.setDimension((int)n);
		}
		if (i % 4 == 1)
		{
			test.setR(n);
		}
		if (i % 4 == 2)
		{
			test.setK((int)n);
		}
		if (i % 4 == 3)
		{
			test.setWindowSize((int)n);
		}
		i++;
		if (i % 4 == 0 && i != 0)
		{
			vecTestFile.push_back(test);
		}
	}
}
