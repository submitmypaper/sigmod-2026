#include<iostream>
#include<stdio.h>
#include"Test.h"
#include"TStream.h"
#include"MMCOD.h"
#include<fstream>
#pragma warning(disable:4996)



void printlogmain(TStream& tstream, Test& test, double time1, double time2) {
	ofstream data;
	data.open("MMCODLogFile.txt", ofstream::app);
	data << "Dimension= " << test.GetDimension() << " N= " << test.GetWindowSize() << " K= " << test.GetK() << endl;
	data << "InitTime= " << time1 << "s" << endl;
	data << "RunningTime= " << time2 << "s" << endl;
	data << "=====================================" << endl;
	data.close();
}

int main()
{
	clock_t startTime, endTime, createTime;
	double initTime;
	
	for (int j = 0; j < 5; j++) {
		double dataMemory = 0;
		vector<double>memory;
		double memoryMax = 0;
		Test t;
		TStream tstream;
		vector<Test> vecTestFile;
		t.Init(vecTestFile, j);
		tstream.Init(vecTestFile[0], j);
		dataMemory = tstream.getProcessMemoryMB();
		for (int i = 0; i < vecTestFile.size(); i++) {
			MMCODFindOutlier MMCOD;
			tstream.SetDataStreamBegin(0);
			tstream.SetDataStreamTag(0);
			startTime = clock();
			MMCOD.ChangeRInit(tstream, vecTestFile[i]);
			endTime = clock();
			memory.push_back(tstream.getProcessMemoryMB() - dataMemory);
			double time = (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000;
			initTime = (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000;
			cout << "Init Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC * 1.000 << 's' << endl;
			startTime = clock();
			MMCOD.Update(tstream, vecTestFile[i], memory, dataMemory);
			endTime = clock();
			cout << "Running Time = " << (double)(endTime - startTime) / CLOCKS_PER_SEC << "s" << endl;
			printlogmain(tstream, vecTestFile[i], initTime, (double)(endTime - startTime) / CLOCKS_PER_SEC);
			double avg = 0;
			for (auto it : memory) {
				avg += it;
			}
			avg /= memory.size();
			memoryMax = tstream.getPeakProcessMemoryMB() - dataMemory;
			memory.clear();
		}
	}
}
