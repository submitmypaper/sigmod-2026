#include "Test.h"
#include<string>
#include<vector>
#pragma warning(disable:4996)

Test::Test()
{
}

Test::~Test()
{
}

int Test::GetDimension()
{
	return dimension;
}

double Test::GetR()
{
	return R;
}

int Test::GetK()
{
	return K;
}

int Test::GetWindowSize()
{
	return windowSize;
}


void Test::SetDimension(int d)
{
	dimension = d;
}

void Test::SetR(double r)
{
	R = r;
}

void Test::SetK(int k)
{
	K = k;
}


void Test::SetWindowSize(int w)
{
	windowSize = w;
}


void Test::Init(vector<Test>& vecTestFile, int j)
{
	FILE* fp;
	string a = to_string(j);
	string s = "test" + a + ".txt";
	fp = fopen(s.data(), "r");
	double n;
	int i = 0;
	Test test;
	while (fscanf(fp, "%lf", &n) != EOF)
	{
		if (i % 4 == 0)
		{
			test.SetDimension((int)n);
		}
		if (i % 4 == 1)
		{
			test.SetR(n);
		}
		if (i % 4 == 2)
		{
			test.SetK((int)n);
		}
		if (i % 4 == 3)
		{
			test.SetWindowSize((int)n);
		}
		i++;
		if (i % 4 == 0 && i != 0)
		{
			vecTestFile.push_back(test);
		}
	}
}
