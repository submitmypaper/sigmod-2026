#pragma once
#include <vector>
#include <stdlib.h>
#include <iostream>
#pragma warning(disable:4996)
using namespace std;
class Test
{
public:
	Test();
	~Test();
	int GetDimension();
	double GetR();
	int GetWindowSize();
	int GetK();

	void SetDimension(int d);
	void SetR(double r);
	void SetK(int k);
	void SetWindowSize(int w);
	void Init(vector<Test>& vecTestFile, int j);

private:
	int dimension = 0;
	double R = 0;
	int K = 0;
	int windowSize = 0;
};

